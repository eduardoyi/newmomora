// Gallery import — its own canvas, so it loads fast and reviews cleanly.
const PHONE_W = 402;
const PHONE_H = 874;
const AB_W = 432;
const AB_H = 920;

function PhoneAB({ children, live = false }) {
  return (
    <div className={live ? 'gi-live' : undefined} style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f0eee9' }}>
      <IOSDevice width={PHONE_W} height={PHONE_H}>{children}</IOSDevice>
    </div>
  );
}
// Android bezel, for the platform-adaptation artboards.
function DroidAB({ children, live = false }) {
  return (
    <div className={live ? 'gi-live' : undefined} style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f0eee9' }}>
      <AndroidDevice width={402} height={874}>{children}</AndroidDevice>
    </div>
  );
}
// iOS bezel with the keyboard raised — for keyboard-avoidance artboards.
function PhoneKB({ children }) {
  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f0eee9' }}>
      <IOSDevice width={PHONE_W} height={PHONE_H} keyboard>{children}</IOSDevice>
    </div>
  );
}

function GalleryCanvas() {
  // ?s=gi-live,gi-deck-a renders only those sections — handy when profiling.
  const only = window.GI_ONLY || new URLSearchParams(location.search).get('s');
  const filter = (kids) => {
    if (!only) return kids;
    const want = only.split(',');
    return React.Children.toArray(kids).filter(k => !k.props || !k.props.id || want.includes(k.props.id));
  };
  return (
    <DesignCanvas>
      {filter([
      <DCSection key="gi-live" id="gi-live" title="Gallery import · the journey"
        subtitle="Fully clickable. Start at the offer: read the explainer, choose full or limited access, watch it work, then swipe or tap through the deck, keep one, and land back on the Timeline. Right = keep, left = set aside; the buttons do the same thing.">
        <DCArtboard id="gi-live-ios" label="Live · start at the offer" width={AB_W} height={AB_H}>
          <PhoneAB live><GIPrototype start="offer"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-live-deck" label="Live · straight into the deck" width={AB_W} height={AB_H}>
          <PhoneAB live><GIPrototype start="deck"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-live-reduced" label="Live · reduced motion" width={AB_W} height={AB_H}>
          <PhoneAB live><GIPrototype start="deck" reduced/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-live-droid" label="Live · Android" width={AB_W} height={AB_H}>
          <DroidAB live><GIPrototype start="offer" platform="android"/></DroidAB>
        </DCArtboard>
        <DCArtboard id="gi-notes-narrative" label="Narrative &amp; rationale" width={560} height={AB_H}>
          <GINoteNarrative/>
        </DCArtboard>
        <DCArtboard id="gi-notes-flow" label="Flow &amp; architecture" width={560} height={AB_H}>
          <GINoteFlow/>
        </DCArtboard>
      </DCSection>,

      <DCSection key="gi-entry" id="gi-entry" title="Gallery import · discovery &amp; entry"
        subtitle="One optional offer after onboarding, an invitation card while the journal is still empty, one permanent row in Settings, and — once a run exists — a small import glyph beside Search that opens a status drawer. Run status never takes over the feed.">
        <DCArtboard id="gi-offer" label="Offer · after onboarding" width={AB_W} height={AB_H}>
          <PhoneAB><GIOffer/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-set-idle" label="Settings · resting entry" width={AB_W} height={AB_H}>
          <PhoneAB><GISettingsEntry state="idle"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-set-ready" label="Settings · suggestions ready" width={AB_W} height={AB_H}>
          <PhoneAB><GISettingsEntry state="ready"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-set-noperm" label="Settings · not a manager" width={AB_W} height={AB_H}>
          <PhoneAB><GISettingsEntry state="unavailable"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-tl-invite" label="Timeline · invitation (new journal)" width={AB_W} height={AB_H}>
          <PhoneAB><GITimelineWithBanner state="invite"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-tl-processing" label="Timeline · glyph, still working" width={AB_W} height={AB_H}>
          <PhoneAB live><GITimelineWithBanner state="processing"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-tl-ready" label="Timeline · glyph, ready" width={AB_W} height={AB_H}>
          <PhoneAB><GITimelineWithBanner state="ready"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-tl-drawer" label="Drawer · ready to review" width={AB_W} height={AB_H}>
          <PhoneAB><GITimelineWithBanner state="ready" drawer/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-tl-drawer-proc" label="Drawer · still working" width={AB_W} height={AB_H}>
          <PhoneAB live><GITimelineWithBanner state="processing" drawer/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-tl-drawer-resume" label="Drawer · pick up again" width={AB_W} height={AB_H}>
          <PhoneAB><GITimelineWithBanner state="resume" drawer/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-tl-drawer-wifi" label="Drawer · waiting for Wi-Fi" width={AB_W} height={AB_H}>
          <PhoneAB><GITimelineWithBanner state="attention" drawer/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-tl-drawer-exp" label="Drawer · ending soon" width={AB_W} height={AB_H}>
          <PhoneAB><GITimelineWithBanner state="expiring" drawer/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-none" label="Nothing stood out" width={AB_W} height={AB_H}>
          <PhoneAB><GIOutcomeEmpty kind="nothing"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-noroll" label="No photos on this phone" width={AB_W} height={AB_H}>
          <PhoneAB><GIOutcomeEmpty kind="emptyLibrary"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-lim-none" label="Nothing from the chosen few" width={AB_W} height={AB_H}>
          <PhoneAB><GIOutcomeEmpty kind="limitedNothing"/></PhoneAB>
        </DCArtboard>
      </DCSection>,

      <DCSection key="gi-trust" id="gi-trust" title="Gallery import · trust &amp; permission"
        subtitle="The uncomfortable fact — small previews really do leave the phone before approval — is card two of three, not a footnote. Then the OS asks, and every answer has a dignified path.">
        <DCArtboard id="gi-expl" label="Explainer" width={AB_W} height={AB_H}>
          <PhoneAB><GIExplainer/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-expl-prev" label="Explainer · what a preview is" width={AB_W} height={AB_H}>
          <PhoneAB><GIExplainer sheet="preview"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-expl-ret" label="Explainer · what is kept" width={AB_W} height={AB_H}>
          <PhoneAB><GIExplainer sheet="retention"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-prompt-ios" label="iOS prompt" width={AB_W} height={AB_H}>
          <PhoneAB><GIOSPrompt platform="ios"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-prompt-droid" label="Android prompt" width={AB_W} height={AB_H}>
          <DroidAB><GIOSPrompt platform="android"/></DroidAB>
        </DCArtboard>
        <DCArtboard id="gi-lim-ios" label="Limited access · iOS" width={AB_W} height={AB_H}>
          <PhoneAB><GIPermissionOutcome kind="limited"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-lim-droid" label="Limited access · Android" width={AB_W} height={AB_H}>
          <DroidAB><GIPermissionOutcome kind="limited" platform="android"/></DroidAB>
        </DCArtboard>
        <DCArtboard id="gi-den-ios" label="Not allowed · iOS" width={AB_W} height={AB_H}>
          <PhoneAB><GIPermissionOutcome kind="denied"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-block-droid" label="Needs a settings change · Android" width={AB_W} height={AB_H}>
          <DroidAB><GIPermissionOutcome kind="blocked" platform="android"/></DroidAB>
        </DCArtboard>
        <DCArtboard id="gi-notes-platform" label="iOS / Android notes" width={560} height={AB_H}>
          <GINotePlatform/>
        </DCArtboard>
      </DCSection>,

      <DCSection key="gi-progress" id="gi-progress" title="Gallery import · progress &amp; resumability"
        subtitle="Every state answers the same three questions: what is happening, can I close the app, and is my camera roll safe. Percentages appear only once the total is genuinely known.">
        <DCArtboard id="gi-p-scan" label="Scanning · keep the app open" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="scanning"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-prep" label="Preparing previews" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="preparing"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-wifi" label="Waiting for Wi-Fi" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="waitingWifi"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-cell" label="Cellular override" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="waitingWifi" sheet="cellular"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-up" label="Sending previews" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="uploading"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-proc" label="Writing drafts · safe to close" width={AB_W} height={AB_H}>
          <PhoneAB live><GIProgressScreen stage="processing"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-ready" label="All done looking" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="ready"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-paused" label="Paused by you" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="paused"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-int" label="Interrupted · carried on" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="interrupted"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-fail" label="Partly finished" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="failed"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-stop" label="Stop · what happens" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="processing" sheet="stop"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-cancel" label="Stopped and cleaned up" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="cancelled"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-p-exp" label="Review period ended" width={AB_W} height={AB_H}>
          <PhoneAB><GIProgressScreen stage="expired"/></PhoneAB>
        </DCArtboard>
      </DCSection>,

      <DCSection key="gi-deck-a" id="gi-deck-a" title="Gallery import · suggestion review"
        subtitle="One suggestion handled like a photograph on a table: the hero print, the event's other photos as a strip, then the drafted words — one text field, exactly like a memory. Nothing is edited here; keeping opens the memory composer. Drag the card in the live artboards, or use the two labelled buttons.">
        <DCArtboard id="gi-a-1" label="Card · at rest" width={AB_W} height={AB_H}>
          <PhoneAB><GIDeckPrint startIndex={0}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-a-2" label="Card · a small event" width={AB_W} height={AB_H}>
          <PhoneAB><GIDeckPrint startIndex={4}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-a-keep" label="Mid-swipe · keep" width={AB_W} height={AB_H}>
          <PhoneAB><GIDeckPrint startIndex={1} frozen demoDx={120}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-a-aside" label="Mid-swipe · set aside" width={AB_W} height={AB_H}>
          <PhoneAB><GIDeckPrint startIndex={2} frozen demoDx={-116}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-a-photos" label="See the whole day" width={AB_W} height={AB_H}>
          <PhoneAB><GIDeckPrint startIndex={0} sheet="photos"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-a-aside-list" label="Set aside · bring back" width={AB_W} height={AB_H}>
          <PhoneAB><GIDeckPrint startIndex={0} sheet="aside"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-a-rest" label="A place to stop" width={AB_W} height={AB_H}>
          <PhoneAB><GIRestPoint/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-a-done" label="All caught up" width={AB_W} height={AB_H}>
          <PhoneAB><GIDeckDone kept={9} aside={3}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-a-droid" label="Deck · Android" width={AB_W} height={AB_H}>
          <DroidAB><GIDeckPrint startIndex={3} platform="android"/></DroidAB>
        </DCArtboard>
        <DCArtboard id="gi-notes-motion" label="Interaction &amp; motion" width={560} height={AB_H}>
          <GINoteMotion/>
        </DCArtboard>
      </DCSection>,

      <DCSection key="gi-approve" id="gi-approve" title="Gallery import · final approval"
        subtitle="Keeping opens the memory composer Momora already has — same header, date pill, serif field, photo grid, tag strip and toolbar. Words, photos, date and who is in it, all in one step, and Save writes the memory onto the day it happened.">
        <DCArtboard id="gi-f-review" label="The memory, before saving" width={AB_W} height={AB_H}>
          <PhoneAB><GIKeepMemory candId="c3"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-f-kb" label="Editing the words · keyboard" width={AB_W} height={AB_H}>
          <PhoneKB><GIKeepMemory candId="c3"/></PhoneKB>
        </DCArtboard>
        <DCArtboard id="gi-f-tag" label="Who is in it · unlimited" width={AB_W} height={AB_H}>
          <PhoneAB><GIKeepMemory candId="c3" pickerOpen/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-f-photos" label="Add from that day" width={AB_W} height={AB_H}>
          <PhoneAB><GIKeepMemory candId="c2" chooserOpen/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-f-dl" label="Downloading originals" width={AB_W} height={AB_H}>
          <PhoneAB><GIKeepMemory candId="c2" state="downloading"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-f-missing" label="A photo is gone" width={AB_W} height={AB_H}>
          <PhoneAB><GIKeepMemory candId="c4" state="unavailable"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-f-posting" label="Saving · safe to close" width={AB_W} height={AB_H}>
          <PhoneAB><GIKeepMemory candId="c3" state="posting"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-f-saved" label="Kept" width={AB_W} height={AB_H}>
          <PhoneAB><GIApproveSuccess candId="c3"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-f-strip" label="Posting survives leaving" width={AB_W} height={AB_H}>
          <PhoneAB>
            <div style={{ height: '100%', background: window.MOMORA.c.bg, paddingTop: 54, overflow: 'hidden' }}>
              <div style={{ padding: '6px 24px 0' }}>
                <Eyebrow color={window.MOMORA.c.ink3}>Sunday · May 25</Eyebrow>
                <Display size={34} style={{ marginTop: 10 }}>Your<br/>moments.</Display>
              </div>
              <div style={{ padding: '18px 20px 0', display: 'flex', flexDirection: 'column', gap: 10 }}>
                <GIPostingStrip/>
                <GIPostingStrip title="Paper hats and one lit cake" failed/>
              </div>
              <div style={{ padding: '14px 20px 0' }}>
                <MemoryCardSpread m={window.MOMORA_MOCK.memories[1]}/>
              </div>
              <TabBar active="timeline"/>
            </div>
          </PhoneAB>
        </DCArtboard>
      </DCSection>,

      <DCSection key="gi-settings" id="gi-settings" title="Gallery import · caption settings (owner only)"
        subtitle="A comprehensive BCP 47 list that is pleasant to search — by language, country, native name, or code — and a 500-character instruction field that is honest about what it can and cannot change.">
        <DCArtboard id="gi-s-main" label="Caption settings" width={AB_W} height={AB_H}>
          <PhoneAB><GICaptionSettings/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-s-filled" label="With instructions written" width={AB_W} height={AB_H}>
          <PhoneAB><GICaptionSettings initialTag="pt-BR" instructions="Escreva uma frase curta e simples. Chamamos a Lila de “Lilinha”. Sem exclamações."/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-s-picker" label="Language · browsing" width={AB_W} height={AB_H}>
          <PhoneAB><GICaptionSettings sheet="locale"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-s-picker-kb" label="Language · searching “pt”" width={AB_W} height={AB_H}>
          <PhoneKB>
            <div style={{ height: '100%', background: window.MOMORA.c.bg, position: 'relative', overflow: 'hidden' }}>
              <GILocalePicker current="en-GB" recent={['en-US']} query="pt"/>
            </div>
          </PhoneKB>
        </DCArtboard>
        <DCArtboard id="gi-s-picker-native" label="Language · searching “日本”" width={AB_W} height={AB_H}>
          <PhoneKB>
            <div style={{ height: '100%', background: window.MOMORA.c.bg, position: 'relative', overflow: 'hidden' }}>
              <GILocalePicker current="en-GB" query="日本"/>
            </div>
          </PhoneKB>
        </DCArtboard>
        <DCArtboard id="gi-s-picker-none" label="Language · no match" width={AB_W} height={AB_H}>
          <PhoneKB>
            <div style={{ height: '100%', background: window.MOMORA.c.bg, position: 'relative', overflow: 'hidden' }}>
              <GILocalePicker current="en-GB" query="klingon"/>
            </div>
          </PhoneKB>
        </DCArtboard>
      </DCSection>,

      <DCSection key="gi-states" id="gi-states" title="Gallery import · exceptional states"
        subtitle="One screen pattern, different words — and nothing technical or moralising anywhere. Anything that does not stop the parent stays inline instead.">
        <DCArtboard id="gi-x-device" label="Opened on another phone" width={AB_W} height={AB_H}>
          <PhoneAB><GIState kind="wrongDevice"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-x-lapsed" label="Subscription lapsed" width={AB_W} height={AB_H}>
          <PhoneAB><GIState kind="lapsed"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-x-demoted" label="No longer a manager" width={AB_W} height={AB_H}>
          <PhoneAB><GIState kind="demoted"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-x-removed" label="Removed from the family" width={AB_W} height={AB_H}>
          <PhoneAB><GIState kind="removed"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-x-limited" label="Limited photo access" width={AB_W} height={AB_H}>
          <PhoneAB><GIState kind="limited"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-x-skips" label="Quietly passed over" width={AB_W} height={AB_H}>
          <PhoneAB><GIState kind="quietSkips"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-x-err" label="Recoverable error" width={AB_W} height={AB_H}>
          <PhoneAB><GIState kind="errorRecoverable"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-x-final" label="Cannot be finished" width={AB_W} height={AB_H}>
          <PhoneAB><GIState kind="errorFinal"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-x-capped" label="Stopped at 18 events" width={AB_W} height={AB_H}>
          <PhoneAB><GIState kind="capped"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-x-offline" label="Offline" width={AB_W} height={AB_H}>
          <PhoneAB><GIState kind="offline"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="gi-x-notices" label="Inline notices" width={AB_W} height={AB_H}>
          <PhoneAB><GINoticeBoard/></PhoneAB>
        </DCArtboard>
      </DCSection>,

      <DCSection key="gi-notes" id="gi-notes" title="Gallery import · the written work"
        subtitle="Rationale, component recommendations, copy that materially affects trust, and the nine decisions an implementer should treat as spec.">
        <DCArtboard id="gi-n-system" label="Components &amp; state coverage" width={560} height={AB_H}>
          <GINoteSystem/>
        </DCArtboard>
        <DCArtboard id="gi-n-copy" label="Copy deck" width={560} height={AB_H}>
          <GINoteCopy/>
        </DCArtboard>
        <DCArtboard id="gi-n-questions" label="Decisions &amp; what is still open" width={560} height={AB_H}>
          <GINoteQuestions/>
        </DCArtboard>
      </DCSection>,

      <DCPostIt key="postit" top={54} right={44} rotate={2.5} width={224}>
        Review is for one decision only: keep or set aside. All editing lives in the memory composer the app already has.
      </DCPostIt>,
      ])}
    </DesignCanvas>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<GalleryCanvas/>);
