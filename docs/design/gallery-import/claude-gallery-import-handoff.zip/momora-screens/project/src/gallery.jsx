// Gallery import — mock data.
// Photo "tones" stand in for real camera-roll photos: warm washes, never fake characters.

window.GI_TONES = {
  snow:    { a: '#C3D0DE', b: '#A9BACB', c: '#E4DCCF' },
  garden:  { a: '#C6D3A5', b: '#A8BA82', c: '#E6DFB4' },
  kitchen: { a: '#E0C193', b: '#C7A272', c: '#F0E0C4' },
  cake:    { a: '#E5B9BF', b: '#CE96A4', c: '#F1D9C6' },
  rain:    { a: '#C2CCD9', b: '#A6B3C4', c: '#DFDBD5' },
  street:  { a: '#D8BFA6', b: '#B99C80', c: '#E9D9C2' },
  beach:   { a: '#E1D0A8', b: '#BFCDBB', c: '#EEE1C7' },
  sofa:    { a: '#D8C4D5', b: '#B9A2BC', c: '#E9DBCF' },
  bath:    { a: '#C3D6D8', b: '#A4BFC2', c: '#E3DCD1' },
  park:    { a: '#C7D7BE', b: '#A3BC9C', c: '#E7DFBF' },
};

let _pid = 0;
const ph = (scene, opts = {}) => ({ id: `p${++_pid}`, scene, seed: (_pid * 37) % 100 / 100, ...opts });

// A candidate = one staged suggestion. `pool` is every photo Momora found in that
// event (the local cluster); `selected` are the ids the vision pass chose.
// A Momora memory is one text field, so `caption` is the whole draft. `title` is
// kept only as a short internal label for lists — it is never shown as a heading.
window.GI_CANDIDATES = [
  {
    id: 'c1', title: 'Snow on the back steps',
    caption: 'A first snow morning — boots too big, mittens on the wrong hands, and a shovel that never made it off the porch.',
    date: '2024-01-14', dateLabel: 'Sunday, January 14, 2024', poolCount: 26,
    emotion: 'wonder',
    pool: [ph('snow'), ph('snow'), ph('snow'), ph('rain'), ph('snow'), ph('street'), ph('snow'), ph('rain')],
  },
  {
    id: 'c2', title: 'The long afternoon with the sprinkler',
    caption: 'One warm afternoon outside that went on and on. Wet hair, a towel on the grass, and nobody wanting to go in.',
    date: '2025-07-06', dateLabel: 'Sunday, July 6, 2025', poolCount: 41,
    emotion: 'joy',
    pool: [ph('garden'), ph('garden'), ph('park'), ph('garden'), ph('park'), ph('garden'), ph('beach'), ph('garden')],
  },
  {
    id: 'c3', title: 'Pancake Saturday',
    caption: 'Batter on the counter, a stool pulled up to the stove, and one pancake that came out almost round.',
    date: '2025-11-15', dateLabel: 'Saturday, November 15, 2025', poolCount: 9,
    emotion: 'tender',
    pool: [ph('kitchen'), ph('kitchen'), ph('kitchen'), ph('sofa'), ph('kitchen'), ph('kitchen')],
  },
  {
    id: 'c4', title: 'Paper hats and one lit cake',
    caption: 'Hats that would not stay on, a cake with candles, and the long pause right before they went out.',
    date: '2025-03-22', dateLabel: 'Saturday, March 22, 2025', poolCount: 63,
    emotion: 'joy',
    pool: [ph('cake'), ph('cake'), ph('kitchen'), ph('cake'), ph('sofa'), ph('cake'), ph('cake')],
  },
  {
    id: 'c5', title: 'Rain at the window',
    caption: 'A grey afternoon spent watching water run down the glass. Three photos, all nearly the same, all worth keeping.',
    date: '2026-02-03', dateLabel: 'Tuesday, February 3, 2026', poolCount: 7,
    emotion: 'calm',
    pool: [ph('rain'), ph('rain'), ph('rain'), ph('sofa'), ph('bath')],
  },
  {
    id: 'c6', title: 'An hour at the beach before the wind picked up',
    caption: 'Sand in everything, a jumper pulled on over a swimsuit, and the walk back to the car.',
    date: '2025-08-30', dateLabel: 'Saturday, August 30, 2025', poolCount: 34,
    emotion: 'wonder',
    pool: [ph('beach'), ph('beach'), ph('park'), ph('beach'), ph('beach'), ph('street')],
  },
  {
    id: 'c7', title: 'Reading on the sofa, twice in one day',
    caption: 'The same book in the morning light and again after dinner, with a different blanket.',
    date: '2025-12-07', dateLabel: 'Sunday, December 7, 2025', poolCount: 12,
    emotion: 'calm',
    pool: [ph('sofa'), ph('sofa'), ph('bath'), ph('sofa'), ph('sofa')],
  },
  {
    id: 'c8', title: 'New shoes on the front step',
    caption: 'Sat down on the step to look at them properly before walking anywhere.',
    date: '2026-04-11', dateLabel: 'Saturday, April 11, 2026', poolCount: 5,
    emotion: 'tender',
    pool: [ph('street'), ph('street'), ph('garden'), ph('street')],
  },
];
window.GI_CANDIDATES.forEach(c => { c.selected = c.pool.slice(0, Math.min(4, c.pool.length)).map(p => p.id); });
window.giCandidate = (id) => window.GI_CANDIDATES.find(c => c.id === id);

// A memory is one block of text — no title. Rows that need a label use the
// first clause of the caption.
window.giExcerpt = (text = '', max = 42) => {
  const first = text.split(/[.—–]/)[0].trim();
  return first.length > max ? first.slice(0, max).trim() + '…' : first;
};

// Set-aside (skipped) suggestions — recoverable until the run expires.
window.GI_SET_ASIDE = [
  { id: 's1', text: 'A wet Tuesday in the car park, waiting for the rain to stop.', date: '2025-05-19', scene: 'rain', when: 'Set aside just now' },
  { id: 's2', text: 'Three photos of the same slide, taken seconds apart.', date: '2024-06-14', scene: 'park', when: 'Set aside 2 minutes ago' },
  { id: 's3', text: 'A grey walk home, nothing much happening.', date: '2025-09-02', scene: 'street', when: 'Set aside yesterday' },
];

// Run-level counters used by progress + review surfaces.
window.GI_RUN = {
  photosSeen: 8412, yearsSpan: '2019 – 2026',
  eventsFound: 96, ready: 12, processing: 8, kept: 4, setAside: 3,
  reviewDays: 30, previewsPrepared: 214, previewsTotal: 388, uploadedMb: 46,
};

// ── Locale registry (subset of BCP 47 / CLDR, enough to exercise search) ──
window.GI_LOCALES = [
  ['en-US','English','United States'],['en-GB','English','United Kingdom'],
  ['en-AU','English','Australia'],['en-CA','English','Canada'],['en-IE','English','Ireland'],
  ['en-IN','English','India'],['en-NZ','English','New Zealand'],['en-ZA','English','South Africa'],
  ['pt-BR','Portuguese','Brazil','português (Brasil)'],['pt-PT','Portuguese','Portugal','português (Portugal)'],
  ['es-ES','Spanish','Spain','español (España)'],['es-MX','Spanish','Mexico','español (México)'],
  ['es-AR','Spanish','Argentina'],['es-CO','Spanish','Colombia'],['es-US','Spanish','United States'],
  ['fr-FR','French','France','français (France)'],['fr-CA','French','Canada','français (Canada)'],
  ['fr-BE','French','Belgium'],['fr-CH','French','Switzerland'],
  ['de-DE','German','Germany','Deutsch (Deutschland)'],['de-AT','German','Austria','Deutsch (Österreich)'],
  ['de-CH','German','Switzerland','Deutsch (Schweiz)'],
  ['it-IT','Italian','Italy','italiano'],['it-CH','Italian','Switzerland'],
  ['nl-NL','Dutch','Netherlands','Nederlands'],['nl-BE','Dutch','Belgium','Nederlands (België)'],
  ['sv-SE','Swedish','Sweden','svenska'],['nb-NO','Norwegian Bokmål','Norway','norsk bokmål'],
  ['da-DK','Danish','Denmark','dansk'],['fi-FI','Finnish','Finland','suomi'],['is-IS','Icelandic','Iceland','íslenska'],
  ['pl-PL','Polish','Poland','polski'],['cs-CZ','Czech','Czechia','čeština'],['sk-SK','Slovak','Slovakia','slovenčina'],
  ['hu-HU','Hungarian','Hungary','magyar'],['ro-RO','Romanian','Romania','română'],['bg-BG','Bulgarian','Bulgaria','български'],
  ['el-GR','Greek','Greece','Ελληνικά'],['tr-TR','Turkish','Türkiye','Türkçe'],
  ['ru-RU','Russian','Russia','русский'],['uk-UA','Ukrainian','Ukraine','українська'],
  ['he-IL','Hebrew','Israel','עברית'],['ar-SA','Arabic','Saudi Arabia','العربية'],
  ['ar-EG','Arabic','Egypt','العربية (مصر)'],['ar-MA','Arabic','Morocco'],['fa-IR','Persian','Iran','فارسی'],
  ['hi-IN','Hindi','India','हिन्दी'],['bn-BD','Bengali','Bangladesh','বাংলা'],['bn-IN','Bengali','India'],
  ['ta-IN','Tamil','India','தமிழ்'],['te-IN','Telugu','India','తెలుగు'],['mr-IN','Marathi','India','मराठी'],
  ['gu-IN','Gujarati','India','ગુજરાતી'],['pa-IN','Punjabi','India','ਪੰਜਾਬੀ'],['ur-PK','Urdu','Pakistan','اردو'],
  ['ne-NP','Nepali','Nepal','नेपाली'],['si-LK','Sinhala','Sri Lanka','සිංහල'],
  ['th-TH','Thai','Thailand','ไทย'],['vi-VN','Vietnamese','Vietnam','Tiếng Việt'],
  ['id-ID','Indonesian','Indonesia','Bahasa Indonesia'],['ms-MY','Malay','Malaysia','Bahasa Melayu'],
  ['fil-PH','Filipino','Philippines','Filipino'],['km-KH','Khmer','Cambodia','ខ្មែរ'],
  ['lo-LA','Lao','Laos','ລາວ'],['my-MM','Burmese','Myanmar','မြန်မာ'],['mn-MN','Mongolian','Mongolia','монгол'],
  ['ko-KR','Korean','South Korea','한국어'],['ja-JP','Japanese','Japan','日本語'],
  ['zh-Hans-CN','Chinese (Simplified)','China','简体中文'],['zh-Hant-TW','Chinese (Traditional)','Taiwan','繁體中文'],
  ['zh-Hant-HK','Chinese (Traditional)','Hong Kong SAR','繁體中文（香港）'],
  ['ca-ES','Catalan','Spain','català'],['eu-ES','Basque','Spain','euskara'],['gl-ES','Galician','Spain','galego'],
  ['et-EE','Estonian','Estonia','eesti'],['lv-LV','Latvian','Latvia','latviešu'],['lt-LT','Lithuanian','Lithuania','lietuvių'],
  ['sl-SI','Slovenian','Slovenia','slovenščina'],['hr-HR','Croatian','Croatia','hrvatski'],
  ['sr-RS','Serbian','Serbia','српски'],['mk-MK','Macedonian','North Macedonia','македонски'],
  ['sq-AL','Albanian','Albania','shqip'],['ka-GE','Georgian','Georgia','ქართული'],['hy-AM','Armenian','Armenia','հայերեն'],
  ['kk-KZ','Kazakh','Kazakhstan','қазақ тілі'],['uz-Latn-UZ','Uzbek','Uzbekistan','oʻzbek'],
  ['af-ZA','Afrikaans','South Africa','Afrikaans'],['zu-ZA','Zulu','South Africa','isiZulu'],
  ['sw-KE','Swahili','Kenya','Kiswahili'],['am-ET','Amharic','Ethiopia','አማርኛ'],
  ['yo-NG','Yoruba','Nigeria','Yorùbá'],['ha-NG','Hausa','Nigeria','Hausa'],['ig-NG','Igbo','Nigeria','Asụsụ Igbo'],
].map(([tag, name, region, native]) => ({
  tag, name, region, native: native || null,
  label: `${name} (${region})`,
}));

window.giSearchLocales = (q) => {
  const s = q.trim().toLowerCase();
  if (!s) return window.GI_LOCALES;
  return window.GI_LOCALES.filter(l =>
    l.tag.toLowerCase().includes(s) || l.name.toLowerCase().includes(s) ||
    l.region.toLowerCase().includes(s) || (l.native || '').toLowerCase().includes(s)
  );
};

window.giFmtDate = (iso) =>
  new Date(iso + 'T12:00:00').toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
window.giFmtShort = (iso) =>
  new Date(iso + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
