// Gallery import — caption settings (family owner only).
const { c: LC, f: LF } = window.MOMORA;

function GICaptionSettings({
  platform = 'ios', sheet: initialSheet, initialTag = 'en-GB', instructions: init = '',
  onBack = () => {},
}) {
  const [tag, setTag] = React.useState(initialTag);
  const [sheet, setSheet] = React.useState(initialSheet || null);
  const [text, setText] = React.useState(init);
  const [recent, setRecent] = React.useState(['en-US', 'pt-BR']);
  const loc = window.GI_LOCALES.find(l => l.tag === tag) || window.GI_LOCALES[0];
  const MAX = 500;

  const sample = {
    'en-GB': 'A grey afternoon spent watching the rain run down the glass.',
    'en-US': 'A gray afternoon spent watching the rain run down the glass.',
    'pt-BR': 'Uma tarde cinzenta olhando a chuva escorrer no vidro.',
    'pt-PT': 'Uma tarde cinzenta a ver a chuva a escorrer no vidro.',
    'es-MX': 'Una tarde gris viendo la lluvia correr por el vidrio.',
  }[tag] || `A short warm caption, written in ${loc.label}.`;

  return (
    <div style={{ height: '100%', background: LC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', boxSizing: 'border-box', paddingBottom: 60 }}>
        <GITopBar left="Settings" onLeft={onBack} platform={platform} onBack={onBack}/>
        <div style={{ padding: '8px 24px 0' }}>
          <Eyebrow>Family owner only</Eyebrow>
          <Display size={34} style={{ marginTop: 12 }}>How captions<br/>are written.</Display>
          <Body size={14} muted style={{ marginTop: 13, lineHeight: 1.6 }}>
            This is for the drafts Momora writes from your photos. It applies to everyone in the
            family, so the journal reads in one voice.
          </Body>
        </div>

        {/* language */}
        <div style={{ padding: '26px 20px 0' }}>
          <GIRule style={{ marginBottom: 10 }}>Language</GIRule>
          <button onClick={() => setSheet('locale')} style={{
            width: '100%', textAlign: 'left', background: '#fff', border: `1px solid ${LC.border}`,
            borderRadius: 16, padding: '15px 16px', display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer',
          }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <Body size={15} style={{ fontWeight: 700 }}>{loc.label}</Body>
              <Body size={12.5} muted style={{ marginTop: 3, fontFamily: LF.mono }}>{loc.tag}{loc.native ? ` · ${loc.native}` : ''}</Body>
            </div>
            <Icon name="chevronDown" size={17} color={LC.ink3} strokeWidth={2}/>
          </button>
          <Body size={12} muted style={{ marginTop: 9, lineHeight: 1.5, paddingLeft: 2 }}>
            Regional variants matter — {'“'}colour{'”'} or {'“'}color{'”'}, {'“'}nappy{'”'} or {'“'}diaper{'”'}.
          </Body>
        </div>

        {/* instructions */}
        <div style={{ padding: '26px 20px 0' }}>
          <GIRule style={{ marginBottom: 10 }}>Your own instructions</GIRule>
          <div style={{ background: '#fff', border: `1px solid ${LC.border}`, borderRadius: 16, padding: 14 }}>
            <Input multiline rows={4} value={text} onChange={(v) => setText(v.slice(0, MAX))}
              placeholder="For example: keep captions to one short sentence, and call the little one Bear."
              style={{ border: 'none', padding: 0, background: 'transparent', fontSize: 14.5 }}/>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 10, paddingTop: 10, borderTop: `1px solid ${LC.border}` }}>
              <Body size={11.5} muted style={{ flex: 1 }}>
                Nicknames, tone, how formal — the wording is yours.
              </Body>
              <Body size={11.5} style={{
                fontFamily: LF.mono, color: text.length > MAX - 50 ? LC.primary : LC.ink3,
              }}>{text.length}/{MAX}</Body>
            </div>
          </div>

          <div style={{ marginTop: 14, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {[
              'Keep it to one short sentence.',
              'We call the baby Bear.',
              'No exclamation marks.',
              'Use British spelling.',
            ].map(ex => (
              <GIPill key={ex} tone="soft" onClick={() => setText(t => (t ? `${t} ${ex}` : ex).slice(0, MAX))}>
                + {ex}
              </GIPill>
            ))}
          </div>
        </div>

        {/* what it can and cannot do — trust, stated plainly */}
        <div style={{ padding: '26px 20px 0' }}>
          <div style={{ background: LC.surface, borderRadius: 16, padding: 16 }}>
            <Body size={13.5} style={{ fontWeight: 700 }}>What your instructions change</Body>
            <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 7 }}>
              {['The language and regional spelling', 'How long and how formal a caption is', 'Words you prefer, like nicknames or “our girls”'].map(s => (
                <div key={s} style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                  <Icon name="check" size={14} color={LC.success} strokeWidth={2.6} style={{ marginTop: 2, flexShrink: 0 }}/>
                  <Body size={12.5} muted style={{ lineHeight: 1.45 }}>{s}</Body>
                </div>
              ))}
            </div>
            <div style={{ height: 1, background: LC.border, margin: '14px 0' }}/>
            <Body size={13.5} style={{ fontWeight: 700 }}>What they cannot change</Body>
            <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 7 }}>
              {['Which photos Momora suggests', 'Facts — it will not invent names, places or occasions', 'Anything about your privacy or what is uploaded'].map(s => (
                <div key={s} style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                  <Icon name="x" size={14} color={LC.ink3} strokeWidth={2.4} style={{ marginTop: 2, flexShrink: 0 }}/>
                  <Body size={12.5} muted style={{ lineHeight: 1.45 }}>{s}</Body>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* live example */}
        <div style={{ padding: '20px 20px 0' }}>
          <GIRule style={{ marginBottom: 10 }}>An example draft</GIRule>
          <div style={{ background: '#fff', border: `1px solid ${LC.border}`, borderRadius: 16, padding: 14, display: 'flex', gap: 12 }}>
            <GIPhoto scene="rain" seed={.5} radius={10} style={{ width: 62, height: 62, flexShrink: 0 }}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <Body size={13.5} style={{ fontWeight: 700 }}>Rain at the window</Body>
              <Body size={13} muted style={{ marginTop: 4, lineHeight: 1.5 }}>{sample}</Body>
            </div>
          </div>
          <Body size={11.5} muted style={{ marginTop: 10, lineHeight: 1.5 }}>
            Changes apply to new drafts. Captions you have already edited stay as you wrote them.
          </Body>
        </div>
        <div style={{ height: 40 }}/>
      </div>

      {sheet === 'locale' && (
        <GILocalePicker current={tag} recent={recent}
          onPick={(t) => { setRecent(r => [tag, ...r.filter(x => x !== tag && x !== t)].slice(0, 3)); setTag(t); setSheet(null); }}
          onClose={() => setSheet(null)}/>
      )}
    </div>
  );
}

// ── The searchable locale combobox ───────────────────────────────
function GILocalePicker({ current = 'en-GB', recent = [], onPick = () => {}, onClose = () => {}, query: q0 = '' }) {
  const [q, setQ] = React.useState(q0);
  const results = window.giSearchLocales(q);
  const cur = window.GI_LOCALES.find(l => l.tag === current);
  const searching = q.trim().length > 0;

  // Alphabetical groups by language name; regions stay together under it.
  const groups = React.useMemo(() => {
    const out = [];
    let letter = null;
    results.forEach(l => {
      const ch = l.name[0].toUpperCase();
      if (ch !== letter) { letter = ch; out.push({ head: ch }); }
      out.push({ loc: l });
    });
    return out;
  }, [q]);

  const Row = (l, badge) => {
    const on = l.tag === current;
    return (
      <button key={`${badge || 'all'}-${l.tag}`} onClick={() => onPick(l.tag)} role="option" aria-selected={on}
        style={{
          width: '100%', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 12,
          padding: '11px 24px', border: 'none', background: on ? LC.primaryTint : 'transparent',
          cursor: 'pointer', WebkitTapHighlightColor: 'transparent',
        }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 7, flexWrap: 'wrap' }}>
            <span style={{ fontFamily: LF.sans, fontSize: 15, fontWeight: on ? 700 : 600, color: on ? LC.primary : LC.ink }}>
              {l.name}
            </span>
            <span style={{ fontFamily: LF.sans, fontSize: 13, color: LC.ink3 }}>{l.region}</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 2 }}>
            {l.native && <span style={{ fontFamily: LF.sans, fontSize: 12.5, color: LC.ink2 }}>{l.native}</span>}
            <span style={{ fontFamily: LF.mono, fontSize: 11, color: LC.ink3 }}>{l.tag}</span>
          </div>
        </div>
        {on && <Icon name="check" size={17} color={LC.primary} strokeWidth={2.6}/>}
      </button>
    );
  };

  return (
    <React.Fragment>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, zIndex: 40, background: 'rgba(36,28,18,0.34)', animation: 'giFade 200ms ease-out both',
      }}/>
      <div role="dialog" aria-label="Caption language" style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, top: 60, zIndex: 41,
        display: 'flex', flexDirection: 'column', background: '#fff',
        borderTopLeftRadius: 24, borderTopRightRadius: 24, overflow: 'hidden',
        boxShadow: '0 -14px 44px rgba(40,30,20,0.22)', animation: 'giSlide 320ms cubic-bezier(.22,.61,.36,1) both',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '10px 0 2px' }}>
          <div style={{ width: 38, height: 5, borderRadius: 999, background: LC.border }}/>
        </div>
        <div style={{ padding: '6px 24px 0', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
          <Title size={22}>Caption language</Title>
          <button onClick={onClose} style={{
            border: 'none', background: 'transparent', cursor: 'pointer', padding: '4px 0',
            fontFamily: LF.sans, fontSize: 14.5, fontWeight: 700, color: LC.primary,
          }}>Cancel</button>
        </div>

        {/* search — language, region, native name, or code */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, margin: '12px 24px 0',
          background: LC.surface, border: `1px solid ${LC.border}`, borderRadius: 12, padding: '11px 12px',
        }}>
          <Icon name="search" size={16} color={LC.ink3} strokeWidth={2}/>
          <input value={q} onChange={e => setQ(e.target.value)} autoFocus
            placeholder="Language, country, or code — try “pt” or “Brasil”"
            aria-label="Search languages"
            style={{
              flex: 1, border: 'none', outline: 'none', background: 'transparent',
              fontFamily: LF.sans, fontSize: 15, color: LC.ink, minWidth: 0,
            }}/>
          {q && (
            <button onClick={() => setQ('')} aria-label="Clear search" style={{
              border: 'none', background: 'none', cursor: 'pointer', padding: 0, display: 'flex',
            }}>
              <Icon name="x" size={15} color={LC.ink3} strokeWidth={2.25}/>
            </button>
          )}
        </div>
        <div style={{ padding: '8px 24px 6px' }}>
          <Body size={11.5} muted>
            {searching
              ? `${results.length} match${results.length === 1 ? '' : 'es'}`
              : `${window.GI_LOCALES.length} languages and regional variants`}
          </Body>
        </div>

        <div role="listbox" style={{ flex: 1, overflowY: 'auto', minHeight: 0, paddingBottom: 24 }}>
          {!searching && (
            <React.Fragment>
              <GroupHead>Current</GroupHead>
              {cur && Row(cur, 'cur')}
              {recent.length > 0 && <GroupHead>Recently used</GroupHead>}
              {recent.map(t => {
                const l = window.GI_LOCALES.find(x => x.tag === t);
                return l ? Row(l, 'recent') : null;
              })}
              <GroupHead>All languages</GroupHead>
            </React.Fragment>
          )}
          {results.length === 0 ? (
            <div style={{ padding: '34px 24px', textAlign: 'center' }}>
              <Body size={14} muted>No language matches “{q}”.</Body>
              <Body size={12.5} muted style={{ marginTop: 6 }}>
                Try the country instead, or a code like <span style={{ fontFamily: LF.mono }}>pt-BR</span>.
              </Body>
            </div>
          ) : searching ? (
            results.map(l => Row(l, 'q'))
          ) : (
            groups.map((g, i) => g.head
              ? <div key={`h${i}`} style={{
                  position: 'sticky', top: 0, zIndex: 2, background: 'rgba(255,255,255,0.94)',
                  backdropFilter: 'blur(8px)', padding: '7px 24px 5px',
                  fontFamily: LF.sans, fontSize: 11, fontWeight: 700, letterSpacing: '0.12em',
                  color: LC.ink3, borderBottom: `1px solid ${LC.border}`,
                }}>{g.head}</div>
              : Row(g.loc))
          )}
        </div>
      </div>
    </React.Fragment>
  );
}

function GroupHead({ children }) {
  return (
    <div style={{
      padding: '14px 24px 6px', fontFamily: LF.sans, fontSize: 11, fontWeight: 700,
      letterSpacing: '0.12em', textTransform: 'uppercase', color: LC.ink3,
    }}>{children}</div>
  );
}

Object.assign(window, { GICaptionSettings, GILocalePicker });
