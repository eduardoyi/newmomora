// Gallery import — the clickable end-to-end prototype.
// Offer → explainer → OS prompt → progress → deck → final review → saved → rest.
function GIPrototype({ start = 'offer', platform = 'ios', reduced = false }) {
  const [route, setRoute] = React.useState(start);
  const [stage, setStage] = React.useState('scanning');
  const [deckIdx, setDeckIdx] = React.useState(0);
  const [candId, setCandId] = React.useState('c1');
  const [keeps, setKeeps] = React.useState(0);

  // Progress advances on its own — the parent is free to leave at any point.
  React.useEffect(() => {
    if (route !== 'progress') return;
    const chain = { scanning: ['preparing', 2000], preparing: ['uploading', 2200], uploading: ['processing', 1800] };
    const next = chain[stage];
    if (!next) return;
    const t = setTimeout(() => setStage(next[0]), next[1]);
    return () => clearTimeout(t);
  }, [route, stage]);

  const toDeck = () => setRoute('deck');

  if (route === 'offer') return (
    <GIOffer platform={platform} onStart={() => setRoute('explainer')} onLater={() => setRoute('timeline-idle')}/>
  );

  if (route === 'explainer') return (
    <GIExplainer platform={platform} onContinue={() => setRoute('prompt')} onCancel={() => setRoute('offer')}/>
  );

  if (route === 'prompt') return (
    <GIOSPrompt platform={platform}
      onFull={() => { setStage('scanning'); setRoute('progress'); }}
      onLimited={() => setRoute('limited')}
      onDeny={() => setRoute('denied')}/>
  );

  if (route === 'limited') return (
    <GIPermissionOutcome kind="limited" platform={platform}
      onPrimary={() => { setStage('scanning'); setRoute('progress'); }}
      onSecondary={() => setRoute('prompt')}/>
  );

  if (route === 'denied') return (
    <GIPermissionOutcome kind="denied" platform={platform}
      onPrimary={() => setRoute('prompt')} onSecondary={() => setRoute('timeline-idle')}/>
  );

  if (route === 'progress') return (
    <GIProgressScreen stage={stage} platform={platform}
      onReview={toDeck} onClose={() => setRoute('timeline-run')}
      onStage={(s) => { if (s === 'cancelled') { setStage('cancelled'); } else setStage(s); }}/>
  );

  if (route === 'deck') return (
    <GIDeckPrint startIndex={deckIdx} platform={platform} reduced={reduced}
      onKeep={(c) => { setCandId(c.id); setDeckIdx(i => i + 1); setRoute('final'); }}
      onAside={() => setDeckIdx(i => i + 1)}
      onClose={() => setRoute('timeline-run')}
      onDone={() => setRoute('timeline-run')}/>
  );

  if (route === 'final') return (
    <GIKeepMemory candId={candId} platform={platform}
      onBack={toDeck}
      onSave={() => { setKeeps(k => k + 1); setRoute('saved'); }}/>
  );

  if (route === 'saved') return (
    <GIApproveSuccess candId={candId} platform={platform} nextCount={Math.max(0, 12 - deckIdx)}
      onNext={() => setRoute(keeps > 0 && keeps % 3 === 0 ? 'rest' : 'deck')}
      onStop={() => setRoute('timeline-run')}/>
  );

  if (route === 'rest') return (
    <GIRestPoint kept={keeps} left={Math.max(0, 12 - deckIdx)} platform={platform}
      onContinue={toDeck} onStop={() => setRoute('timeline-run')}/>
  );

  // Back in the app: an untouched journal shows the invitation, a live run shows
  // the import glyph beside Search.
  if (route === 'timeline-idle') return (
    <GITimelineWithBanner state="invite" onOpen={() => setRoute('offer')}/>
  );
  return (
    <GITimelineWithBanner
      state={keeps > 0 ? 'resume' : 'processing'}
      onOpen={() => (keeps > 0 ? toDeck() : setRoute('progress'))}/>
  );
}

window.GIPrototype = GIPrototype;
