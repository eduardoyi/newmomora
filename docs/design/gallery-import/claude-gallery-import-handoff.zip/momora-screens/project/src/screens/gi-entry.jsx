// Gallery import — discovery and entry points.
const { c: EC, f: EF } = window.MOMORA;

// ── The optional offer, right after onboarding ─────────────────────
// One screen, one idea: the years are already on your phone.
function GIOffer({ onStart = () => {}, onLater = () => {}, platform = 'ios' }) {
  const R = window.GI_RUN;
  const strip = [
    { scene: 'snow', seed: .2 }, { scene: 'garden', seed: .5 }, { scene: 'cake', seed: .7 },
    { scene: 'beach', seed: .3 }, { scene: 'kitchen', seed: .6 },
  ];
  return (
    <div style={{ height: '100%', background: EC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', boxSizing: 'border-box', paddingBottom: 208 }}>
        <GITopBar left="Not now" onLeft={onLater} platform={platform} onBack={onLater}/>
        <div style={{ padding: '10px 24px 0' }}>
          <Eyebrow>Before you start writing</Eyebrow>
          <Display size={38} style={{ marginTop: 12 }}>Some of it is<br/>already on<br/><em style={{ fontStyle: 'italic', color: EC.primary }}>your phone.</em></Display>
          <Body size={15} muted style={{ marginTop: 16, lineHeight: 1.6, maxWidth: 320 }}>
            Momora can look through the photos you already have and suggest a handful
            of moments worth keeping. You decide which ones become memories.
          </Body>
        </div>

        {/* the promise, shown as a stack of prints on a table */}
        <div style={{ margin: '26px 0 0', padding: '0 24px', position: 'relative', height: 214 }}>
          <div style={{ position: 'absolute', left: 44, right: 44, top: 16, bottom: 22, background: '#fff', border: `1px solid ${EC.border}`, borderRadius: 18, transform: 'rotate(-4deg)' }}/>
          <div style={{ position: 'absolute', left: 36, right: 36, top: 10, bottom: 26, background: '#fff', border: `1px solid ${EC.border}`, borderRadius: 18, transform: 'rotate(2.4deg)' }}/>
          <div style={{
            position: 'absolute', left: 24, right: 24, top: 0, bottom: 18, background: '#fff',
            border: `1px solid ${EC.border}`, borderRadius: 18, padding: 12,
            boxShadow: '0 18px 34px rgba(40,30,20,0.10)', transform: 'rotate(-1deg)',
          }}>
            <GIPhoto scene="garden" seed={.45} radius={12} style={{ width: '100%', height: 118 }} stamp="jul 2025"/>
            <div style={{ marginTop: 10, display: 'flex', gap: 6 }}>
              {strip.slice(0, 4).map((s, i) => (
                <GIPhoto key={i} scene={s.scene} seed={s.seed} radius={7} style={{ flex: 1, height: 34 }}/>
              ))}
            </div>
          </div>
        </div>

        <div style={{ padding: '22px 24px 0', display: 'flex', flexDirection: 'column', gap: 14 }}>
          <GIFact icon="search" title="It looks for events, not good photos">
            Days with a lot going on — a snowy morning, an afternoon outside — grouped
            the way you would remember them.
          </GIFact>
          <GIFact icon="image" title="Nothing is deleted or tidied up">
            Momora only reads your library. Your camera roll stays exactly as it is.
          </GIFact>
          <GIFact icon="check" title="Nothing is added without you">
            You look at each suggestion and keep the ones you want. The rest quietly go away.
          </GIFact>
        </div>
      </div>

      <GIActionBar platform={platform}>
        <Button onClick={onStart} style={{ width: '100%' }}>Look through my photos</Button>
        <Button variant="ghost" onClick={onLater} style={{ width: '100%' }}>Maybe later</Button>
        <Body size={11.5} muted style={{ textAlign: 'center', marginTop: 2 }}>
          You can start this any time from Settings.
        </Body>
      </GIActionBar>
    </div>
  );
}

// ── Persistent entry: the Settings row ────────────────────────────
function GISettingsEntry({ state = 'idle', onOpen = () => {} }) {
  const R = window.GI_RUN;
  const copy = {
    idle:       { label: 'Find memories in your photos', caption: 'Look through your camera roll for moments worth keeping.', pill: null },
    running:    { label: 'Find memories in your photos', caption: 'Looking through your photos — you can close Momora.', pill: <GIPill tone="sea">{R.ready} ready</GIPill> },
    ready:      { label: 'Find memories in your photos', caption: `${R.ready} suggestions waiting for you.`, pill: <GIPill tone="primary">Ready</GIPill> },
    unavailable:{ label: 'Find memories in your photos', caption: 'Only the family owner or a manager can start this.', pill: null, dim: true },
  }[state];
  return (
    <div style={{ height: '100%', background: EC.bg, position: 'relative', overflow: 'hidden', paddingTop: 54 }}>
      <div style={{ padding: '6px 24px 0' }}>
        <Eyebrow color={EC.ink3}>Account</Eyebrow>
        <Display size={40} style={{ marginTop: 8 }}>Settings.</Display>
      </div>
      <div style={{ padding: '26px 20px 0' }}>
        <Eyebrow color={EC.ink3} style={{ fontSize: 10, marginBottom: 10 }}>Your journal</Eyebrow>
        <div style={{ background: '#fff', border: `1px solid ${EC.border}`, borderRadius: 16, overflow: 'hidden' }}>
          <button onClick={onOpen} disabled={copy.dim} style={{
            width: '100%', textAlign: 'left', border: 'none', background: 'transparent',
            padding: '15px 16px', display: 'flex', alignItems: 'center', gap: 13,
            cursor: copy.dim ? 'default' : 'pointer', opacity: copy.dim ? 0.55 : 1,
          }}>
            <div style={{
              width: 38, height: 38, borderRadius: 12, background: EC.primaryTint,
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Icon name="layers" size={18} color={EC.primary} strokeWidth={1.9}/>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <Body size={14.5} style={{ fontWeight: 700 }}>{copy.label}</Body>
              <Body size={12.5} muted style={{ marginTop: 3, lineHeight: 1.4 }}>{copy.caption}</Body>
            </div>
            {copy.pill}
            {!copy.pill && <Icon name="chevronRight" size={16} color={EC.ink3}/>}
          </button>
          <div style={{ borderTop: `1px solid ${EC.border}`, padding: '15px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ flex: 1 }}>
              <Body size={14.5} style={{ fontWeight: 600 }}>Photo caption language</Body>
              <Body size={12.5} muted style={{ marginTop: 3 }}>English (UK) · owner only</Body>
            </div>
            <Icon name="chevronRight" size={16} color={EC.ink3}/>
          </div>
          <div style={{ borderTop: `1px solid ${EC.border}`, padding: '15px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ flex: 1 }}><Body size={14.5} style={{ fontWeight: 600 }}>Export your journal</Body></div>
            <Icon name="chevronRight" size={16} color={EC.ink3}/>
          </div>
        </div>
        {state === 'unavailable' && (
          <Body size={12.5} muted style={{ marginTop: 12, lineHeight: 1.5 }}>
            Ask {'Mateo'} — they manage this family — to bring in older photos.
          </Body>
        )}
      </div>
      <TabBar active="settings"/>
    </div>
  );
}

// ── Returning to the app ──────────────────────────────────────────
// Run status does not take over the Timeline. It lives behind a small import
// glyph next to Search, which carries a quiet dot when there is news.
function GIImportGlyph({ size = 19, color = EC.ink2 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color}
      strokeWidth="1.85" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 3v9"/><path d="M8.5 8.5L12 12l3.5-3.5"/>
      <path d="M4 15v3a2 2 0 002 2h12a2 2 0 002-2v-3"/>
    </svg>
  );
}

// state: none | processing | ready | resume | attention | expiring
function GIImportButton({ state = 'ready', onClick = () => {}, style = {} }) {
  const dot = {
    processing: EC.sea, ready: EC.primary, resume: EC.primary,
    attention: EC.sun, expiring: EC.sun, none: null,
  }[state];
  const label = {
    processing: 'Photo suggestions, still working',
    ready: `Photo suggestions ready, ${window.GI_RUN.ready} waiting`,
    resume: 'Photo suggestions, pick up where you left off',
    attention: 'Photo suggestions need your attention',
    expiring: 'Photo suggestions ending soon',
    none: 'Find memories in your photos',
  }[state];
  return (
    <button onClick={onClick} aria-label={label} title={label} style={{
      position: 'relative', width: 38, height: 38, borderRadius: '50%', background: '#fff',
      border: `1px solid ${EC.border}`, cursor: 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, ...style,
    }}>
      <GIImportGlyph/>
      {dot && (
        <span className={state === 'processing' ? 'gi-anim-breathe' : undefined} style={{
          position: 'absolute', top: 1, right: 1, width: 10, height: 10, borderRadius: 999,
          background: dot, border: '2px solid #fff', boxSizing: 'content-box',
        }}/>
      )}
    </button>
  );
}

// The drawer behind that glyph — one status, one action, nothing shouted.
function GIImportDrawer({ state = 'ready', onOpen = () => {}, onClose = () => {}, onSettings = () => {} }) {
  const R = window.GI_RUN;
  const map = {
    processing: {
      eyebrow: 'Looking through your photos', tone: EC.sea,
      title: `${R.ready} suggestions ready so far`,
      sub: 'Still looking through the rest. Safe to close Momora.',
      cta: 'Start reviewing', bar: <GIProgress indeterminate tone={EC.sea}/>,
    },
    ready: {
      eyebrow: 'Ready when you are', tone: EC.primary,
      title: `${R.ready} suggestions from your photos`,
      sub: `From ${R.yearsSpan}. Keep the ones you want — no rush.`,
      cta: 'Review suggestions', bar: null,
    },
    resume: {
      eyebrow: 'Where you left off', tone: EC.primary,
      title: '8 suggestions left to look at',
      sub: '4 kept so far. Your place is saved.',
      cta: 'Pick up where you left off', bar: <GIProgress value={4} total={12}/>,
    },
    attention: {
      eyebrow: 'Waiting for Wi-Fi', tone: EC.sunInk,
      title: 'Paused until you are on Wi-Fi',
      sub: 'Momora will carry on by itself. Or use cellular data now.',
      cta: 'See options', bar: null,
    },
    expiring: {
      eyebrow: 'Ending soon', tone: EC.sunInk,
      title: '3 set aside, 4 days left',
      sub: 'After that the suggestions clear, and your camera roll is untouched.',
      cta: 'Take a last look', bar: null,
    },
  }[state];
  return (
    <GISheet title="From your photos" onClose={onClose} closeLabel="Close">
      <div style={{ padding: '14px 24px 26px' }}>
        <div style={{ background: '#fff', border: `1px solid ${EC.border}`, borderRadius: 16, padding: 15 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {state === 'processing' && <span className="gi-anim-breathe" style={{ width: 7, height: 7, borderRadius: 999, background: EC.sea }}/>}
            <Eyebrow color={map.tone} style={{ fontSize: 10 }}>{map.eyebrow}</Eyebrow>
          </div>
          <Title size={19} style={{ marginTop: 8, lineHeight: 1.15 }}>{map.title}</Title>
          <Body size={13} muted style={{ marginTop: 5, lineHeight: 1.5 }}>{map.sub}</Body>
          {map.bar && <div style={{ marginTop: 12 }}>{map.bar}</div>}
          <div style={{ marginTop: 13, display: 'flex', alignItems: 'center', gap: 10 }}>
            <GIThumbRow size={36} radius={7} photos={window.GI_CANDIDATES[0].pool.slice(0, 3)}
              more={state === 'ready' ? 9 : 0}/>
            <div style={{ flex: 1 }}/>
            <Button size="sm" onClick={onOpen}>{map.cta}</Button>
          </div>
        </div>

        <div style={{ marginTop: 14, background: EC.surface, borderRadius: 14, overflow: 'hidden' }}>
          <button onClick={onSettings} style={{
            width: '100%', textAlign: 'left', background: 'transparent', border: 'none',
            padding: '13px 14px', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer',
          }}>
            <Icon name="settings" size={16} color={EC.ink2} strokeWidth={1.8}/>
            <Body size={13.5} style={{ flex: 1, fontWeight: 600 }}>How captions are written</Body>
            <Icon name="chevronRight" size={15} color={EC.ink3}/>
          </button>
          <div style={{ borderTop: `1px solid ${EC.border}`, padding: '13px 14px', display: 'flex', alignItems: 'center', gap: 10 }}>
            <Icon name="clock" size={16} color={EC.ink3} strokeWidth={1.8}/>
            <Body size={12.5} muted style={{ flex: 1, lineHeight: 1.4 }}>
              Suggestions clear after {R.reviewDays} days. Kept memories stay forever.
            </Body>
          </div>
        </div>
        <GIReassure style={{ marginTop: 16 }}/>
      </div>
    </GISheet>
  );
}

// ── The post-onboarding invitation, in the Timeline ───────────────
// The one moment this feature earns a place in the feed: a brand-new journal
// with nothing behind it.
function GIImportInvite({ onStart = () => {}, onDismiss = () => {}, style = {} }) {
  return (
    <div style={{
      background: '#fff', border: `1px solid ${EC.border}`, borderRadius: 20, padding: 16,
      boxShadow: '0 10px 24px rgba(40,30,20,0.06)', position: 'relative', ...style,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <Eyebrow style={{ fontSize: 10 }}>Start with what you have</Eyebrow>
        <div style={{ flex: 1 }}/>
        <button onClick={onDismiss} aria-label="Not now" style={{
          width: 28, height: 28, borderRadius: '50%', border: 'none', background: 'transparent',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}>
          <Icon name="x" size={14} color={EC.ink3} strokeWidth={2}/>
        </button>
      </div>
      <Title size={21} style={{ marginTop: 8, lineHeight: 1.14 }}>
        Your journal does not have to start empty.
      </Title>
      <Body size={13.5} muted style={{ marginTop: 7, lineHeight: 1.5 }}>
        Momora can look through the photos already on your phone and suggest a handful
        of moments worth keeping. You decide which ones become memories.
      </Body>
      <div style={{ display: 'flex', gap: 5, marginTop: 14 }}>
        {['snow', 'garden', 'cake', 'kitchen', 'beach'].map((s, i) => (
          <GIPhoto key={s} scene={s} seed={(i * 23 % 100) / 100} radius={8}
            style={{ flex: 1, height: 62, transform: `rotate(${(i % 2 ? 1 : -1) * 1.1}deg)` }}/>
        ))}
      </div>
      <div style={{ marginTop: 15, display: 'flex', alignItems: 'center', gap: 12 }}>
        <Button size="md" onClick={onStart} style={{ flex: 1 }}>Look through my photos</Button>
      </div>
      <GIReassure style={{ marginTop: 13 }}>
        Nothing is added without you, and your camera roll is never changed.
      </GIReassure>
    </div>
  );
}

// A Timeline in each of its import-aware states.
// state: invite | processing | ready | resume | attention | expiring
function GITimelineWithBanner({ state = 'ready', drawer = false, onOpen = () => {}, onTab = () => {} }) {
  const [open, setOpen] = React.useState(drawer);
  const invite = state === 'invite';
  const mems = window.MOMORA_MOCK.memories.slice(0, invite ? 1 : 2);
  return (
    <div style={{ height: '100%', background: EC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', boxSizing: 'border-box', paddingBottom: 130 }}>
        <div style={{ padding: '54px 24px 0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Eyebrow color={EC.ink3}>Sunday · May 25</Eyebrow>
            <div style={{ display: 'flex', gap: 8 }}>
              <button aria-label="Search" style={{
                width: 38, height: 38, borderRadius: '50%', background: '#fff', border: `1px solid ${EC.border}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
              }}>
                <Icon name="search" size={18} color={EC.ink2}/>
              </button>
              {!invite && <GIImportButton state={state} onClick={() => setOpen(true)}/>}
            </div>
          </div>
          <Display size={34} style={{ marginTop: 10 }}>Your<br/>moments.</Display>
          <StreakStrip style={{ marginTop: 18 }}/>
        </div>
        <div style={{ padding: '22px 20px 0', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {invite && <GIImportInvite onStart={onOpen}/>}
          {mems.map(m => <MemoryCardSpread key={m.id} m={m}/>)}
        </div>
      </div>
      <ComposeFab/>
      <TabBar active="timeline" onTab={onTab}/>
      {open && (
        <GIImportDrawer state={state === 'invite' ? 'ready' : state}
          onOpen={() => { setOpen(false); onOpen(); }} onClose={() => setOpen(false)}/>
      )}
    </div>
  );
}

// ── Outcomes with nothing to show ─────────────────────────────────
function GIOutcomeEmpty({ kind = 'nothing', onDone = () => {}, onSecondary = () => {}, platform = 'ios' }) {
  const map = {
    nothing: {
      eyebrow: 'All done looking',
      title: 'Nothing stood out\nthis time.',
      body: 'Momora went through 8,412 photos and did not find a group it felt confident about. That is not a judgement of your photos — it only suggests events it is sure of.',
      note: 'You can still add any photo yourself, whenever you want.',
      primary: 'Add a photo myself', secondary: 'Back to my journal',
      script: 'nothing to suggest',
    },
    emptyLibrary: {
      eyebrow: 'Nothing to look through',
      title: 'No photos here\nyet.',
      body: 'Momora could not find any photos on this phone. If your photos live in another account or on another device, start this from that phone instead.',
      note: 'Your camera roll is never changed — there was simply nothing to read.',
      primary: 'Back to my journal', secondary: 'How this works',
      script: 'an empty roll',
    },
    limitedNothing: {
      eyebrow: 'All done looking',
      title: 'Nothing yet from\nthe photos you chose.',
      body: 'Momora looked at the 14 photos you allowed and did not find an event it was confident about. Choosing a few more days of photos usually helps.',
      note: 'Your camera roll is never changed.',
      primary: 'Choose more photos', secondary: 'Back to my journal',
      script: 'just 14 photos',
    },
  }[kind];
  return (
    <div style={{ height: '100%', background: EC.bg, position: 'relative', overflow: 'hidden' }}>
      <GITopBar left="Close" onLeft={onDone} platform={platform} onBack={onDone}/>
      <div style={{ padding: '18px 24px 0' }}>
        <Eyebrow color={EC.ink3}>{map.eyebrow}</Eyebrow>
        <Display size={34} style={{ marginTop: 12, whiteSpace: 'pre-line' }}>{map.title}</Display>
      </div>
      <div style={{ padding: '24px 32px 0' }}>
        <div style={{
          background: '#fff', border: `1px solid ${EC.border}`, borderRadius: 20, padding: '30px 20px',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, position: 'relative', overflow: 'hidden',
        }}>
          {[1,2,3,4,5].map(i => (
            <div key={i} style={{ position: 'absolute', left: 22, right: 22, top: 20 + i * 26, height: 1, background: EC.border, opacity: .5 }}/>
          ))}
          <Script size={28} color={EC.primary} style={{ transform: 'rotate(-3deg)', position: 'relative' }}>{map.script}</Script>
        </div>
      </div>
      <div style={{ padding: '22px 24px 0' }}>
        <Body size={14.5} muted style={{ lineHeight: 1.6 }}>{map.body}</Body>
        <GIReassure style={{ marginTop: 16 }}>{map.note}</GIReassure>
      </div>
      <GIActionBar platform={platform}>
        <Button onClick={onDone} style={{ width: '100%' }}>{map.primary}</Button>
        <Button variant="ghost" onClick={onSecondary} style={{ width: '100%' }}>{map.secondary}</Button>
      </GIActionBar>
    </div>
  );
}

Object.assign(window, {
  GIOffer, GISettingsEntry, GITimelineWithBanner, GIOutcomeEmpty,
  GIImportButton, GIImportDrawer, GIImportInvite, GIImportGlyph,
});
