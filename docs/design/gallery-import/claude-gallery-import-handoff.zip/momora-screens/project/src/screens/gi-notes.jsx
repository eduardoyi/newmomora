// Gallery import — the written deliverable: narrative, flow, motion, system, copy, questions.
const { c: NC, f: NF } = window.MOMORA;
const nb = (s) => `<strong style="color:${NC.ink};font-weight:700">${s}</strong>`;

// Local copy of the notes bullet block, so this file stands alone.
function GINoteBlock({ title, items }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
      <Eyebrow style={{ fontSize: 10.5 }}>{title}</Eyebrow>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
        {items.map((t, i) => (
          <div key={i} style={{ display: 'flex', gap: 9, alignItems: 'flex-start' }}>
            <div style={{ width: 5, height: 5, borderRadius: 999, background: NC.border, marginTop: 7, flexShrink: 0 }}/>
            <div style={{ fontFamily: NF.sans, fontSize: 12.5, lineHeight: 1.55, color: NC.ink2, textWrap: 'pretty' }}
              dangerouslySetInnerHTML={{ __html: t }}/>
          </div>
        ))}
      </div>
    </div>
  );
}
var NoteBlock = GINoteBlock;

function GINotePage({ eyebrow, title, lede, children, width = 470 }) {
  return (
    <div style={{ height: '100%', overflowY: 'auto', boxSizing: 'border-box', background: NC.bg, padding: '34px 34px 46px' }}>
      <Eyebrow>{eyebrow}</Eyebrow>
      <div style={{
        fontFamily: NF.display, fontWeight: 400, fontSize: 34, lineHeight: 1.08,
        letterSpacing: '-0.02em', color: NC.ink, marginTop: 14,
      }}>{title}</div>
      {lede && (
        <div style={{ fontFamily: NF.sans, fontSize: 13.5, lineHeight: 1.6, color: NC.ink2, marginTop: 12, maxWidth: width }}
          dangerouslySetInnerHTML={{ __html: lede }}/>
      )}
      <div style={{ marginTop: 30, display: 'grid', gap: 26 }}>{children}</div>
    </div>
  );
}

// ── 1 · Narrative and rationale ──────────────────────────────────
function GINoteNarrative() {
  return (
    <GINotePage eyebrow="Gallery import · the idea"
      title="Momora went through the shoebox for you."
      lede={`The emotional promise is not ${nb('“AI organised your photos”')} — it is ${nb('“someone quietly went through the box in the loft and left a small stack on the table.”')} Everything in the design serves that image: a stack, not a queue; prints, not files; keeping, not sorting.`}>
      <NoteBlock title="What the parent feels, in order" items={[
        `${nb('Recognition')} — “some of it is already on your phone”. The offer never says import, upload, scan, or library.`,
        `${nb('Trust, before permission')} — three numbered facts, including the uncomfortable one: small previews really do leave the phone before approval. Said plainly, in the second card, not in a footnote.`,
        `${nb('Relief')} — “safe to close Momora” is answered on every progress state, positively or negatively. Never implied.`,
        `${nb('Reward')} — the first card is a print with a date stamped on it, not a task. Kept memories land on the day they happened, so the journal grows backwards and the years fill in.`,
        `${nb('Permission to stop')} — a rest point every few keeps. “That is enough for now” is a real button, styled as an equal, not a dismissal.`,
      ]}/>
      <NoteBlock title="Anti-goals, and how each is avoided" items={[
        `Not a ${nb('photo cleanup tool')}: nothing is graded. Left swipe is “set aside”, and the copy names the reason as not-this-one, never a fault in the photo. Skipped items live in a list called Set aside, with Bring back — no bin iconography anywhere.`,
        `Not a ${nb('dating app')}: the card does not fly away with a green tick or a red cross. The intent label is a small letterpress stamp — Keep in raspberry, Set aside in outline — and the tilt is capped at 8°.`,
        `Not a ${nb('file uploader')}: bytes, queues and percentages are replaced with events, photos and prints. The only number shown is one a parent can picture (“214 of 388 previews”, “about 46 MB”).`,
        `Not an ${nb('AI dashboard')}: no confidence scores, no model names, no moderation language, no token counts. Confidence is expressed by absence — low-confidence events are simply never suggested.`,
        `Not an ${nb('administrative chore')}: review has no completion bar over an unknown total, no streak, no “7 left!” urgency. The ledger reads “4 kept · 3 set aside · 6 still coming”.`,
      ]}/>
      <NoteBlock title="Where the decision ends and editing begins" items={[
        `${nb('The card is for one decision only')} — keep or set aside. A photograph laid on paper: hero print, the event's other photos as a small strip, then the drafted text. No edit affordances, no chrome on the image, nothing to fiddle with. One-handed; the thumb never leaves the bottom third.`,
        `${nb('Keeping opens the memory composer')} — the same screen Momora already has for New and Edit memory: header, date pill, one serif field, the photo grid with numbered removable tiles and an Add tile, the tag strip, the toolbar. Words, photos, date and who is in it, in one step, and Save writes the memory. A parent who has written one memory already knows this screen.`,
        `${nb('One line below the buttons carries this')}: “Keeping opens the memory so you can change the words, photos, date and who is in it before it is saved.” It removes the fear that a swipe commits something unedited, without putting an edit control on the card.`,
        `The film strip on the card stays a ${nb('preview')}, not a control — tapping it opens the day's photos to look at, and the count (“4 photos chosen · from 26 that day”) tells a parent the rest were not thrown away.`,
      ]}/>
      <NoteBlock title="Where it lives in Momora" items={[
        `Visually it is the existing journal, one notch warmer: same #FAFAFD ground, white paper cards, Newsreader titles, raspberry as the only action colour. The one new element is the ${nb('photo mat')} — a 12px white border around imported photos, which reads as a print and separates a camera-roll photo from an AI illustration at a glance.`,
        `Illustrations are deliberately absent. Imported memories are ${nb('media memories')}; the picture is the parent's own photo, and the app never redraws it.`,
        `Caveat is used exactly once per screen — the date stamp on the hero print. It is the only handwritten mark in the flow.`,
      ]}/>
    </GINotePage>
  );
}

// ── 2 · Flow and information architecture ────────────────────────
function GINoteFlow() {
  const Node = ({ children, tone = 'paper', sub }) => (
    <div style={{
      background: tone === 'paper' ? '#fff' : tone === 'tint' ? NC.primaryTint : NC.surface,
      border: `1px solid ${tone === 'tint' ? NC.primarySoft : NC.border}`, borderRadius: 12,
      padding: '9px 11px', minWidth: 0,
    }}>
      <div style={{ fontFamily: NF.sans, fontSize: 12.5, fontWeight: 700, color: NC.ink, lineHeight: 1.3 }}>{children}</div>
      {sub && <div style={{ fontFamily: NF.sans, fontSize: 11, color: NC.ink3, marginTop: 3, lineHeight: 1.35 }}>{sub}</div>}
    </div>
  );
  const Arrow = () => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '4px 0' }}>
      <Icon name="chevronDown" size={14} color={NC.ink3} strokeWidth={2}/>
    </div>
  );
  const Lane = ({ label, children }) => (
    <div>
      <Eyebrow color={NC.ink3} style={{ fontSize: 10, marginBottom: 8 }}>{label}</Eyebrow>
      <div style={{ display: 'grid', gap: 0 }}>{children}</div>
    </div>
  );
  return (
    <GINotePage eyebrow="Gallery import · flow" title="One path, four safe exits."
      lede={`Every screen in the run is leaveable. The only irreversible step in the whole feature is ${nb('Add to my journal')} — and even that is undoable by deleting the memory.`}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 22 }}>
        <Lane label="Discovery">
          <Node tone="tint" sub="After child-first onboarding, paid, owner or manager">Post-onboarding offer</Node>
          <Arrow/>
          <Node sub="Settings › Your journal — always there">Persistent entry</Node>
          <Arrow/>
          <Node sub="Glyph beside Search → status drawer">Timeline glyph</Node>
        </Lane>
        <Lane label="Trust">
          <Node sub="What is read · what is sent · what is kept">Explainer</Node>
          <Arrow/>
          <Node sub="Full · limited · denied · already denied">OS prompt</Node>
          <Arrow/>
          <Node sub="Degraded mode is a first-class path">Limited outcome</Node>
        </Lane>
        <Lane label="Work (server-side)">
          <Node sub="On device · keep the app open">Scanning</Node>
          <Arrow/>
          <Node sub="Wi-Fi default · cellular override">Previews → upload</Node>
          <Arrow/>
          <Node sub="Safe to close · results stream in">Writing drafts</Node>
        </Lane>
        <Lane label="Review and keep">
          <Node tone="tint" sub="Swipe or buttons · edit · choose photos">The deck</Node>
          <Arrow/>
          <Node sub="Caption · date · unlimited tagging">Final review</Node>
          <Arrow/>
          <Node sub="Saved on its own date · next or stop">Kept</Node>
        </Lane>
      </div>
      <NoteBlock title="Run states the parent can actually see" items={[
        `${nb('scanning → preparing → waiting for Wi-Fi → uploading → processing → ready')}, plus ${nb('paused')}, ${nb('interrupted')}, ${nb('did not finish')}, ${nb('stopped')} and ${nb('cleared')}. Each maps to one screen with the same skeleton: eyebrow, one sentence of state, one honest number, the three-step ladder, and the safe-to-close card.`,
        `A Momora memory is ${nb('one block of text')} — no title field — so a draft is exactly that: one serif paragraph and a date. Editing a draft opens the ${nb('same screen as Edit memory')} (Cancel · type badge · Save, date pill, one serif field, attachment below, mic in the toolbar), with the illustration toggle absent because imports never generate one.`,
        `Candidate states: ${nb('waiting → in the deck → kept → set aside → not available')}. “Accepted but not finished” is never a dead end — leaving the final review puts the card back in the deck untouched.`,
        `A run belongs to the phone that scanned it. Another device shows one screen: ${nb('“These photos live on your other phone.”')} No previews, no counts of other people's drafts.`,
      ]}/>
      <NoteBlock title="Entry-point rules" items={[
        `Hidden entirely for viewers and for members who are not owner or manager — not shown-and-disabled, except in Settings where a one-line explanation is kinder than a missing row.`,
        `The offer appears ${nb('once')} after onboarding, and only after the first child and portrait exist. Declining moves it to Settings and never asks again.`,
        `While a run is active, a small import glyph appears beside Search carrying a quiet dot — sea and breathing while it works, raspberry when there is something to review, mustard when it needs a decision. Tapping it opens a drawer with one status and one action. Run status never occupies a card in the feed.`,
        `The one exception is a brand-new journal: until it has memories of its own, an invitation card sits in the feed (${nb('“Your journal does not have to start empty.”')}) with a dismiss ✕. Dismissed once, or outgrown, it never returns — the glyph and the Settings row carry the feature from then on.`,
      ]}/>
    </GINotePage>
  );
}

// ── 3 · Interaction, motion, accessibility ───────────────────────
function GINoteMotion() {
  return (
    <GINotePage eyebrow="Gallery import · interaction &amp; motion" title="Curation, not judgement."
      lede={`The gesture is fixed by the plan; its ${nb('expression')} is the design work. Everything below is tuned to make a swipe feel like moving a photograph, not scoring it.`}>
      <NoteBlock title="The swipe" items={[
        `Follow the finger 1:1. Rotation is ${nb('dx ÷ 28, capped at 8°')}, pivoting from below the card so it behaves like paper on a table.`,
        `Commit threshold ${nb('92px')} or a fling over 0.6 px/ms. Below that the card returns in 260ms, --ease-out. No snap-back overshoot.`,
        `Intent stamps appear from 26px of travel, opacity tracking distance: ${nb('Keep')} as a filled raspberry pill top-right, ${nb('Set aside')} as an outlined pill top-left. Both carry a word — never colour alone, never a red cross.`,
        `Exit: 240ms translate to ±460px with an 8° rotation and no fade — the card leaves the table rather than dissolving. The next print is already visible beneath, so the deck never looks empty mid-transition.`,
        `Right swipe opens the final review as a push, not a commit. Backing out returns the same card to the top of the deck, unedited and unmarked.`,
      ]}/>
      <NoteBlock title="No gesture is the only way" items={[
        `Every card has ${nb('Set aside')} and ${nb('Keep this')} as labelled buttons in the bottom bar, 48px tall, thumb-height, with icons and text. The gesture is an accelerator for people who like it.`,
        `Screen-reader custom actions on the card: Keep, Set aside, Edit words, Choose photos, Show set-aside list. The card announces as “Suggestion 5 of 12. Sunday 14 January 2024. 4 photos. A first snow morning — boots too big, mittens on the wrong hands.”`,
        `Focus order: card → film strip → edit → Set aside → Keep. The ledger and the “still coming” count are a polite ${nb('live region')} — it announces once when new suggestions arrive, not per card.`,
        `Hit targets ≥44px everywhere, including the photo checkboxes (the 20px circle sits inside a full-tile button).`,
      ]}/>
      <NoteBlock title="Reduced motion" items={[
        `Card tilt, exit translate and the sweep on the progress card are all disabled. The card cross-fades out over 120ms and the next one fades in — position never changes.`,
        `Intent stamps become instant on/off at the 26px threshold instead of ramping with distance.`,
        `The indeterminate progress sweep becomes a static bar with a text state (“Still working”). Breathing dots become solid.`,
      ]}/>
      <NoteBlock title="Everything else, kept calm" items={[
        `Durations from the system: ${nb('140ms')} press feedback, ${nb('220ms')} sheets and toggles, ${nb('380ms')} set pieces (the saved card rising, the offer's print stack settling). Easing --ease-out throughout; --ease-spring only on the saved-card rise.`,
        `No confetti, no bounce, no haptic burst on keep. Saving is quiet: the card rises 10px and the next suggestion is already there.`,
        `Progress never animates a percentage of an unknown total. While the total is unknown, the bar sweeps and the truth lives in the counts.`,
        `Keyboard avoidance: caption and instruction fields sit inside a sheet that resizes with the keyboard; the pinned action row rides above it with live bottom-inset padding on both platforms. Nothing that can be typed into is ever under the keyboard.`,
      ]}/>
    </GINotePage>
  );
}

// ── 4 · Components and states ────────────────────────────────────
function GINoteSystem() {
  return (
    <GINotePage eyebrow="Gallery import · reusable parts" title="Nine components carry the feature."
      lede={`All of it is built from the existing Momora kit plus a small photo-import layer. Nothing new enters the design system that is not reused at least twice.`}>
      <NoteBlock title="New, reusable" items={[
        `${nb('PhotoMat')} — a white 12px paper frame with the standard 16px radius and hairline border. Used by deck cards, the final review, the saved card and the timeline card for imported memories. This is the visual signature of “your photo, not our drawing”.`,
        `${nb('SwipeCard')} + ${nb('IntentStamp')} — the gesture wrapper and its two labels. Also usable later for any accept/skip queue (invites, duplicate merges).`,
        `${nb('ContactGrid')} is the composer's own photo grid, extended with a day's pool — nothing new is built for import.`,
        `${nb('ContactGrid')} — the selectable 3-up photo grid. One component behind: choose different photos, replace an unavailable photo, and limited-access previews.`,
        `${nb('RunLedger')} — “4 kept · 3 set aside · 6 still coming”. Replaces progress bars wherever the total is unknowable.`,
        `${nb('StepLadder')} — the three-step vertical ladder with done/active/waiting dots, plus the ${nb('SafeToCloseCard')} beneath it. Reusable for portrait generation and export.`,
        `${nb('StateScreen')} — eyebrow or pill, big serif line, one paragraph, optional card, one primary and one ghost action, reassurance line. Every exceptional state is this component with different words.`,
        `${nb('InlineNotice')} — the four-tone strip (sea, sun, soft, error) for anything that does not need to take over the screen.`,
        `${nb('LocaleCombobox')} — searchable, grouped, sticky-lettered list with Current and Recently used at the top. Reusable for any long registry list.`,
        `${nb('PostingStrip')} — matches the existing pending-memory card, so an import that is still saving looks exactly like a normal post in progress.`,
        `${nb('ImportGlyph + status drawer')} — a 38px round button beside Search with a state dot, and the drawer behind it. Reusable for any background job that must not colonise the feed (export, portrait batches).`,
        `${nb('InviteCard')} — the empty-journal prompt in the feed, dismissible, shown once.`,
      ]}/>
      <NoteBlock title="Reused unchanged" items={[
        `${nb('WhosInIt')} roster sheet — same control as the composer, with the cap label suppressed because imported photo memories allow unlimited tags.`,
        `${nb('New / Edit memory')} — the keep step IS that screen, not a copy of it: same header, date pill, serif field, photo grid, tag strip and toolbar. Only the illustration toggle is absent, because imported memories never generate one.`,
        `Buttons, Field/Input, Eyebrow, Display/Title/Body, EmotionChip, Avatar, Paper, TabBar, GISheet's grabber and scrim — all existing.`,
        `The Timeline card for a kept import is the ordinary ${nb('media memory card')}. Nothing marks it as machine-suggested once it is in the journal; it is simply a memory now.`,
      ]}/>
      <NoteBlock title="State coverage checklist" items={[
        `Permission: full · limited · denied · denied-and-not-repromptable · revoked mid-run.`,
        `Network: Wi-Fi · waiting for Wi-Fi · cellular override · offline · lost mid-upload.`,
        `Run: scanning · preparing · uploading · processing · partial · paused · interrupted · failed · stopped · expired · another device.`,
        `Candidate: waiting · in deck · edited · set aside · restored · kept · photo unavailable · cleared by expiry.`,
        `Access: owner · manager · demoted mid-run · removed from family · subscription lapsed · complimentary.`,
      ]}/>
    </GINotePage>
  );
}

// ── 5 · Copy deck ────────────────────────────────────────────────
function GINoteCopy() {
  const Pair = ({ good, bad }) => (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
      <div style={{ background: '#fff', border: `1px solid ${NC.border}`, borderRadius: 12, padding: 11 }}>
        <Body size={11} style={{ fontWeight: 700, color: NC.success }}>Say</Body>
        <Body size={12.5} style={{ marginTop: 4, lineHeight: 1.45 }}>{good}</Body>
      </div>
      <div style={{ background: NC.surface, border: `1px solid ${NC.border}`, borderRadius: 12, padding: 11 }}>
        <Body size={11} style={{ fontWeight: 700, color: NC.ink3 }}>Not</Body>
        <Body size={12.5} muted style={{ marginTop: 4, lineHeight: 1.45 }}>{bad}</Body>
      </div>
    </div>
  );
  return (
    <GINotePage eyebrow="Gallery import · copy" title="Words that carry the trust."
      lede={`Momora's voice already forbids most of the traps here. These are the lines where a wrong word would cost belief, so they are specified rather than left to the build.`}>
      <div style={{ display: 'grid', gap: 10 }}>
        <Pair good="Some of it is already on your phone." bad="Import your camera roll"/>
        <Pair good="Small previews are sent to Momora and its AI partner." bad="Your photos are processed securely"/>
        <Pair good="Set aside" bad="Skip · Discard · Delete · Reject"/>
        <Pair good="Not this one." bad="This photo isn’t good enough"/>
        <Pair good="Safe to close Momora." bad="Do not close the app"/>
        <Pair good="12 suggestions ready · 8 still coming" bad="63% complete"/>
        <Pair good="Momora only suggests events it is confident about." bad="Some photos were rejected by our safety filter"/>
        <Pair good="One photo is not on this phone any more." bad="Asset unavailable (error 404)"/>
        <Pair good="These photos live on your other phone." bad="Run is device-bound"/>
        <Pair good="Your camera roll is never changed." bad="We do not modify your library (probably)"/>
        <Pair good="Your journal does not have to start empty." bad="Import your photos to get started!"/>
        <Pair good="Momora wrote this. Change anything — it is your memory." bad="AI-generated caption"/>
      </div>
      <NoteBlock title="Lines worth locking" items={[
        `Permission explainer, card 2: ${nb('“To suggest titles and pick which photos tell the story, Momora sends small, low-resolution copies to its own private storage and to the AI service that writes the drafts.”')} This sentence is the whole honesty posture; do not soften it in localisation.`,
        `Never-invent promise: ${nb('“Momora never tries to work out who is in a photo or where it was taken. It writes what it can see, and you add the names.”')} It explains the slightly generic drafts and turns a limitation into a value.`,
        `Set-aside reassurance: ${nb('“Setting something aside is not a judgement of the photo — it just means not this one.”')}`,
        `Family digest: ${nb('“Sam added 58 older memories to the journal.”')} — no mechanism, no camera-roll mention, one notification per quiet period.`,
        `Expiry: ${nb('“Suggestions last 30 days, then Momora deletes the previews and drafts. The memories you kept are yours.”')} Expiry is framed as tidying up after itself, never as losing something.`,
      ]}/>
    </GINotePage>
  );
}

// ── 6 · Platform differences ─────────────────────────────────────
function GINotePlatform() {
  return (
    <GINotePage eyebrow="Gallery import · iOS &amp; Android" title="Same product, native manners."
      lede={`Two platforms, one design. Differences are limited to how the OS asks, how it navigates, and where the system settings are — never to what the feature is.`}>
      <NoteBlock title="Deliberate differences" items={[
        `${nb('Navigation')} — iOS uses a text “Cancel” or “Close” on the left, per Momora's existing rule. Android uses a 44px back arrow plus a left-aligned title, and respects predictive back: swiping back from the deck is the same as Close, and mid-run it never loses the run.`,
        `${nb('Permission')} — iOS offers Limit Access, Allow Full Access, Don't Allow, and asks only once, so the “already denied” state routes to Settings › Momora › Photos. Android offers Allow all, Select photos and videos, Don't allow, and its blocked copy points at Settings › Apps › Momora › Permissions.`,
        `${nb('Limited library')} — iOS shows “Choose more photos” which opens the system picker over the app; Android shows “Select more photos”. Both re-scan the new selection into the same run.`,
        `${nb('Sheets')} — iOS sheets keep the grabber and corner radius 24; Android sheets use the same geometry but Material-standard 28px on system dialogs only (the OS prompt), so the app never mixes idioms with the platform's own.`,
        `${nb('Safe area')} — bottom action bars pad 34px on iOS home-indicator devices and 22px plus the live inset on Android's gesture bar. Both read the inset at runtime; neither hard-codes.`,
        `${nb('Wording')} — “iCloud” on iOS, “your Google Photos backup” on Android, for the downloading-originals state. Everything else is identical.`,
      ]}/>
      <NoteBlock title="One product risk worth naming" items={[
        `Whole-library scanning on Android depends on Play broad-photo-access approval, which the plan itself calls uncertain. The design is therefore built so that ${nb('limited access is a first-class mode, not a fallback')}: nothing in the offer, explainer, progress or deck assumes the whole library.`,
        `If approval is refused, the same screens work over a user-selected batch with two copy changes (“the photos you choose” instead of “your photos”, and a “Choose photos” step before the explainer). No new flow, no second product.`,
      ]}/>
    </GINotePage>
  );
}

// ── 7 · Decisions and what is still open ────────────────────────
function GINoteQuestions() {
  return (
    <GINotePage eyebrow="Gallery import · decisions" title="Settled, and still open."
      lede={`Found while designing against ${nb('docs/plans/gallery-import.md')}. The first group is answered and built into these screens — an implementer should treat them as spec. The second group still needs a product answer.`}>
      <NoteBlock title="Decided — build to these" items={[
        `${nb('Set-aside recovery ends with the run.')} Skipped cards are recoverable for 30 days and then clear, even though skipped receipts never expire. Shipping as-is: no day-31 path, and a later run still never re-suggests them. Copy already frames expiry as Momora tidying up after itself, not as loss.`,
        `${nb('Cancelling the composer returns the card to the deck, untouched.')} A right swipe stages nothing — it opens the memory composer. Back out and the suggestion is unmarked, unedited, and next in the deck. No accepted-not-finished state is needed.`,
        `${nb('Run caps get a plain-language ceiling screen.')} When dispatch stops early: ${nb('“Momora stopped at 18 events this time. There is plenty left — you can look through more next month.”')} Never budget, quota, or limit. See the ${nb('Stopped at 18 events')} artboard.`,
        `${nb('A lapsed subscription can still read, edit and set aside.')} Only ${nb('Save')} routes to resubscribe. Everything staged stays visible for the rest of the review period, so nothing feels held hostage.`,
        `${nb('Photo access is fixed once a run starts.')} Granting more photos mid-run does not join it. This is not stated on screen — no warning, no nag — the limited-access copy simply invites choosing more ${nb('before')} Momora starts looking, and never promises new photos will be picked up.`,
        `${nb('No emotion until a memory is saved.')} Suggestion cards show no emotion chip, so the deck never looks like the AI is labelling the family's feelings. Emotion is analysed after the memory exists.`,
        `${nb('Expiry stays one 30-day window.')} No waves, no extensions, even for a very large result set. Revisit if real runs routinely produce 100+ candidates.`,
        `${nb('Provenance is stored, never shown.')} A kept import carries a flag in the database so retention questions stay answerable — and no badge, filter or label anywhere in the UI. Once it is in the journal it is simply a memory. Adding a badge later would change the look of memories a family already owns.`,
        `${nb('The family digest drops the mechanism:')} ${nb('“Sam added 58 older memories to the journal.”')} No camera roll, no import, no count of runs. One summary after 30 quiet minutes.`,
      ]}/>
      <NoteBlock title="Still open" items={[
        `${nb('Two phones, one family.')} Photos split across an old and a new device need two runs, and the monthly cap may block the second. A first-time-import exemption is probably right, but it is a product call.`,
        `${nb('What the ceiling number actually is.')} The screen says 18 because the mock does; the real number, and whether it is events or cost, changes the sentence.`,
        `${nb('Three evenings of reviewing produces three digests')} under the 30-minute quiet period. Assumed intentional — worth stating in the feature doc so it is not later read as a bug.`,
        `${nb('Videos are out of scope')}, but parents will notice videos missing from a suggested day. One line in the photo sheet (“Momora only suggests photos for now”) would prevent a support ticket. Needs a yes before it goes in.`,
      ]}/>
    </GINotePage>
  );
}

Object.assign(window, {
  GINotePage, GINoteNarrative, GINoteFlow, GINoteMotion, GINoteSystem, GINoteCopy, GINotePlatform, GINoteQuestions,
});
