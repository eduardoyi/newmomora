// Gallery import — trust, permission, and the honest privacy explanation.
const { c: TRC, f: TRF } = window.MOMORA;

// ── Pre-permission explainer ──────────────────────────────────────
// Everything the parent should know before the OS asks. No manipulation:
// the "not now" option is a real, equal option.
function GIExplainer({ onContinue = () => {}, onCancel = () => {}, onDetails = () => {}, platform = 'ios', sheet }) {
  const [open, setOpen] = React.useState(sheet || null);
  const detail = (k) => { setOpen(k); onDetails(k); };
  return (
    <div style={{ height: '100%', background: TRC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', boxSizing: 'border-box', paddingBottom: 170 }}>
        <GITopBar left="Cancel" onLeft={onCancel} platform={platform} onBack={onCancel}/>
        <div style={{ padding: '10px 24px 0' }}>
          <Eyebrow>Before we look</Eyebrow>
          <Display size={34} style={{ marginTop: 12 }}>Here is exactly<br/>what happens.</Display>
        </div>

        <div style={{ padding: '24px 20px 0', display: 'flex', flexDirection: 'column', gap: 10 }}>
          <TrustCard n="1" title="Your phone does the looking"
            body="Momora reads the photos you allow — dates, and how they group into events. Nothing is deleted, moved, edited or tidied up."
            foot="Reading only · stays on this phone"/>
          <TrustCard n="2" title="Small previews are sent to Momora and its AI partner"
            body="To suggest titles and pick which photos tell the story, Momora sends small, low-resolution copies to its own private storage and to the AI service that writes the drafts."
            foot="Small copies, before you approve anything" tone="sun"
            action={{ label: 'What a preview is', onClick: () => detail('preview') }}/>
          <TrustCard n="3" title="Only what you keep is saved"
            body="When you keep a suggestion, Momora saves the full-size photos into your journal. Everything else — including the previews — is deleted."
            foot={`Suggestions clear after ${window.GI_RUN.reviewDays} days`}
            action={{ label: 'What is kept, and for how long', onClick: () => detail('retention') }}/>
        </div>

        <div style={{ padding: '20px 24px 0' }}>
          <div style={{ background: TRC.surface, border: `1px solid ${TRC.border}`, borderRadius: 14, padding: 14 }}>
            <Body size={13} style={{ fontWeight: 700 }}>No face recognition. No location.</Body>
            <Body size={12.5} muted style={{ marginTop: 5, lineHeight: 1.5 }}>
              Momora never tries to work out who is in a photo or where it was taken.
              It writes what it can see, and you add the names.
            </Body>
          </div>
        </div>
      </div>

      <GIActionBar platform={platform}>
        <Button onClick={onContinue} style={{ width: '100%' }}>
          {platform === 'ios' ? 'Choose which photos' : 'Continue'}
        </Button>
        <Button variant="ghost" onClick={onCancel} style={{ width: '100%' }}>Not now</Button>
        <Body size={11.5} muted style={{ textAlign: 'center' }}>
          Next, {platform === 'ios' ? 'iOS' : 'Android'} will ask what Momora may see.
        </Body>
      </GIActionBar>

      {open === 'preview' && (
        <GISheet title="What a preview is" onClose={() => setOpen(null)}
          subtitle="The honest version, in plain terms.">
          <div style={{ padding: '18px 24px 26px', display: 'flex', flexDirection: 'column', gap: 18 }}>
            <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
              <GIPhoto scene="garden" seed={.4} radius={12} style={{ width: 116, height: 116 }}/>
              <Icon name="arrowRight" size={18} color={TRC.ink3}/>
              <GIPhoto scene="garden" seed={.4} radius={8} style={{ width: 52, height: 52 }}/>
            </div>
            <Body size={14} style={{ lineHeight: 1.6 }}>
              A preview is a copy of your photo shrunk to about the size of a thumbnail —
              roughly a hundredth of the detail of the original. It is enough for the AI to
              tell a snowy morning from a birthday, and not much more.
            </Body>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <GIFact icon="layers" title="Where they go">
                Momora's own private storage, and the AI service that writes the draft titles.
                Nobody else in your family can see them.
              </GIFact>
              <GIFact icon="trash" title="How long they last">
                Until you finish reviewing, or {window.GI_RUN.reviewDays} days — whichever comes first.
                Then they are deleted.
              </GIFact>
              <GIFact icon="x" title="What is never sent">
                Names, ages, who is related to whom, your location, file names, and anything
                you have already written in Momora.
              </GIFact>
            </div>
            <Body size={12.5} muted style={{ lineHeight: 1.5 }}>
              This is the one part of Momora where photos leave your phone before you approve
              anything. We would rather say so plainly than bury it.
            </Body>
          </div>
        </GISheet>
      )}

      {open === 'retention' && (
        <GISheet title="What is kept" onClose={() => setOpen(null)}
          subtitle="Three different things, three different lives.">
          <div style={{ padding: '18px 24px 26px', display: 'flex', flexDirection: 'column', gap: 14 }}>
            <RetentionRow label="Your camera roll" value="Never touched" tone="sea"
              body="Momora only reads. It cannot delete, move or edit a photo, even if you wanted it to."/>
            <RetentionRow label="Previews and drafts" value={`Up to ${window.GI_RUN.reviewDays} days`} tone="sun"
              body="Deleted as soon as you finish, or automatically when the review period ends."/>
            <RetentionRow label="Memories you keep" value="Yours, until you delete them" tone="primary"
              body="Full-size photos, saved into your private family journal with the location data stripped out."/>
            <div style={{ height: 1, background: TRC.border, margin: '4px 0' }}/>
            <Body size={13} muted style={{ lineHeight: 1.6 }}>
              You can stop the whole thing at any point. Stopping deletes the previews and
              the drafts, and keeps anything you already saved.
            </Body>
            <Button variant="secondary" style={{ width: '100%' }}>Read the privacy policy</Button>
          </div>
        </GISheet>
      )}
    </div>
  );
}

function TrustCard({ n, title, body, foot, action, tone = 'primary' }) {
  const c = tone === 'sun' ? TRC.sunInk : TRC.primary;
  return (
    <div style={{ background: '#fff', border: `1px solid ${TRC.border}`, borderRadius: 16, padding: 16 }}>
      <div style={{ display: 'flex', gap: 12 }}>
        <div style={{
          width: 24, height: 24, borderRadius: '50%', flexShrink: 0, marginTop: 1,
          background: tone === 'sun' ? TRC.sunSoft : TRC.primaryTint,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: TRF.sans, fontSize: 12, fontWeight: 700, color: c,
        }}>{n}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <Body size={15} style={{ fontWeight: 700, lineHeight: 1.3 }}>{title}</Body>
          <Body size={13.5} muted style={{ marginTop: 6, lineHeight: 1.55 }}>{body}</Body>
          <div style={{ marginTop: 11, display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            <GIPill tone={tone === 'sun' ? 'sun' : 'soft'}>{foot}</GIPill>
            {action && (
              <button onClick={action.onClick} style={{
                border: 'none', background: 'transparent', padding: '4px 0', cursor: 'pointer',
                fontFamily: TRF.sans, fontSize: 12.5, fontWeight: 700, color: TRC.primary,
                textDecoration: 'underline', textUnderlineOffset: 3,
              }}>{action.label}</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function RetentionRow({ label, value, body, tone }) {
  const map = { sea: TRC.sea, sun: TRC.sunInk, primary: TRC.primary };
  return (
    <div style={{ display: 'flex', gap: 12 }}>
      <div style={{ width: 3, borderRadius: 999, background: map[tone], flexShrink: 0 }}/>
      <div style={{ flex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, flexWrap: 'wrap' }}>
          <Body size={14} style={{ fontWeight: 700 }}>{label}</Body>
          <Body size={12.5} style={{ color: map[tone], fontWeight: 700 }}>{value}</Body>
        </div>
        <Body size={12.5} muted style={{ marginTop: 4, lineHeight: 1.5 }}>{body}</Body>
      </div>
    </div>
  );
}

// ── The OS prompt itself ──────────────────────────────────────────
function GIOSPrompt({ platform = 'ios', onFull = () => {}, onLimited = () => {}, onDeny = () => {} }) {
  return (
    <div style={{ height: '100%', position: 'relative', overflow: 'hidden', background: TRC.bg }}>
      <div style={{ position: 'absolute', inset: 0, opacity: .5, pointerEvents: 'none' }}>
        <GIExplainer/>
      </div>
      <div style={{ position: 'absolute', inset: 0, background: platform === 'ios' ? 'rgba(0,0,0,0.28)' : 'rgba(0,0,0,0.42)' }}/>
      {platform === 'ios' ? (
        <div style={{
          position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)',
          width: 270, background: 'rgba(249,249,249,0.94)', backdropFilter: 'blur(24px)',
          borderRadius: 14, overflow: 'hidden', fontFamily: '-apple-system, system-ui, sans-serif',
          boxShadow: '0 20px 50px rgba(0,0,0,0.28)',
        }}>
          <div style={{ padding: '19px 16px 15px', textAlign: 'center' }}>
            <div style={{ fontSize: 17, fontWeight: 600, color: '#000' }}>Allow “Momora” to access your photos?</div>
            <div style={{ fontSize: 13, color: '#000', marginTop: 4, lineHeight: 1.35 }}>
              Momora groups your photos into suggested memories. Small copies are sent to
              Momora and its AI partner to write the drafts.
            </div>
          </div>
          {[
            { label: 'Limit Access…', fn: onLimited },
            { label: 'Allow Full Access', fn: onFull, bold: true },
            { label: 'Don’t Allow', fn: onDeny },
          ].map(b => (
            <button key={b.label} onClick={b.fn} style={{
              width: '100%', border: 'none', borderTop: '0.5px solid rgba(0,0,0,0.18)',
              background: 'transparent', padding: '11px 8px', cursor: 'pointer',
              fontSize: 17, fontWeight: b.bold ? 600 : 400, color: '#007AFF',
              fontFamily: '-apple-system, system-ui, sans-serif',
            }}>{b.label}</button>
          ))}
        </div>
      ) : (
        <div style={{
          position: 'absolute', left: 16, right: 16, top: '50%', transform: 'translateY(-50%)',
          background: '#FEF7FF', borderRadius: 28, padding: '24px 24px 16px',
          fontFamily: 'Roboto, system-ui, sans-serif', boxShadow: '0 20px 50px rgba(0,0,0,0.32)',
        }}>
          <div style={{
            width: 44, height: 44, borderRadius: '50%', background: TRC.primaryTint, margin: '0 auto',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon name="image" size={22} color={TRC.primary} strokeWidth={1.9}/>
          </div>
          <div style={{ textAlign: 'center', fontSize: 20, color: '#1D1B20', marginTop: 16, lineHeight: 1.3 }}>
            Allow Momora to access photos and videos on this device?
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', marginTop: 22 }}>
            {[
              { label: 'Allow all', fn: onFull },
              { label: 'Select photos and videos', fn: onLimited },
              { label: 'Don’t allow', fn: onDeny },
            ].map(b => (
              <button key={b.label} onClick={b.fn} style={{
                border: 'none', background: 'transparent', textAlign: 'center', padding: '13px 8px',
                cursor: 'pointer', fontSize: 14, fontWeight: 500, color: '#6750A4',
                fontFamily: 'Roboto, system-ui, sans-serif',
              }}>{b.label}</button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── After the prompt ──────────────────────────────────────────────
function GIPermissionOutcome({ kind = 'limited', platform = 'ios', onPrimary = () => {}, onSecondary = () => {} }) {
  const isIOS = platform === 'ios';
  const map = {
    limited: {
      eyebrow: 'Some photos', title: 'Momora can see\nthe 14 photos\nyou chose.',
      body: isIOS
        ? 'That works. Momora will look through those and suggest what it can. If you want it to see more, choose them now — once it starts looking, it works with what it has.'
        : 'That works. Momora will look through those and suggest what it can. If you want it to see more, select them now — once it starts looking, it works with what it has.',
      pill: 'Limited access', tone: 'sun',
      primary: 'Look through these 14', secondary: isIOS ? 'Choose more photos' : 'Select more photos',
      note: 'Fewer photos usually means fewer suggestions — not worse ones.',
    },
    denied: {
      eyebrow: 'No photo access', title: 'Momora cannot\nsee your photos.',
      body: isIOS
        ? 'That is a completely reasonable choice, and nothing else in Momora is affected. If you change your mind, photo access lives in iOS Settings under Momora.'
        : 'That is a completely reasonable choice, and nothing else in Momora is affected. If you change your mind, photo access lives in Android settings under Momora.',
      pill: 'Not allowed', tone: 'neutral',
      primary: isIOS ? 'Open Settings' : 'Open app settings', secondary: 'Back to my journal',
      note: 'You can always add photos to a memory yourself, one at a time.',
    },
    blocked: {
      eyebrow: 'Asked before', title: 'This one has to\nbe changed in\nsettings.',
      body: isIOS
        ? 'iOS only asks once. To let Momora look through your photos, open Settings › Momora › Photos and choose All Photos or Selected Photos.'
        : 'Android only asks twice. To let Momora look through your photos, open Settings › Apps › Momora › Permissions › Photos and videos.',
      pill: 'Needs a settings change', tone: 'neutral',
      primary: isIOS ? 'Open Settings' : 'Open app settings', secondary: 'Not now',
      note: 'Momora will not ask you again here.',
    },
  }[kind];
  return (
    <div style={{ height: '100%', background: TRC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', boxSizing: 'border-box', paddingBottom: 170 }}>
        <GITopBar left="Close" onLeft={onSecondary} platform={platform} onBack={onSecondary}/>
        <div style={{ padding: '10px 24px 0' }}>
          <GIPill tone={map.tone}>{map.pill}</GIPill>
          <Display size={32} style={{ marginTop: 14, whiteSpace: 'pre-line' }}>{map.title}</Display>
          <Body size={14.5} muted style={{ marginTop: 14, lineHeight: 1.6 }}>{map.body}</Body>
        </div>
        {kind === 'limited' && (
          <div style={{ padding: '22px 24px 0' }}>
            <GIRule style={{ marginBottom: 12 }}>The photos you chose</GIRule>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 5 }}>
              {['snow','garden','cake','kitchen','beach','rain','park','sofa','street','bath','garden','cake','snow','beach'].map((s, i) => (
                <GIPhoto key={i} scene={s} seed={(i * 13 % 100) / 100} radius={6} style={{ aspectRatio: '1' }}/>
              ))}
            </div>
          </div>
        )}
        <div style={{ padding: '22px 24px 0' }}>
          <GIReassure>{map.note}</GIReassure>
        </div>
      </div>
      <GIActionBar platform={platform}>
        <Button onClick={onPrimary} style={{ width: '100%' }}>{map.primary}</Button>
        <Button variant="ghost" onClick={onSecondary} style={{ width: '100%' }}>{map.secondary}</Button>
      </GIActionBar>
    </div>
  );
}

Object.assign(window, { GIExplainer, GIOSPrompt, GIPermissionOutcome });
