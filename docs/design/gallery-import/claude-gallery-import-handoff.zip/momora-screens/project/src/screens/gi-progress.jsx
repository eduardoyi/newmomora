// Gallery import — progress, waiting, and every way a run can pause.
const { c: PGC, f: PGF } = window.MOMORA;

const GI_STEPS = ['Looking through your photos', 'Preparing small previews', 'Writing the drafts', 'Ready to review'];

// stage → which step is live, and what the parent needs to understand.
const GI_STAGE = {
  scanning: {
    step: 0, eyebrow: 'Step 1 of 3',
    title: 'Looking through\nyour photos.',
    body: 'Reading dates and grouping photos into events. This part happens entirely on your phone.',
    stat: '3,140 photos so far · 2019 – 2026',
    indeterminate: true, safeToClose: false,
    hint: 'Keep Momora open for another moment — this part needs the app awake.',
  },
  preparing: {
    step: 1, eyebrow: 'Step 2 of 3',
    title: 'Preparing small\npreviews.',
    body: 'Making thumbnail-sized copies of the photos in 96 events. Your originals are untouched.',
    stat: '214 of 388 previews ready',
    value: 214, total: 388, safeToClose: false,
    hint: 'This is the part that uses your battery. A minute or two, usually.',
  },
  waitingWifi: {
    step: 1, eyebrow: 'Waiting', tone: 'sun',
    title: 'Waiting for\nWi-Fi.',
    body: 'The previews are ready and waiting. Momora sends them on Wi-Fi by default to keep off your data plan.',
    stat: '388 previews ready to send · about 46 MB',
    paused: true, safeToClose: true,
    hint: 'It will carry on by itself the moment you are on Wi-Fi.',
    actions: [{ label: 'Use cellular data instead', kind: 'secondary', to: 'cellular' }],
  },
  uploading: {
    step: 1, eyebrow: 'Step 2 of 3',
    title: 'Sending the\npreviews.',
    body: 'Small copies are on their way to Momora and its AI partner. Full-size photos stay here.',
    stat: '31 MB of 46 MB sent', value: 31, total: 46, safeToClose: true,
    hint: 'Safe to close Momora — this keeps going.',
  },
  processing: {
    step: 2, eyebrow: 'Step 3 of 3',
    title: 'Writing the\ndrafts.',
    body: 'Momora is choosing which photos tell each story and writing a title and caption for you to edit.',
    stat: '12 suggestions ready · 8 still coming',
    indeterminate: true, safeToClose: true, ready: 12,
    hint: 'You can start reviewing now. The rest will appear as they finish.',
  },
  ready: {
    step: 3, eyebrow: 'All done looking',
    title: '18 moments,\nready for you.',
    body: 'Momora went through 8,412 photos and found 18 events it feels confident about. Nothing has been added to your journal yet.',
    stat: `Yours to review for the next ${window.GI_RUN.reviewDays} days`,
    done: true, safeToClose: true, ready: 18,
    hint: 'No rush. Your place is saved between visits.',
  },
  paused: {
    step: 1, eyebrow: 'Paused by you', tone: 'sun',
    title: 'Paused.',
    body: 'Nothing is happening until you say so. The previews already made are waiting on your phone.',
    stat: '214 previews waiting · nothing sent yet',
    paused: true, safeToClose: true,
    hint: 'Your camera roll is untouched, as always.',
    actions: [{ label: 'Carry on', kind: 'primary', to: 'preparing' }],
  },
  interrupted: {
    step: 2, eyebrow: 'Picked up again',
    title: 'Carrying on\nwhere it stopped.',
    body: 'Momora closed before this finished. Nothing was lost — it started again from the last event it completed.',
    stat: '12 suggestions safe · 8 to go',
    indeterminate: true, safeToClose: true, ready: 12,
    hint: 'Closing the app, restarting your phone, losing signal — all fine.',
  },
  failed: {
    step: 2, eyebrow: 'Something went wrong', tone: 'error',
    title: 'That did not\nfinish.',
    body: 'Momora could not finish the last few events. The 12 suggestions it already made are safe and ready to review.',
    stat: '12 suggestions ready · 6 events not finished',
    safeToClose: true, ready: 12,
    hint: 'Nothing was added to your journal, and your camera roll is untouched.',
    actions: [{ label: 'Try the rest again', kind: 'secondary', to: 'processing' }],
  },
  cancelled: {
    step: 0, eyebrow: 'Stopped',
    title: 'Stopped, and\ncleaned up.',
    body: 'Momora stopped looking. The previews it had made were deleted, and the drafts are gone. Anything you already kept is still in your journal.',
    stat: '4 memories kept · everything else cleared',
    done: true, safeToClose: true,
    hint: 'Your camera roll was never changed.',
  },
  expired: {
    step: 3, eyebrow: 'Review period ended',
    title: 'These have\ncleared.',
    body: `Suggestions last ${window.GI_RUN.reviewDays} days, then Momora deletes the previews and drafts. The 9 memories you kept are in your journal.`,
    stat: '9 kept · 12 suggestions cleared',
    done: true, safeToClose: true,
    hint: 'You can look through your photos again whenever you like.',
    actions: [{ label: 'Look through my photos again', kind: 'secondary', to: 'scanning' }],
  },
};

function GIProgressScreen({
  stage = 'processing', platform = 'ios', sheet,
  onReview = () => {}, onClose = () => {}, onStage = () => {},
}) {
  const s = GI_STAGE[stage];
  const [open, setOpen] = React.useState(sheet || null);
  const toneColor = s.tone === 'sun' ? PGC.sunInk : s.tone === 'error' ? PGC.error : PGC.primary;

  return (
    <div style={{ height: '100%', background: PGC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', boxSizing: 'border-box', paddingBottom: s.ready || s.actions ? 180 : 130 }}>
        <GITopBar left="Close" onLeft={onClose} platform={platform} onBack={onClose}
          right={!s.done && (
            <button onClick={() => setOpen('stop')} style={{
              border: 'none', background: 'transparent', cursor: 'pointer', padding: '10px 0',
              fontFamily: PGF.sans, fontSize: 14, fontWeight: 600, color: PGC.ink3,
            }}>Stop</button>
          )}/>

        <div style={{ padding: '8px 24px 0' }}>
          <Eyebrow color={toneColor}>{s.eyebrow}</Eyebrow>
          <Display size={34} style={{ marginTop: 12, whiteSpace: 'pre-line' }}>{s.title}</Display>
          <Body size={14.5} muted style={{ marginTop: 14, lineHeight: 1.6 }}>{s.body}</Body>
        </div>

        {/* the workbench — prints being sorted */}
        <GIWorkbench stage={stage}/>

        {/* measured progress, or an honest indeterminate sweep */}
        <div style={{ padding: '0 24px' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 9 }}>
            <Body size={13} style={{ fontWeight: 700, color: PGC.ink }}>{s.stat}</Body>
          </div>
          {!s.done && !s.paused && <GIProgress indeterminate={!!s.indeterminate} value={s.value} total={s.total} tone={toneColor}/>}
          {s.paused && <div style={{ height: 6, borderRadius: 999, background: PGC.border }}/>}
        </div>

        {/* the three steps, so the parent always knows where they are */}
        <div style={{ padding: '24px 24px 0' }}>
          {GI_STEPS.map((label, i) => {
            const done = i < s.step || s.done;
            const active = i === s.step && !s.done;
            return (
              <div key={label} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', paddingBottom: 14 }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                  <div className={active && !s.paused ? 'gi-anim-breathe' : undefined} style={{
                    width: 18, height: 18, borderRadius: '50%',
                    background: done ? PGC.primary : active ? '#fff' : PGC.surface,
                    border: done ? 'none' : `1.5px solid ${active ? toneColor : PGC.border}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    '--gi-dur': '1800ms',
                  }}>
                    {done && <Icon name="check" size={10} color="#fff" strokeWidth={3.2}/>}
                  </div>
                  {i < GI_STEPS.length - 1 && (
                    <div style={{ width: 1.5, flex: 1, minHeight: 16, background: done ? PGC.primarySoft : PGC.border, marginTop: 3 }}/>
                  )}
                </div>
                <Body size={13.5} style={{
                  fontWeight: active ? 700 : 600, color: done ? PGC.ink2 : active ? PGC.ink : PGC.ink3, marginTop: -1,
                }}>{label}</Body>
              </div>
            );
          })}
        </div>

        {/* can I close the app? — answered every time, never implied */}
        <div style={{ padding: '4px 24px 0' }}>
          <div style={{
            background: s.safeToClose ? PGC.seaSoft : PGC.surface, borderRadius: 14, padding: '13px 14px',
            display: 'flex', gap: 10, alignItems: 'flex-start',
          }}>
            <Icon name={s.safeToClose ? 'moon' : 'clock'} size={16} color={s.safeToClose ? PGC.seaInk : PGC.ink2} strokeWidth={1.9} style={{ marginTop: 1, flexShrink: 0 }}/>
            <div style={{ flex: 1 }}>
              <Body size={13} style={{ fontWeight: 700, color: s.safeToClose ? PGC.seaInk : PGC.ink }}>
                {s.safeToClose ? 'Safe to close Momora' : 'Please keep Momora open'}
              </Body>
              <Body size={12.5} style={{ marginTop: 3, lineHeight: 1.45, color: s.safeToClose ? PGC.seaInk : PGC.ink2, opacity: .85 }}>
                {s.hint}
              </Body>
            </div>
          </div>
          <GIReassure style={{ marginTop: 14 }}/>
          <button onClick={() => setOpen('privacy')} style={{
            border: 'none', background: 'transparent', padding: '10px 0', cursor: 'pointer',
            fontFamily: PGF.sans, fontSize: 12.5, fontWeight: 700, color: PGC.primary,
          }}>What Momora sends, and for how long</button>
        </div>
      </div>

      {(s.ready || s.actions || s.done) && (
        <GIActionBar platform={platform}>
          {s.ready
            ? <Button onClick={onReview} style={{ width: '100%' }}>Start reviewing · {s.ready} ready</Button>
            : s.done && !s.actions ? <Button onClick={onClose} style={{ width: '100%' }}>Back to my journal</Button> : null}
          {(s.actions || []).map(a => (
            <Button key={a.label} variant={a.kind === 'primary' ? 'primary' : 'secondary'}
              onClick={() => onStage(a.to)} style={{ width: '100%' }}>{a.label}</Button>
          ))}
        </GIActionBar>
      )}

      {open === 'stop' && (
        <GISheet title="Stop looking through your photos?" onClose={() => setOpen(null)} closeLabel="Keep going"
          subtitle="Nothing you have already kept is affected."
          footer={
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <Button variant="secondary" onClick={() => onStage('cancelled')} style={{ width: '100%' }}>Stop and clear the drafts</Button>
              <Button variant="ghost" onClick={() => setOpen(null)} style={{ width: '100%' }}>Keep going</Button>
            </div>
          }>
          <div style={{ padding: '16px 24px 20px', display: 'flex', flexDirection: 'column', gap: 12 }}>
            <GIFact icon="check" title="Kept memories stay">The 4 memories you have already kept remain in your journal.</GIFact>
            <GIFact icon="trash" title="Drafts and previews are deleted">Every preview Momora made is removed from its storage.</GIFact>
            <GIFact icon="image" title="Your camera roll is untouched">It always was. Stopping changes nothing about your photos.</GIFact>
            <GIFact icon="refresh" title="You can start again later">A new look through your photos will not re-suggest anything you set aside.</GIFact>
          </div>
        </GISheet>
      )}

      {open === 'cellular' && (
        <GISheet title="Send over cellular data?" onClose={() => setOpen(null)} closeLabel="Cancel"
          subtitle="About 46 MB — roughly one short video."
          footer={
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <Button onClick={() => onStage('uploading')} style={{ width: '100%' }}>Use cellular data</Button>
              <Button variant="ghost" onClick={() => setOpen(null)} style={{ width: '100%' }}>Wait for Wi-Fi</Button>
            </div>
          }>
          <div style={{ padding: '16px 24px 20px' }}>
            <Body size={14} style={{ lineHeight: 1.6 }}>
              Momora waits for Wi-Fi by default so a big first import never eats your data plan.
              If you would rather not wait, it will send now and remember this choice for this
              import only.
            </Body>
            <GIReassure style={{ marginTop: 16 }}>Only the small previews are sent. Full-size photos are only uploaded for memories you keep.</GIReassure>
          </div>
        </GISheet>
      )}

      {open === 'privacy' && (
        <GISheet title="What Momora sends" onClose={() => setOpen(null)}>
          <div style={{ padding: '16px 24px 26px', display: 'flex', flexDirection: 'column', gap: 14 }}>
            <GIFact icon="image" title="Small previews, now">Thumbnail-sized copies go to Momora's private storage and its AI partner so the drafts can be written.</GIFact>
            <GIFact icon="check" title="Full-size photos, only when you keep one">Nothing full-size is uploaded until you approve a suggestion.</GIFact>
            <GIFact icon="trash" title={`Deleted within ${window.GI_RUN.reviewDays} days`}>Sooner if you finish or stop. Location data is stripped from anything saved.</GIFact>
            <GIFact icon="x" title="Never sent">Names, ages, relationships, location, file names, or anything already written in Momora.</GIFact>
          </div>
        </GISheet>
      )}
    </div>
  );
}

// A quiet visual of prints being sorted — no spinner theatre.
function GIWorkbench({ stage }) {
  const idle = ['cancelled', 'expired', 'paused', 'waitingWifi'].includes(stage);
  const scenes = ['snow', 'garden', 'cake', 'kitchen', 'beach', 'rain'];
  return (
    <div style={{ padding: '26px 24px 22px' }}>
      <div style={{
        background: '#fff', border: `1px solid ${PGC.border}`, borderRadius: 18, padding: 14,
        display: 'flex', gap: 7, alignItems: 'flex-end', overflow: 'hidden', position: 'relative',
      }}>
        {scenes.map((sc, i) => {
          const h = [58, 78, 96, 70, 52, 44][i];
          const settled = idle || i < 3;
          return (
            <GIPhoto key={i} scene={sc} seed={(i * 17 % 100) / 100} radius={8}
              className={settled || idle ? undefined : 'gi-anim-breathe'}
              style={{
                flex: 1, height: h, opacity: settled ? 1 : 0.42,
                transform: `rotate(${(i % 2 ? 1 : -1) * (idle ? 0 : 1.2)}deg)`,
                '--gi-dur': `${1400 + i * 260}ms`,
              }}/>
          );
        })}
        {!idle && (
          <div className="gi-anim-sweep" style={{
            position: 'absolute', top: 0, bottom: 0, width: '30%',
            background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.55), transparent)',
            '--gi-dur': '2600ms',
          }}/>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { GIProgressScreen, GIWorkbench, GI_STAGE });
