// Gallery import — keeping a suggestion.
// This IS the memory composer: same header, date pill, serif field, photo grid,
// tag strip and toolbar as New/Edit memory. Everything happens in one step —
// words, photos, date and who is in it — and Save writes the memory.
const { c: AC, f: AF } = window.MOMORA;

// state: review | downloading | unavailable | posting
function GIKeepMemory({
  candId = 'c3', state = 'review', platform = 'ios',
  onBack = () => {}, onSave = () => {}, pickerOpen = false, chooserOpen = false,
}) {
  const base = window.giCandidate(candId);
  const [text, setText] = React.useState(base.caption);
  const [edited, setEdited] = React.useState(false);
  const [cand, setCand] = React.useState({ ...base });
  const [tagged, setTagged] = React.useState(['lila']);
  const [chooser, setChooser] = React.useState(chooserOpen);
  const items = cand.pool.filter(p => cand.selected.includes(p.id));
  const MAX = 10;
  const missing = state === 'unavailable';
  const busy = state === 'posting';

  const removeAt = (i) => setCand(c => c.selected.length === 1 ? c
    : { ...c, selected: c.selected.filter((_, j) => j !== i) });

  return (
    <div style={{ height: '100%', background: AC.bg, display: 'flex', flexDirection: 'column', position: 'relative' }}>

      {/* header — Cancel · type badge · Save */}
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <button onClick={onBack} style={{
          background: 'none', border: 'none', cursor: 'pointer', padding: 0,
          fontFamily: AF.sans, fontSize: 16, fontWeight: 600, color: AC.primary,
        }}>Cancel</button>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 5, background: AC.surface,
          border: `1px solid ${AC.border}`, borderRadius: 999, padding: '5px 11px 5px 8px',
        }}>
          <Icon name="camera" size={12} color={AC.ink2} strokeWidth={2}/>
          <span style={{ fontFamily: AF.sans, fontSize: 12, fontWeight: 700, color: AC.ink2 }}>
            {items.length === 1 ? 'Photo' : 'Photos'}
          </span>
        </div>
        <button onClick={busy ? undefined : onSave} style={{
          background: 'none', border: 'none', cursor: busy ? 'default' : 'pointer', padding: 0,
          fontFamily: AF.sans, fontSize: 16, fontWeight: 700, color: busy ? AC.ink3 : AC.primary,
        }}>{busy ? 'Saving…' : 'Save'}</button>
      </div>

      {/* date pill — the day the photos were taken, not today */}
      <div style={{ padding: '14px 20px 0', display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
        <button style={{
          background: '#fff', border: `1px solid ${AC.border}`, borderRadius: 999,
          padding: '6px 13px', fontFamily: AF.sans, fontSize: 13, fontWeight: 600,
          color: AC.ink2, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 7,
        }}>
          <Icon name="calendar" size={13} color={AC.ink2}/>
          {window.giFmtDate(cand.date)}
          <Icon name="chevronDown" size={13} color={AC.ink2}/>
        </button>
        <GIPill tone="soft" style={{ fontSize: 11 }}>From the photos</GIPill>
      </div>

      {/* the memory text — one serif field, Momora's draft, yours to change */}
      <div style={{
        padding: '14px 20px 0', flex: '1 1 auto', minHeight: 118,
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
      }}>
        <textarea value={text} onChange={e => { setEdited(true); setText(e.target.value); }}
          placeholder="What happened?"
          style={{
            width: '100%', background: 'transparent', border: 'none', outline: 'none',
            fontFamily: AF.display, fontWeight: 400, fontSize: 21, lineHeight: 1.42,
            color: AC.ink, resize: 'none', boxSizing: 'border-box', flex: '1 1 auto', minHeight: 0,
          }}/>
        {edited ? (
          <button onClick={() => { setText(base.caption); setEdited(false); }} style={{
            alignSelf: 'flex-start', border: 'none', background: 'transparent', padding: '2px 0', cursor: 'pointer',
            fontFamily: AF.sans, fontSize: 12, fontWeight: 700, color: AC.primary,
          }}>Restore Momora's draft</button>
        ) : (
          <Body size={11.5} muted>Momora wrote this from the photos. Change anything.</Body>
        )}
      </div>

      {/* something that needs saying before saving */}
      {(state === 'downloading' || missing || busy) && (
        <div style={{ padding: '10px 20px 0', flexShrink: 0 }}>
          {state === 'downloading' && (
            <GINotice tone="sea" icon="refresh" title="Getting the full-size photos"
              body="Two of these live in iCloud. Saving will finish once they are here — you can close Momora."/>
          )}
          {missing && (
            <GINotice tone="sun" icon="alert" title="One photo is not on this phone any more"
              body="It was removed from your camera roll, or Momora is no longer allowed to see it. Swap in another from that day, or save the rest."
              action="Choose another photo"/>
          )}
          {busy && (
            <GINotice tone="soft" icon="check" title="Saving to your journal"
              body="Uploading photo 2 of 4 at full size. Safe to close Momora — it will finish on its own."/>
          )}
        </div>
      )}

      {/* photos — same grid as the multi-media composer. It is the block that
          yields when the keyboard is up, so the toolbar never leaves the screen. */}
      <div style={{ flex: '0 1 auto', minHeight: 0, padding: '10px 20px 0', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <Eyebrow color={AC.ink3} style={{ fontSize: 10 }}>Photos from that day</Eyebrow>
          <span style={{ fontFamily: AF.sans, fontSize: 12, fontWeight: 700, color: AC.ink2 }}>
            {items.length}/{MAX}
          </span>
        </div>
        <div style={{ flex: 1, minHeight: 0, maxHeight: 210, overflowY: 'auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
            {items.map((p, i) => (
              <div key={p.id} style={{ position: 'relative', aspectRatio: '1', borderRadius: 12, overflow: 'hidden' }}>
                <GIPhoto scene={p.scene} seed={p.seed} radius={12} style={{ position: 'absolute', inset: 0 }}
                  dim={missing && i === 1}/>
                {missing && i === 1 && (
                  <div style={{
                    position: 'absolute', inset: 0, borderRadius: 12, border: `1.5px dashed ${AC.borderStrong}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <Icon name="alert" size={16} color={AC.ink2} strokeWidth={2}/>
                  </div>
                )}
                <div style={{
                  position: 'absolute', bottom: 5, right: 5, background: 'rgba(0,0,0,0.44)',
                  borderRadius: 999, padding: '1px 6px', pointerEvents: 'none',
                }}>
                  <span style={{ fontFamily: AF.sans, fontSize: 10, fontWeight: 700, color: '#fff' }}>{i + 1}</span>
                </div>
                <button onClick={() => removeAt(i)} aria-label={`Remove photo ${i + 1}`} style={{
                  position: 'absolute', top: 5, right: 5, width: 22, height: 22, borderRadius: '50%',
                  background: 'rgba(0,0,0,0.52)', border: 'none', cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Icon name="x" size={11} color="#fff" strokeWidth={2.5}/>
                </button>
              </div>
            ))}
            {items.length < MAX && (
              <button onClick={() => setChooser(true)} style={{
                aspectRatio: '1', borderRadius: 12, border: `2px dashed ${AC.borderStrong}`,
                background: AC.surface, cursor: 'pointer', display: 'flex', flexDirection: 'column',
                alignItems: 'center', justifyContent: 'center', gap: 4,
              }}>
                <Icon name="plus" size={20} color={AC.ink3} strokeWidth={2}/>
                <span style={{ fontFamily: AF.sans, fontSize: 10, fontWeight: 600, color: AC.ink3 }}>Add</span>
              </button>
            )}
          </div>
          <div style={{ textAlign: 'center', marginTop: 8, paddingBottom: 4 }}>
            <span style={{ fontFamily: AF.sans, fontSize: 11, color: AC.ink3 }}>
              {cand.poolCount} photos from this day · removing one changes only this memory
            </span>
          </div>
        </div>
      </div>

      {/* who is in it — unlimited for photo memories, and Momora never guesses */}
      <div style={{ flexShrink: 0 }}>
        <WhosInIt tagged={tagged} setTagged={setTagged} max={window.MOMORA_MOCK.family.length}
          showCap={false} label="Who is in it" defaultOpen={pickerOpen}/>
      </div>

      {/* toolbar — mic and photos. No illustration toggle: imports never generate one. */}
      <div style={{
        padding: '13px 20px 28px', borderTop: `1px solid ${AC.border}`, marginTop: 12,
        display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0,
      }}>
        <button aria-label="Dictate" style={{
          width: 46, height: 46, borderRadius: '50%', flexShrink: 0, background: '#fff',
          border: `1px solid ${AC.border}`, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="mic" size={20} color={AC.sea} strokeWidth={2}/>
        </button>
        <button onClick={() => setChooser(true)} aria-label="Choose photos from that day" style={{
          width: 46, height: 46, borderRadius: '50%', flexShrink: 0, background: '#fff',
          border: `1px solid ${AC.border}`, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="camera" size={20} color={AC.ink2} strokeWidth={1.75}/>
        </button>
        <div style={{ flex: 1, textAlign: 'right' }}>
          <Body size={11} muted style={{ lineHeight: 1.4 }}>
            Saves on {window.giFmtShort(cand.date)}, not today.<br/>Your camera roll is not changed.
          </Body>
        </div>
      </div>

      {chooser && <GIPhotoChooser cand={cand} onChange={setCand} onClose={() => setChooser(false)}/>}
    </div>
  );
}

// ── Saved ────────────────────────────────────────────────────────
function GIApproveSuccess({ candId = 'c3', platform = 'ios', nextCount = 7, onNext = () => {}, onStop = () => {} }) {
  const cand = window.giCandidate(candId);
  const sel = cand.pool.filter(p => cand.selected.includes(p.id));
  return (
    <div style={{ height: '100%', background: AC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', boxSizing: 'border-box', paddingBottom: 172 }}>
        <GITopBar left="Close" onLeft={onStop} platform={platform} onBack={onStop}/>
        <div style={{ padding: '14px 24px 0' }}>
          <Eyebrow>Kept</Eyebrow>
          <Display size={34} style={{ marginTop: 12 }}>It is in your<br/>journal now.</Display>
          <Body size={14.5} muted style={{ marginTop: 14, lineHeight: 1.6 }}>
            Filed under {window.giFmtDate(cand.date)}, with {sel.length} photos at full size.
          </Body>
        </div>
        <div style={{ padding: '22px 20px 0' }}>
          <div style={{
            background: '#fff', border: `1px solid ${AC.border}`, borderRadius: 18, padding: 12,
            boxShadow: '0 14px 30px rgba(40,30,20,0.08)', animation: 'giRise 380ms cubic-bezier(.22,.61,.36,1) both',
          }}>
            <GIPhoto scene={sel[0].scene} seed={sel[0].seed} radius={12} style={{ width: '100%', height: 168 }}/>
            <div style={{ padding: '12px 4px 2px' }}>
              <div style={{
                fontFamily: AF.display, fontWeight: 400, fontSize: 18, lineHeight: 1.42,
                letterSpacing: '-0.008em', color: AC.ink, textWrap: 'pretty',
              }}>{cand.caption}</div>
              <div style={{ marginTop: 9, display: 'flex', alignItems: 'center', gap: 8 }}>
                <Avatar name="Lila" size={22} tint="tender"/>
                <Body size={12} muted style={{ flex: 1 }}>{window.giFmtDate(cand.date)} · {sel.length} photos</Body>
              </div>
            </div>
          </div>
        </div>
        <div style={{ padding: '22px 24px 0' }}>
          <div style={{ background: AC.surface, borderRadius: 14, padding: 14 }}>
            <Body size={13} style={{ fontWeight: 700 }}>Your family will get one summary</Body>
            <Body size={12.5} muted style={{ marginTop: 4, lineHeight: 1.5 }}>
              Not one alert per memory. Momora waits until you have finished, then tells them once.
            </Body>
          </div>
        </div>
      </div>
      <GIActionBar platform={platform}>
        <Button onClick={onNext} style={{ width: '100%' }}>Next suggestion · {nextCount} left</Button>
        <Button variant="ghost" onClick={onStop} style={{ width: '100%' }}>That is enough for now</Button>
      </GIActionBar>
    </div>
  );
}

// ── Posting strip — survives leaving the flow, like a pending post ──
function GIPostingStrip({ title = 'Pancake Saturday, batter on the counter', n = 2, total = 4, failed = false, style = {} }) {
  return (
    <div style={{
      background: '#fff', border: `1px solid ${failed ? AC.errorSoft : AC.border}`, borderRadius: 16,
      padding: 13, display: 'flex', alignItems: 'center', gap: 12,
      boxShadow: '0 10px 24px rgba(40,30,20,0.08)', ...style,
    }}>
      <div style={{
        width: 40, height: 40, borderRadius: 12, flexShrink: 0,
        background: failed ? AC.errorSoft : AC.primaryTint,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name={failed ? 'alert' : 'image'} size={18} color={failed ? AC.error : AC.primary} strokeWidth={1.9}/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <Body size={13.5} style={{ fontWeight: 700, lineHeight: 1.3 }}>
          {failed ? 'Could not finish saving' : 'Saving to your journal'}
        </Body>
        <Body size={11.5} muted style={{ marginTop: 2 }}>
          {failed ? `${window.giExcerpt(title, 34)} · nothing was lost` : `${window.giExcerpt(title, 30)} · photo ${n} of ${total}`}
        </Body>
        {!failed && <div style={{ marginTop: 7 }}><GIProgress value={n} total={total} height={4}/></div>}
      </div>
      {failed && <Button size="sm" variant="secondary">Try again</Button>}
    </div>
  );
}

// Kept for existing references — the keep step is the composer now.
const GIFinalReview = GIKeepMemory;

Object.assign(window, { GIKeepMemory, GIFinalReview, GIApproveSuccess, GIPostingStrip });
