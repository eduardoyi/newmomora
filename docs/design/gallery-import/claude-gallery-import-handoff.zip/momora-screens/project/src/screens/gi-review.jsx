// Gallery import — the review deck.
// Right = keep (opens final review). Left = set aside (recoverable, never deleting).
const { c: RC, f: RF } = window.MOMORA;

// ── Gesture plumbing ─────────────────────────────────────────────
function useSwipeCard({ onKeep, onAside, reduced = false, threshold = 92 }) {
  const [dx, setDx] = React.useState(0);
  const [drag, setDrag] = React.useState(false);
  const [exit, setExit] = React.useState(null);
  const start = React.useRef(0);
  const fire = (dir) => {
    setExit(dir);
    setDx(0); setDrag(false);
    window.setTimeout(() => { setExit(null); dir === 'keep' ? onKeep() : onAside(); }, reduced ? 90 : 240);
  };
  const handlers = {
    onPointerDown: (e) => { setDrag(true); start.current = e.clientX; try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) {} },
    onPointerMove: (e) => { if (drag) setDx(e.clientX - start.current); },
    onPointerUp: () => {
      if (Math.abs(dx) > threshold) fire(dx > 0 ? 'keep' : 'aside');
      else { setDx(0); setDrag(false); }
    },
    onPointerCancel: () => { setDx(0); setDrag(false); },
  };
  return { dx, drag, exit, handlers, fire };
}

// The intent label that rides along with the drag.
function SwipeIntent({ dx, side, reduced }) {
  const keep = side === 'keep';
  const active = keep ? dx > 26 : dx < -26;
  const strength = Math.min(1, Math.abs(dx) / 110);
  return (
    <div style={{
      position: 'absolute', top: 18, [keep ? 'right' : 'left']: 18, zIndex: 5,
      opacity: reduced ? (active ? 1 : 0) : (active ? strength : 0),
      transform: reduced ? 'none' : `rotate(${keep ? -6 : 6}deg) scale(${0.9 + strength * 0.1})`,
      transition: 'opacity 140ms',
      padding: '7px 14px', borderRadius: 999,
      background: keep ? RC.primary : '#fff',
      border: keep ? 'none' : `1.5px solid ${RC.borderStrong}`,
      color: keep ? '#fff' : RC.ink2,
      fontFamily: RF.sans, fontSize: 12.5, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase',
      boxShadow: keep ? '0 8px 20px rgba(214,62,120,0.34)' : '0 6px 16px rgba(40,30,20,0.10)',
      pointerEvents: 'none',
    }}>{keep ? 'Keep' : 'Set aside'}</div>
  );
}

// ── Deck chrome shared by both directions ────────────────────────
function GIDeckBar({ index, total, processing, aside, onClose, onList, platform = 'ios' }) {
  return (
    <React.Fragment>
      <GITopBar left="Close" onLeft={onClose} platform={platform} onBack={onClose}
        right={
          <button onClick={onList} aria-label={`Set aside, ${aside} suggestions`} style={{
            display: 'flex', alignItems: 'center', gap: 6, border: `1px solid ${RC.border}`,
            background: '#fff', borderRadius: 999, padding: '7px 12px', cursor: 'pointer',
            fontFamily: RF.sans, fontSize: 12.5, fontWeight: 700, color: RC.ink2,
          }}>
            <Icon name="history" size={14} color={RC.ink2} strokeWidth={1.9}/>
            Set aside · {aside}
          </button>
        }/>
      <div style={{ padding: '2px 24px 0', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ display: 'flex', gap: 4, alignItems: 'center', flex: 1 }}>
          {Array.from({ length: total }).map((_, i) => (
            <div key={i} style={{
              flex: 1, height: 3, borderRadius: 999, maxWidth: 26,
              background: i < index ? RC.primary : i === index ? RC.primarySoft : RC.border,
            }}/>
          ))}
          {processing > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginLeft: 6 }}>
              <span className="gi-anim-breathe" style={{ width: 6, height: 6, borderRadius: 999, background: RC.sea }}/>
              <span style={{ fontFamily: RF.sans, fontSize: 11.5, color: RC.ink3, whiteSpace: 'nowrap' }}>+{processing} coming</span>
            </div>
          )}
        </div>
      </div>
    </React.Fragment>
  );
}

// ── The deck — “the print” ───────────────────────────────────────
// One suggestion, handled like a photograph laid on the table. The event's other
// photos sit beneath as a film strip you can open. Keeping opens the memory
// composer; nothing is edited here.
function GIDeckPrint({
  startIndex = 0, platform = 'ios', reduced = false, sheet: initialSheet, frozen = false, demoDx = null,
  onKeep = () => {}, onAside = () => {}, onClose = () => {}, onDone = () => {},
}) {
  const all = window.GI_CANDIDATES;
  const [i, setI] = React.useState(startIndex);
  const [kept, setKept] = React.useState(4);
  const [aside, setAside] = React.useState(3);
  const [sheet, setSheet] = React.useState(initialSheet || null);
  const [cand, setCand] = React.useState(() => ({ ...all[startIndex] }));

  React.useEffect(() => { setCand({ ...all[i % all.length] }); }, [i]);

  const advance = () => setI(n => n + 1);
  const { dx: dragDx, drag, exit, handlers, fire } = useSwipeCard({
    onKeep: () => { setKept(k => k + 1); onKeep(cand); advance(); },
    onAside: () => { setAside(a => a + 1); onAside(cand); advance(); },
    reduced,
  });
  const dx = demoDx != null ? demoDx : dragDx;

  if (i >= all.length) return <GIDeckDone kept={kept} aside={aside} onClose={onClose} onDone={onDone} platform={platform}/>;

  const sel = cand.pool.filter(p => cand.selected.includes(p.id));
  const hero = sel[0] || cand.pool[0];
  const rot = reduced ? 0 : dx / 28;
  const tx = exit ? (exit === 'keep' ? 460 : -460) : dx;

  return (
    <div style={{ height: '100%', background: RC.bg, position: 'relative', overflow: 'hidden' }}>
      <GIDeckBar index={i} total={Math.min(all.length, 12)} processing={6} aside={aside}
        onClose={onClose} onList={() => setSheet('aside')} platform={platform}/>

      <div style={{ position: 'absolute', left: 0, right: 0, top: platform === 'android' ? 96 : 106, bottom: 116, padding: '0 20px' }}>
        {/* the next print, peeking */}
        <div style={{
          position: 'absolute', left: 30, right: 30, top: 12, bottom: 6, background: '#fff',
          border: `1px solid ${RC.border}`, borderRadius: 20, transform: 'rotate(-1.4deg)',
        }}/>
        <div style={{
          position: 'absolute', left: 25, right: 25, top: 6, bottom: 4, background: '#fff',
          border: `1px solid ${RC.border}`, borderRadius: 20, transform: 'rotate(1deg)',
        }}/>

        {/* the live card */}
        <div {...(frozen ? {} : handlers)} style={{
          position: 'absolute', inset: 0, background: '#fff', border: `1px solid ${RC.border}`,
          borderRadius: 20, padding: 12, overflow: 'hidden', touchAction: 'pan-y',
          boxShadow: '0 20px 40px rgba(40,30,20,0.10)',
          transform: `translateX(${tx}px) rotate(${exit ? (exit === 'keep' ? 8 : -8) : rot}deg)`,
          opacity: exit && reduced ? 0 : 1,
          transition: drag ? 'none' : `transform ${reduced ? 120 : 260}ms cubic-bezier(.22,.61,.36,1), opacity 160ms`,
          cursor: frozen ? 'default' : 'grab', display: 'flex', flexDirection: 'column',
        }}>
          <SwipeIntent dx={dx} side="keep" reduced={reduced}/>
          <SwipeIntent dx={dx} side="aside" reduced={reduced}/>

          <GIPhoto scene={hero.scene} seed={hero.seed} radius={14}
            style={{ width: '100%', flex: '1 1 auto', minHeight: 0 }}/>

          {/* the event's other photos */}
          <button onClick={() => setSheet('photos')} style={{
            marginTop: 10, display: 'flex', alignItems: 'center', gap: 8, background: 'transparent',
            border: 'none', padding: 0, cursor: 'pointer', textAlign: 'left', width: '100%',
          }}>
            <div style={{ display: 'flex', gap: 4 }}>
              {sel.slice(1, 4).map(p => (
                <GIPhoto key={p.id} scene={p.scene} seed={p.seed} radius={6} style={{ width: 38, height: 38 }}/>
              ))}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <Body size={12.5} style={{ fontWeight: 700, color: RC.ink2 }}>
                {sel.length} photos chosen
              </Body>
              <Body size={11.5} muted>from {cand.poolCount} photos that day</Body>
            </div>
            <Icon name="chevronRight" size={15} color={RC.ink3}/>
          </button>

          <div style={{ height: 1, background: RC.border, margin: '11px 0 12px' }}/>

          <div style={{ paddingBottom: 2 }}>
            <Eyebrow color={RC.ink3} style={{ fontSize: 10 }}>{cand.dateLabel}</Eyebrow>
            <div style={{
              fontFamily: RF.display, fontWeight: 400, fontSize: 19, lineHeight: 1.42,
              letterSpacing: '-0.008em', color: RC.ink, marginTop: 8, textWrap: 'pretty',
              display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden',
            }}>{cand.caption}</div>
          </div>
        </div>
      </div>

      {/* accessible equivalents — never gesture-only */}
      <GIActionBar platform={platform} style={{ gap: 8 }}>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <Button variant="secondary" onClick={() => fire('aside')} style={{ flex: 1 }}
            icon={<Icon name="x" size={16} strokeWidth={2}/>}>Set aside</Button>
          <Button onClick={() => fire('keep')} style={{ flex: 1.25 }}
            icon={<Icon name="check" size={16} strokeWidth={2.4}/>}>Keep this</Button>
        </div>
        <Body size={11.5} muted style={{ textAlign: 'center', lineHeight: 1.45, padding: '0 6px' }}>
          Keeping opens the memory so you can change the words, photos, date and who is in it
          before it is saved.
        </Body>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <GILedger kept={kept} aside={aside} processing={6}/>
        </div>
      </GIActionBar>

      {sheet === 'photos' && <GIPhotoChooser cand={cand} onChange={setCand} onClose={() => setSheet(null)}/>}
      {sheet === 'aside' && <GISetAsideSheet onClose={() => setSheet(null)}/>}
    </div>
  );
}

// ── A place to stop ──────────────────────────────────────────────
function GIRestPoint({ kept = 6, left = 7, processing = 4, platform = 'ios', onContinue = () => {}, onStop = () => {} }) {
  return (
    <div style={{ height: '100%', background: RC.bg, position: 'relative', overflow: 'hidden' }}>
      <GITopBar left="Close" onLeft={onStop} platform={platform} onBack={onStop}/>
      <div style={{ padding: '14px 24px 0' }}>
        <Eyebrow>Six in a row</Eyebrow>
        <Display size={34} style={{ marginTop: 12 }}>That is {kept}<br/>new memories.</Display>
        <Body size={14.5} muted style={{ marginTop: 14, lineHeight: 1.6 }}>
          They are in your journal now, filed under the day they happened — not today.
          There are {left} more ready when you want them, and {processing} still coming.
        </Body>
      </div>
      <div style={{ padding: '24px 24px 0', display: 'flex', gap: 7 }}>
        {window.GI_CANDIDATES.slice(0, 6).map((c, n) => (
          <GIPhoto key={c.id} scene={c.pool[0].scene} seed={c.pool[0].seed} radius={8}
            style={{ flex: 1, height: 74, transform: `rotate(${(n % 2 ? 1 : -1) * 1.4}deg)` }}/>
        ))}
      </div>
      <div style={{ padding: '26px 24px 0' }}>
        <div style={{ background: '#fff', border: `1px solid ${RC.border}`, borderRadius: 16, padding: 15 }}>
          <Body size={13.5} style={{ fontWeight: 700 }}>Your place is saved</Body>
          <Body size={12.5} muted style={{ marginTop: 4, lineHeight: 1.5 }}>
            Stop here and pick up from the Timeline whenever you like — tonight, next week,
            any time in the next {window.GI_RUN.reviewDays} days.
          </Body>
        </div>
        <GIReassure style={{ marginTop: 16 }}/>
      </div>
      <GIActionBar platform={platform}>
        <Button onClick={onContinue} style={{ width: '100%' }}>Keep going · {left} ready</Button>
        <Button variant="ghost" onClick={onStop} style={{ width: '100%' }}>That is enough for now</Button>
      </GIActionBar>
    </div>
  );
}

function GIDeckDone({ kept = 9, aside = 3, processing = 0, platform = 'ios', onClose = () => {}, onDone = () => {} }) {
  return (
    <div style={{ height: '100%', background: RC.bg, position: 'relative', overflow: 'hidden' }}>
      <GITopBar left="Close" onLeft={onClose} platform={platform} onBack={onClose}/>
      <div style={{ padding: '14px 24px 0' }}>
        <Eyebrow>All caught up</Eyebrow>
        <Display size={36} style={{ marginTop: 12 }}>{kept} memories,<br/>from years<br/>you already had.</Display>
        <Body size={14.5} muted style={{ marginTop: 14, lineHeight: 1.6 }}>
          They are in your journal on the days they happened. Your family gets one quiet
          summary — not {kept} notifications.
        </Body>
      </div>
      <div style={{ padding: '24px 24px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 7 }}>
          {window.GI_CANDIDATES.slice(0, 6).map(c => (
            <GIPhoto key={c.id} scene={c.pool[0].scene} seed={c.pool[0].seed} radius={10} style={{ aspectRatio: '1' }}/>
          ))}
        </div>
      </div>
      <div style={{ padding: '22px 24px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <GIPill tone="soft">{aside} set aside</GIPill>
          <Body size={12.5} muted style={{ flex: 1, lineHeight: 1.45 }}>
            Kept for {window.GI_RUN.reviewDays} days if you change your mind. They will not come back in a future look.
          </Body>
        </div>
        <GIReassure style={{ marginTop: 16 }}/>
      </div>
      <GIActionBar platform={platform}>
        <Button onClick={onDone} style={{ width: '100%' }}>See them in my journal</Button>
        <Button variant="ghost" onClick={onClose} style={{ width: '100%' }}>Look at the {aside} I set aside</Button>
      </GIActionBar>
    </div>
  );
}

Object.assign(window, { GIDeckPrint, GIRestPoint, GIDeckDone, useSwipeCard });
