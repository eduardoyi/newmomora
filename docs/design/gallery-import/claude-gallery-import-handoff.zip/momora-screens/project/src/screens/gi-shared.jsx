// Gallery import — shared parts. Photo stand-ins, chrome, sheets, ledgers.
const { c: GC, f: GF, s: GS, r: GR } = window.MOMORA;

if (!document.getElementById('gi-anim')) {
  const st = document.createElement('style');
  st.id = 'gi-anim';
  st.textContent =
    '@keyframes giFade{from{opacity:0}to{opacity:1}}' +
    '@keyframes giSlide{from{transform:translateY(102%)}to{transform:translateY(0)}}' +
    '@keyframes giRise{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}' +
    '@keyframes giSweep{0%{transform:translateX(-46%)}100%{transform:translateX(146%)}}' +
    '@keyframes giBreathe{0%,100%{opacity:.5}50%{opacity:.9}}' +
    // Looping motion only runs inside a .gi-live artboard, so a board full of
    // stills does not keep a hundred animations alive.
    '.gi-anim-breathe,.gi-anim-sweep{animation:none}' +
    '.gi-live .gi-anim-breathe{animation:giBreathe var(--gi-dur,1600ms) ease-in-out infinite}' +
    '.gi-live .gi-anim-sweep{animation:giSweep var(--gi-dur,1900ms) cubic-bezier(.4,0,.6,1) infinite}';
  document.head.appendChild(st);
}

// ── Photo stand-in ───────────────────────────────────────────────
// A warm wash in the scene's colour family with a soft vignette. Deliberately
// not a drawn character — real photos drop in here. One layer, no blend modes:
// hundreds of these render at once on the canvas.
function GIPhoto({ scene = 'garden', seed = 0.4, style = {}, radius = 10, stamp, dim = false, blur = 0, className, children }) {
  const t = window.GI_TONES[scene] || window.GI_TONES.garden;
  const ang = 120 + Math.round(seed * 110);
  const x = 20 + seed * 60, y = 14 + seed * 30;
  return (
    <div className={className} style={{
      position: 'relative', overflow: 'hidden', borderRadius: radius,
      background: `
        radial-gradient(ellipse at 52% 34%, rgba(255,255,255,0.28) 0%, transparent 56%),
        radial-gradient(ellipse 46% 42% at ${34 + seed * 30}% 62%, rgba(74,58,44,0.20) 0%, transparent 72%),
        radial-gradient(ellipse at 50% 116%, rgba(78,60,44,0.26) 0%, transparent 60%),
        radial-gradient(circle at 78% 76%, rgba(110,90,72,0.16) 0%, transparent 52%),
        radial-gradient(ellipse at ${x}% ${y}%, ${t.c} 0%, transparent 58%),
        radial-gradient(ellipse at ${78 - seed * 40}% 82%, ${t.b} 0%, transparent 56%),
        linear-gradient(${ang}deg, ${t.a} 0%, ${t.b} 62%, ${t.c} 100%)`,
      filter: blur ? `blur(${blur}px)` : undefined,
      ...style,
    }}>
      {dim && <div style={{ position: 'absolute', inset: 0, background: 'rgba(250,250,253,0.62)' }}/>}
      {stamp && (
        <div style={{
          position: 'absolute', bottom: 8, right: 10, fontFamily: GF.script,
          fontSize: 17, fontWeight: 600, color: 'rgba(60,44,30,0.62)', transform: 'rotate(-4deg)',
        }}>{stamp}</div>
      )}
      {children}
    </div>
  );
}

// ── Screen chrome ────────────────────────────────────────────────
// iOS: text "Cancel" on the left, per the Momora layout rules.
function GITopBar({ left = 'Cancel', onLeft, title, right, platform = 'ios', onBack, style = {} }) {
  const android = platform === 'android';
  return (
    <div style={{
      paddingTop: android ? 42 : 54, paddingLeft: android ? 12 : 20, paddingRight: 20, paddingBottom: 6,
      display: 'flex', alignItems: 'center', gap: android ? 6 : 12, minHeight: 44, ...style,
    }}>
      {android ? (
        <button onClick={onBack || onLeft} aria-label="Back" style={{
          width: 44, height: 44, borderRadius: '50%', border: 'none', background: 'transparent',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0,
        }}>
          <Icon name="chevronLeft" size={22} color={GC.ink} strokeWidth={2}/>
        </button>
      ) : (
        <button onClick={onLeft} style={{
          border: 'none', background: 'transparent', cursor: 'pointer', padding: '10px 0',
          fontFamily: GF.sans, fontSize: 15.5, fontWeight: 600, color: GC.primary, flexShrink: 0,
        }}>{left}</button>
      )}
      {title && (
        <div style={{
          flex: 1, fontFamily: GF.sans, fontSize: 15, fontWeight: 700, color: GC.ink,
          textAlign: android ? 'left' : 'center', paddingLeft: android ? 4 : 0,
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>{title}</div>
      )}
      {!title && <div style={{ flex: 1 }}/>}
      <div style={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: 8 }}>{right}</div>
    </div>
  );
}

// The one line that has to be true on every screen of this flow.
function GIReassure({ children = 'Your camera roll is never changed.', style = {}, tone = 'ink3' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 7, ...style }}>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={GC.sea} strokeWidth="1.9"
        strokeLinecap="round" strokeLinejoin="round" style={{ marginTop: 2, flexShrink: 0 }}>
        <path d="M12 3l7 3v6c0 4.2-2.9 7.6-7 9-4.1-1.4-7-4.8-7-9V6l7-3z"/><path d="M9 12l2 2 4-4"/>
      </svg>
      <div style={{ fontFamily: GF.sans, fontSize: 12.5, lineHeight: 1.45, color: tone === 'ink2' ? GC.ink2 : GC.ink3 }}>
        {children}
      </div>
    </div>
  );
}

// ── Bottom sheet ─────────────────────────────────────────────────
function GISheet({ title, subtitle, children, onClose, footer, maxHeight = '88%', closeLabel = 'Done' }) {
  return (
    <React.Fragment>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, zIndex: 40, background: 'rgba(36,28,18,0.34)',
        animation: 'giFade 200ms ease-out both',
      }}/>
      <div role="dialog" aria-label={title} style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 41, maxHeight,
        display: 'flex', flexDirection: 'column', background: '#fff',
        borderTopLeftRadius: 24, borderTopRightRadius: 24,
        boxShadow: '0 -14px 44px rgba(40,30,20,0.22)',
        animation: 'giSlide 320ms cubic-bezier(.22,.61,.36,1) both',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '10px 0 2px', flexShrink: 0 }}>
          <div style={{ width: 38, height: 5, borderRadius: 999, background: GC.border }}/>
        </div>
        {title && (
          <div style={{ padding: '8px 24px 0', display: 'flex', alignItems: 'flex-start', gap: 12, flexShrink: 0 }}>
            <div style={{ flex: 1 }}>
              <Title size={22}>{title}</Title>
              {subtitle && <Body size={13} muted style={{ marginTop: 5, lineHeight: 1.5 }}>{subtitle}</Body>}
            </div>
            <button onClick={onClose} style={{
              border: 'none', background: 'transparent', cursor: 'pointer', padding: '2px 0',
              fontFamily: GF.sans, fontSize: 14.5, fontWeight: 700, color: GC.primary,
            }}>{closeLabel}</button>
          </div>
        )}
        <div style={{ flex: 1, overflowY: 'auto', minHeight: 0 }}>{children}</div>
        {footer && (
          <div style={{ padding: '12px 24px 30px', borderTop: `1px solid ${GC.border}`, flexShrink: 0 }}>{footer}</div>
        )}
      </div>
    </React.Fragment>
  );
}

// ── Pinned bottom action bar with live safe-area padding ──────────
function GIActionBar({ children, style = {}, platform = 'ios', translucent = true }) {
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 30,
      padding: `14px 20px ${platform === 'android' ? 22 : 34}px`,
      background: translucent
        ? 'linear-gradient(180deg, rgba(250,250,253,0) 0%, rgba(250,250,253,0.92) 36%, #FAFAFD 100%)'
        : GC.bg,
      display: 'flex', flexDirection: 'column', gap: 10, ...style,
    }}>{children}</div>
  );
}

// ── Progress ─────────────────────────────────────────────────────
// Indeterminate while the total is unknown; a real bar only once it is.
function GIProgress({ value, total, indeterminate = false, tone = GC.primary, height = 6 }) {
  const pct = indeterminate || !total ? 0 : Math.max(3, Math.round((value / total) * 100));
  return (
    <div style={{
      height, borderRadius: 999, background: GC.border, overflow: 'hidden', position: 'relative',
    }}>
      {indeterminate ? (
        <div className="gi-anim-sweep" style={{
          position: 'absolute', top: 0, bottom: 0, width: '38%', borderRadius: 999,
          background: `linear-gradient(90deg, transparent, ${tone}, transparent)`,
        }}/>
      ) : (
        <div style={{
          height: '100%', width: `${pct}%`, borderRadius: 999, background: tone,
          transition: 'width 380ms cubic-bezier(.22,.61,.36,1)',
        }}/>
      )}
    </div>
  );
}

// A quiet ledger of what has happened so far — never a percentage of a total
// Momora cannot know yet.
function GILedger({ kept = 0, aside = 0, ready = 0, processing = 0, style = {} }) {
  const item = (n, label, color) => (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 5 }}>
      <span style={{ fontFamily: GF.display, fontSize: 19, fontWeight: 500, color, lineHeight: 1 }}>{n}</span>
      <span style={{ fontFamily: GF.sans, fontSize: 12, color: GC.ink3 }}>{label}</span>
    </div>
  );
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap', ...style }}>
      {item(kept, 'kept', GC.primary)}
      <span style={{ color: GC.border }}>·</span>
      {item(aside, 'set aside', GC.ink2)}
      {processing > 0 && <React.Fragment>
        <span style={{ color: GC.border }}>·</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span className="gi-anim-breathe" style={{
            width: 7, height: 7, borderRadius: 999, background: GC.sea,
          }}/>
          <span style={{ fontFamily: GF.sans, fontSize: 12, color: GC.ink3 }}>{processing} still coming</span>
        </div>
      </React.Fragment>}
    </div>
  );
}

// ── Small parts ──────────────────────────────────────────────────
function GIPill({ children, icon, tone = 'neutral', style = {}, onClick, ariaLabel }) {
  const tones = {
    neutral: { bg: '#fff', bd: GC.border, fg: GC.ink2 },
    soft:    { bg: GC.surface, bd: GC.border, fg: GC.ink2 },
    primary: { bg: GC.primaryTint, bd: GC.primarySoft, fg: GC.primary },
    sea:     { bg: GC.seaSoft, bd: GC.seaSoft, fg: GC.seaInk },
    sun:     { bg: GC.sunSoft, bd: GC.sunSoft, fg: GC.sunInk },
    warn:    { bg: GC.warnSoft, bd: GC.warnSoft, fg: '#7a5510' },
    error:   { bg: GC.errorSoft, bd: GC.errorSoft, fg: GC.error },
  }[tone];
  const Tag = onClick ? 'button' : 'div';
  return (
    <Tag onClick={onClick} aria-label={ariaLabel} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 11px',
      background: tones.bg, border: `1px solid ${tones.bd}`, borderRadius: 999,
      fontFamily: GF.sans, fontSize: 12, fontWeight: 600, color: tones.fg,
      cursor: onClick ? 'pointer' : 'default', whiteSpace: 'nowrap', ...style,
    }}>{icon}{children}</Tag>
  );
}

// The 4-up contact sheet used on cards, rows and confirmations.
function GIThumbRow({ photos = [], size = 54, gap = 5, max = 4, more = 0, radius = 8, style = {} }) {
  const shown = photos.slice(0, max);
  return (
    <div style={{ display: 'flex', gap, ...style }}>
      {shown.map(p => (
        <GIPhoto key={p.id} scene={p.scene} seed={p.seed} radius={radius}
          style={{ width: size, height: size, flexShrink: 0 }}/>
      ))}
      {more > 0 && (
        <div style={{
          width: size, height: size, borderRadius: radius, background: GC.surface,
          border: `1px solid ${GC.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: GF.sans, fontSize: 12.5, fontWeight: 700, color: GC.ink3, flexShrink: 0,
        }}>+{more}</div>
      )}
    </div>
  );
}

// Round icon button — always ≥44px, always labelled.
function GIIconButton({ icon, label, onClick, size = 46, tone = 'neutral', style = {} }) {
  const tones = {
    neutral: { bg: '#fff', bd: GC.border, fg: GC.ink2 },
    primary: { bg: GC.primary, bd: GC.primary, fg: '#fff' },
    soft:    { bg: GC.surface, bd: GC.border, fg: GC.ink2 },
  }[tone];
  return (
    <button onClick={onClick} aria-label={label} title={label} style={{
      width: size, height: size, borderRadius: '50%', background: tones.bg,
      border: `1px solid ${tones.bd}`, color: tones.fg, cursor: 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, ...style,
    }}>{icon}</button>
  );
}

// Section label + rule, used in explainers and settings.
function GIRule({ children, style = {} }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, ...style }}>
      <Eyebrow color={GC.ink3} style={{ fontSize: 10 }}>{children}</Eyebrow>
      <div style={{ flex: 1, height: 1, background: GC.border }}/>
    </div>
  );
}

// Explainer row: icon, headline, one plain sentence.
function GIFact({ icon, title, children, tone = GC.primary, style = {} }) {
  return (
    <div style={{ display: 'flex', gap: 13, ...style }}>
      <div style={{
        width: 34, height: 34, borderRadius: 11, flexShrink: 0, background: GC.surface,
        border: `1px solid ${GC.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name={icon} size={17} color={tone} strokeWidth={1.8}/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <Body size={14.5} style={{ fontWeight: 700, lineHeight: 1.35 }}>{title}</Body>
        <Body size={13} muted style={{ marginTop: 3, lineHeight: 1.5 }}>{children}</Body>
      </div>
    </div>
  );
}

Object.assign(window, {
  GIPhoto, GITopBar, GIReassure, GISheet, GIActionBar, GIProgress, GILedger,
  GIPill, GIThumbRow, GIIconButton, GIRule, GIFact,
});
