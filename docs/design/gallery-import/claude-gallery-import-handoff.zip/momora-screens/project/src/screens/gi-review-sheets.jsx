// Gallery import — the two sheets: choose photos from the day, and the
// set-aside list. Editing a draft is the memory composer, not a sheet.
const { c: SC, f: SF } = window.MOMORA;

// ── Choose different photos from the same event ──────────────────
function GIPhotoChooser({ cand, onChange = () => {}, onClose = () => {}, max = 10 }) {
  // The full local cluster — everything Momora found that day, on this phone.
  const pool = React.useMemo(() => {
    const out = [];
    for (let n = 0; n < Math.min(cand.poolCount, 18); n++) {
      const src = cand.pool[n % cand.pool.length];
      out.push({ id: n < cand.pool.length ? src.id : `${cand.id}-x${n}`, scene: src.scene, seed: ((n * 29) % 100) / 100 });
    }
    return out;
  }, [cand.id]);
  const [sel, setSel] = React.useState(cand.selected);
  const toggle = (id) => setSel(s =>
    s.includes(id) ? (s.length === 1 ? s : s.filter(x => x !== id))
                   : (s.length >= max ? s : [...s, id]));
  const done = () => { onChange({ ...cand, selected: sel }); onClose(); };
  const atCap = sel.length >= max;

  return (
    <GISheet title="Photos from that day"
      subtitle={`${cand.poolCount} photos from ${window.giFmtDate(cand.date)}, all still on your phone.`}
      onClose={done} closeLabel="Done" maxHeight="90%"
      footer={
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <Body size={13} style={{ fontWeight: 700 }}>{sel.length} of {max} chosen</Body>
            <Body size={11.5} muted style={{ marginTop: 2 }}>
              {atCap ? 'That is the most one memory can hold.' : 'Tap a photo to add or remove it.'}
            </Body>
          </div>
          <Button onClick={done}>Use these {sel.length}</Button>
        </div>
      }>
      <div style={{ padding: '14px 24px 0' }}>
        <div style={{ background: SC.surface, borderRadius: 12, padding: 12, marginBottom: 14 }}>
          <Body size={12.5} muted style={{ lineHeight: 1.5 }}>
            Momora only looked closely at a few of these. The rest are shown from your phone —
            choosing one does not send anything new anywhere.
          </Body>
        </div>
      </div>
      <div style={{ padding: '0 24px 22px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 7 }}>
        {pool.map(p => {
          const on = sel.includes(p.id);
          const order = sel.indexOf(p.id) + 1;
          const disabled = !on && atCap;
          return (
            <button key={p.id} onClick={() => !disabled && toggle(p.id)}
              aria-pressed={on} aria-label={on ? `Photo ${order}, included` : 'Not included'}
              style={{
                position: 'relative', aspectRatio: '1', padding: 0, border: 'none', background: 'transparent',
                borderRadius: 12, overflow: 'hidden', cursor: disabled ? 'default' : 'pointer',
                opacity: disabled ? 0.45 : 1,
              }}>
              <GIPhoto scene={p.scene} seed={p.seed} radius={12} dim={!on} style={{ position: 'absolute', inset: 0 }}/>
              <div style={{
                position: 'absolute', inset: 0, borderRadius: 12,
                border: on ? `2.5px solid ${SC.primary}` : `1px solid ${SC.border}`,
              }}/>
              <div style={{
                position: 'absolute', top: 6, right: 6, minWidth: 21, height: 21, borderRadius: 999,
                background: on ? SC.primary : 'rgba(255,255,255,0.9)',
                border: on ? 'none' : `1.5px solid ${SC.borderStrong}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: SF.sans, fontSize: 11.5, fontWeight: 700, color: '#fff',
              }}>
                {on ? order : ''}
              </div>
            </button>
          );
        })}
      </div>
    </GISheet>
  );
}

// ── Set aside — recoverable, never a bin ─────────────────────────
function GISetAsideSheet({ onClose = () => {}, items = window.GI_SET_ASIDE }) {
  const [list] = React.useState(items);
  const [restored, setRestored] = React.useState([]);
  return (
    <GISheet title="Set aside" onClose={onClose} closeLabel="Done"
      subtitle={`Nothing here was deleted. Bring any of them back for the next ${window.GI_RUN.reviewDays} days.`}>
      <div style={{ padding: '14px 24px 24px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {list.map(s => {
          const back = restored.includes(s.id);
          return (
            <div key={s.id} style={{
              display: 'flex', alignItems: 'center', gap: 12, background: back ? SC.primaryTint : '#fff',
              border: `1px solid ${back ? SC.primarySoft : SC.border}`, borderRadius: 14, padding: 11,
              transition: 'background 220ms',
            }}>
              <GIPhoto scene={s.scene} seed={.45} radius={10} style={{ width: 54, height: 54, flexShrink: 0 }} dim={!back}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <Body size={13.5} style={{ lineHeight: 1.35 }}>{window.giExcerpt(s.text, 46)}</Body>
                <Body size={11.5} muted style={{ marginTop: 3 }}>
                  {window.giFmtDate(s.date)} · {back ? 'Back in the deck' : s.when}
                </Body>
              </div>
              <Button size="sm" variant={back ? 'ghost' : 'secondary'}
                onClick={() => setRestored(r => back ? r.filter(x => x !== s.id) : [...r, s.id])}>
                {back ? 'Undo' : 'Bring back'}
              </Button>
            </div>
          );
        })}
        <div style={{ background: SC.surface, borderRadius: 12, padding: 13, marginTop: 4 }}>
          <Body size={12.5} muted style={{ lineHeight: 1.55 }}>
            Setting something aside is not a judgement of the photo — it just means not this one.
            Momora will not suggest it again in a future look through your photos.
          </Body>
        </div>
      </div>
    </GISheet>
  );
}

Object.assign(window, { GIPhotoChooser, GISetAsideSheet });
