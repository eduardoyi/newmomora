// Gallery import — exceptional states. One calm pattern, never technical.
const { c: XC, f: XF } = window.MOMORA;

function GIMessage({
  eyebrow, title, body, tone = 'neutral', pill, primary, secondary, note, children,
  platform = 'ios', onPrimary = () => {}, onSecondary = () => {}, onClose = () => {},
}) {
  const toneColor = { neutral: XC.ink3, sun: XC.sunInk, error: XC.error, primary: XC.primary, sea: XC.seaInk }[tone];
  return (
    <div style={{ height: '100%', background: XC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', boxSizing: 'border-box', paddingBottom: secondary ? 170 : 140 }}>
        <GITopBar left="Close" onLeft={onClose} platform={platform} onBack={onClose}/>
        <div style={{ padding: '10px 24px 0' }}>
          {pill ? <GIPill tone={tone === 'neutral' ? 'soft' : tone}>{pill}</GIPill>
                : <Eyebrow color={toneColor}>{eyebrow}</Eyebrow>}
          <Display size={32} style={{ marginTop: 14, whiteSpace: 'pre-line' }}>{title}</Display>
          <Body size={14.5} muted style={{ marginTop: 14, lineHeight: 1.6 }}>{body}</Body>
        </div>
        {children && <div style={{ padding: '22px 20px 0' }}>{children}</div>}
        {note && <div style={{ padding: '22px 24px 0' }}><GIReassure>{note}</GIReassure></div>}
      </div>
      <GIActionBar platform={platform}>
        {primary && <Button onClick={onPrimary} style={{ width: '100%' }}>{primary}</Button>}
        {secondary && <Button variant="ghost" onClick={onSecondary} style={{ width: '100%' }}>{secondary}</Button>}
      </GIActionBar>
    </div>
  );
}

const GI_STATES = {
  wrongDevice: {
    pill: 'Started on another phone', tone: 'neutral',
    title: 'These photos live\non your other\nphone.',
    body: 'Momora only ever reads photos from the phone they are on, so the suggestions from that import can only be finished there. Nothing is lost — open Momora on that phone and pick up where you left off.',
    note: 'You can still start a fresh look through the photos on this phone.',
    primary: 'Look through this phone’s photos', secondary: 'Back to my journal',
    card: () => (
      <div style={{ background: '#fff', border: `1px solid ${XC.border}`, borderRadius: 16, padding: 15, display: 'flex', gap: 12, alignItems: 'center' }}>
        <div style={{ width: 40, height: 40, borderRadius: 12, background: XC.surface, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Icon name="clock" size={18} color={XC.ink2} strokeWidth={1.9}/>
        </div>
        <div style={{ flex: 1 }}>
          <Body size={13.5} style={{ fontWeight: 700 }}>12 suggestions waiting on “Sam’s iPhone”</Body>
          <Body size={12} muted style={{ marginTop: 3 }}>Ready for the next 26 days</Body>
        </div>
      </div>
    ),
  },
  lapsed: {
    pill: 'Momora Plus has ended', tone: 'sun',
    title: 'You can look,\nbut not add\njust yet.',
    body: 'Your journal and everything in it stays yours to read and export. Adding new memories — including these suggestions — needs an active subscription.',
    note: 'The 9 suggestions still here are safe for 26 more days.',
    primary: 'See subscription options', secondary: 'Keep looking through them',
  },
  demoted: {
    pill: 'Your role changed', tone: 'neutral',
    title: 'Only owners and\nmanagers can add\nfrom photos.',
    body: 'Your role in this family changed while this import was open, so it has stopped here. Nothing you already added has been affected.',
    note: 'The drafts and previews have been deleted. Your camera roll was never changed.',
    primary: 'Back to my journal', secondary: 'How family roles work',
  },
  removed: {
    pill: 'No longer in this family', tone: 'neutral',
    title: 'This journal is\nno longer\nshared with you.',
    body: 'You have been removed from this family, so its memories and any suggestions from your import are no longer available on this phone.',
    note: 'Momora has cleared the drafts and previews from this device.',
    primary: 'Back to my journal',
  },
  limited: {
    pill: 'Some photos', tone: 'sun',
    title: 'Working with\nthe photos\nyou chose.',
    body: 'Momora can see 14 photos, so it will suggest what it can from those. More days of photos usually turn up more events — worth choosing them before it starts looking.',
    note: 'Your camera roll is never changed, whichever you allow.',
    primary: 'Choose more photos', secondary: 'Carry on with these',
  },
  quietSkips: {
    pill: 'A few left out', tone: 'neutral',
    title: 'Some events\nwere left out.',
    body: 'Momora only suggests groups it is confident about. Screens, receipts, near-identical shots and events it could not read clearly are quietly passed over — nothing has been judged or graded.',
    note: 'Everything is still in your camera roll, exactly as it was.',
    primary: 'Review the 12 it found', secondary: 'Back to my journal',
  },
  errorRecoverable: {
    pill: 'A hiccup', tone: 'sun',
    title: 'That did not\ngo through.',
    body: 'Momora could not reach its own storage just now. Your place is saved and nothing was lost — this is worth another try in a moment.',
    note: 'Nothing was added to your journal and your camera roll is untouched.',
    primary: 'Try again', secondary: 'Not now',
  },
  errorFinal: {
    pill: 'Cannot be finished', tone: 'neutral',
    title: 'This one has to\nstart over.',
    body: 'Something went wrong that Momora cannot recover from. It has cleaned up after itself — the previews and drafts are deleted. Starting again is safe and will not re-suggest anything you set aside.',
    note: 'The 4 memories you kept are in your journal.',
    primary: 'Start again', secondary: 'Back to my journal',
  },
  capped: {
    pill: 'Enough for one go', tone: 'neutral',
    title: 'Momora stopped\nat 18 events\nthis time.',
    body: 'It went back as far as it could in one sitting and found 18 moments worth showing you. There is plenty left — you can look through more next month.',
    note: 'Nothing was missed or thrown away. Your camera roll is untouched.',
    primary: 'Review the 18 it found', secondary: 'Back to my journal',
  },
  offline: {
    pill: 'No connection', tone: 'neutral',
    title: 'Offline for\nnow.',
    body: 'You can keep reading the suggestions already on this phone. Keeping one needs a connection, because the full-size photos are uploaded then.',
    note: 'Momora will pick up on its own when you are back online.',
    primary: 'Keep reading suggestions', secondary: 'Back to my journal',
  },
};

function GIState({ kind = 'wrongDevice', platform = 'ios', ...rest }) {
  const s = GI_STATES[kind];
  return (
    <GIMessage platform={platform} {...s} {...rest}>
      {s.card ? s.card() : null}
    </GIMessage>
  );
}

// ── Inline notices — for banners inside the deck or the timeline ──
function GINotice({ tone = 'sun', icon = 'alert', title, body, action, style = {} }) {
  const t = {
    sun: { bg: XC.warnSoft, fg: '#7a5510' }, sea: { bg: XC.seaSoft, fg: XC.seaInk },
    soft: { bg: XC.surface, fg: XC.ink2 }, error: { bg: XC.errorSoft, fg: XC.error },
  }[tone];
  return (
    <div style={{ background: t.bg, borderRadius: 14, padding: '12px 13px', display: 'flex', gap: 10, ...style }}>
      <Icon name={icon} size={16} color={t.fg} strokeWidth={1.9} style={{ marginTop: 2, flexShrink: 0 }}/>
      <div style={{ flex: 1, minWidth: 0 }}>
        <Body size={13} style={{ fontWeight: 700, color: t.fg, lineHeight: 1.3 }}>{title}</Body>
        {body && <Body size={12} style={{ marginTop: 3, lineHeight: 1.45, color: t.fg, opacity: .88 }}>{body}</Body>}
        {action && (
          <button style={{
            marginTop: 8, border: 'none', background: 'transparent', padding: 0, cursor: 'pointer',
            fontFamily: XF.sans, fontSize: 12, fontWeight: 700, color: t.fg,
            textDecoration: 'underline', textUnderlineOffset: 3,
          }}>{action}</button>
        )}
      </div>
    </div>
  );
}

// A board of every notice, for review in one glance.
function GINoticeBoard() {
  return (
    <div style={{ height: '100%', boxSizing: 'border-box', background: XC.bg, overflowY: 'auto', padding: '54px 20px 30px' }}>
      <div style={{ padding: '0 4px 16px' }}>
        <Eyebrow color={XC.ink3}>In-context notices</Eyebrow>
        <Title size={22} style={{ marginTop: 8 }}>Small things, said in place</Title>
        <Body size={12.5} muted style={{ marginTop: 6, lineHeight: 1.5 }}>
          Anything that does not stop the parent stays inline instead of taking over the screen.
        </Body>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <GINotice tone="sea" icon="moon" title="Still finding more"
          body="8 more events are being written. They will appear here as they are ready."/>
        <GINotice tone="sun" icon="alert" title="Waiting for Wi-Fi"
          body="46 MB of previews to send. Momora will carry on by itself." action="Use cellular data"/>
        <GINotice tone="soft" icon="image" title="Momora can see 14 of your photos"
          body="Suggestions come only from those."/>
        <GINotice tone="sun" icon="refresh" title="One photo is downloading from iCloud"
          body="Keeping this memory will finish once it is here."/>
        <GINotice tone="soft" icon="clock" title="These clear in 4 days"
          body="Kept memories stay forever. Suggestions do not."/>
        <GINotice tone="error" icon="alert" title="Could not finish saving that one"
          body="Nothing was lost. Your place is saved." action="Try again"/>
        <GINotice tone="soft" icon="check" title="9 memories added"
          body="Your family gets one summary, not nine alerts."/>
      </div>
    </div>
  );
}

Object.assign(window, { GIState, GIMessage, GINotice, GINoticeBoard, GI_STATES });
