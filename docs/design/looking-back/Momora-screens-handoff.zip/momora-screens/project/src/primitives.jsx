// Momora primitives — Anchor Journal edition.
// Cozier, more expressive variants of the existing UI-kit primitives.
const { c: MC, f: MF, s: MS, r: MR } = window.MOMORA;

// ─────────────── Eyebrow ───────────────
function Eyebrow({ children, color = MC.primary, style = {} }) {
  return (
    <div style={{
      fontFamily: MF.sans, fontSize: 11, fontWeight: 700,
      letterSpacing: '0.14em', textTransform: 'uppercase',
      color, whiteSpace: 'nowrap', ...style,
    }}>{children}</div>
  );
}

// ─────────────── Type ───────────────
function Display({ children, size = 44, italic = false, style = {} }) {
  return <div style={{
    fontFamily: MF.display, fontWeight: 400, fontStyle: italic ? 'italic' : 'normal',
    fontSize: size, lineHeight: 0.98, letterSpacing: '-0.018em',
    color: MC.ink, fontVariationSettings: `"opsz" ${Math.min(72, size)}`,
    textWrap: 'balance', ...style,
  }}>{children}</div>;
}
function Title({ children, size = 28, style = {} }) {
  return <div style={{
    fontFamily: MF.display, fontWeight: 500, fontSize: size,
    lineHeight: 1.08, letterSpacing: '-0.012em',
    fontVariationSettings: `"opsz" ${Math.min(72, size)}`,
    color: MC.ink, ...style,
  }}>{children}</div>;
}
function Body({ children, muted = false, size = 16, style = {} }) {
  return <div style={{
    fontFamily: MF.sans, fontSize: size, lineHeight: 1.5,
    color: muted ? MC.ink2 : MC.ink, ...style,
  }}>{children}</div>;
}
function Script({ children, size = 28, color = MC.primary, style = {} }) {
  return <div style={{
    fontFamily: MF.script, fontWeight: 500, fontSize: size,
    lineHeight: 1, color, ...style,
  }}>{children}</div>;
}

// ─────────────── Buttons ───────────────
function Button({ children, onClick, variant = 'primary', size = 'lg', icon, style = {} }) {
  const [pressed, setPressed] = React.useState(false);
  const paddings = { lg: '16px 22px', md: '12px 18px', sm: '8px 14px' };
  const fs = { lg: 16, md: 15, sm: 13 };
  const base = {
    border: 'none', borderRadius: MR.pill, padding: paddings[size],
    fontFamily: MF.sans, fontWeight: 700, fontSize: fs[size], cursor: 'pointer',
    transition: 'background 140ms cubic-bezier(.22,.61,.36,1), opacity 140ms, transform 140ms',
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    boxSizing: 'border-box', whiteSpace: 'nowrap',
  };
  const variants = {
    primary: { background: pressed ? MC.primaryDark : MC.primary, color: '#fff' },
    secondary: { background: '#fff', color: MC.ink, border: `1px solid ${MC.border}` },
    ghost: { background: 'transparent', color: MC.primary, opacity: pressed ? 0.7 : 1 },
    sea: { background: pressed ? MC.seaInk : MC.sea, color: '#fff' },
    sun: { background: pressed ? MC.sunInk : MC.sun, color: MC.ink },
    ink: { background: pressed ? '#000' : MC.ink, color: '#fff' },
  };
  return (
    <button onClick={onClick}
      onPointerDown={() => setPressed(true)} onPointerUp={() => setPressed(false)}
      onPointerLeave={() => setPressed(false)}
      style={{ ...base, ...variants[variant], ...style }}>
      {icon}{children}
    </button>
  );
}

// ─────────────── Input ───────────────
function Field({ label, hint, children, error }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {label && <label style={{
        fontFamily: MF.sans, fontSize: 13, fontWeight: 600, color: MC.ink2,
        letterSpacing: '0.01em',
      }}>{label}</label>}
      {children}
      {hint && !error && <div style={{ color: MC.ink3, fontSize: 12, fontFamily: MF.sans }}>{hint}</div>}
      {error && <div style={{ color: MC.error, fontSize: 12, fontFamily: MF.sans }}>{error}</div>}
    </div>
  );
}
function Input({ value, onChange, placeholder, type = 'text', multiline, rows = 3, style = {} }) {
  const [focus, setFocus] = React.useState(false);
  const base = {
    fontFamily: MF.sans, fontSize: 16, color: MC.ink,
    background: '#fff',
    border: `1px solid ${focus ? MC.primary : MC.border}`,
    borderRadius: MR.md, padding: '13px 14px',
    outline: 'none', width: '100%', boxSizing: 'border-box',
    transition: 'border 140ms, box-shadow 140ms',
    boxShadow: focus ? `0 0 0 3px ${MC.primaryTint}` : 'none',
  };
  const Tag = multiline ? 'textarea' : 'input';
  return <Tag type={type} value={value}
    onChange={(e) => onChange && onChange(e.target.value)} placeholder={placeholder}
    onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
    rows={multiline ? rows : undefined}
    style={{ ...base, resize: multiline ? 'none' : undefined, ...style }} />;
}

// ─────────────── Emotion chip ───────────────
function EmotionChip({ emotion = 'joy', size = 'md', style = {} }) {
  const e = window.MOMORA_EMOTIONS[emotion] || window.MOMORA_EMOTIONS.joy;
  const sizes = {
    sm: { p: '2px 8px 2px 6px', fs: 10.5, dot: 5 },
    md: { p: '4px 11px 4px 9px', fs: 12, dot: 6 },
    lg: { p: '6px 14px 6px 11px', fs: 13, dot: 7 },
  }[size];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: sizes.p, borderRadius: 999, background: e.soft, color: e.ink,
      fontFamily: MF.sans, fontWeight: 600, fontSize: sizes.fs,
      letterSpacing: '0.02em', ...style,
    }}>
      <span style={{ width: sizes.dot, height: sizes.dot, borderRadius: 999, background: e.c }}/>
      {emotion}
    </span>
  );
}

// ─────────────── Avatar — with portrait-tint frame ───────────────
function Avatar({ name = '?', size = 48, tint = 'joy', src, ring = false, style = {} }) {
  const e = window.MOMORA_EMOTIONS[tint] || window.MOMORA_EMOTIONS.joy;
  const ringPad = ring ? 3 : 0;
  return (
    <div style={{
      width: size + ringPad * 2, height: size + ringPad * 2,
      borderRadius: '50%', padding: ringPad,
      background: ring ? `conic-gradient(from 220deg, ${e.c}, ${MC.primary}, ${e.c})` : 'transparent',
      flexShrink: 0, ...style,
    }}>
      <div style={{
        width: size, height: size, borderRadius: '50%',
        background: `linear-gradient(135deg, ${e.soft} 0%, ${e.c} 100%)`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: MF.display, fontWeight: 500, fontSize: Math.round(size * 0.42),
        color: '#fff', overflow: 'hidden', position: 'relative',
        boxShadow: ring ? `inset 0 0 0 2px #fff` : 'none',
      }}>
        {src ? <img src={src} style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
            : <span style={{ textShadow: '0 1px 2px rgba(0,0,0,0.12)' }}>{name.charAt(0).toUpperCase()}</span>}
      </div>
    </div>
  );
}

// ─────────────── Illustration placeholder ───────────────
// A warm watercolor wash anchored on the emotion's color family.
// Includes a soft horizon and a paper grain to feel hand-rendered.
function Illustration({ emotion = 'joy', mood, style = {}, scene = 'window', stamp }) {
  const e = window.MOMORA_EMOTIONS[emotion] || window.MOMORA_EMOTIONS.joy;
  // Each scene composes different soft shapes — not characters, but environments
  const scenes = {
    window:   { warm: '#FCE0BB', accent: '#FBD3E2', hint: e.c },
    garden:   { warm: '#E7F0CB', accent: '#FFE7B0', hint: e.c },
    bedroom:  { warm: '#F4D9E0', accent: '#E5D2F1', hint: e.c },
    kitchen:  { warm: '#FBE0B5', accent: '#F5D6CC', hint: e.c },
    park:     { warm: '#D6EDDE', accent: '#FFE7B0', hint: e.c },
    bath:     { warm: '#CFE1F4', accent: '#FBD6E1', hint: e.c },
  };
  const s = scenes[scene] || scenes.window;
  return (
    <div style={{
      borderRadius: MR.md, overflow: 'hidden', position: 'relative',
      background: `
        radial-gradient(ellipse at 70% 18%, ${e.soft} 0%, transparent 55%),
        radial-gradient(ellipse at 22% 78%, ${s.accent} 0%, transparent 50%),
        radial-gradient(ellipse at 55% 60%, ${s.hint}33 0%, transparent 45%),
        linear-gradient(160deg, ${s.warm} 0%, ${e.soft} 75%, ${s.accent} 100%)
      `,
      ...style,
    }}>
      {/* soft horizon */}
      <div style={{
        position: 'absolute', left: 0, right: 0, top: '62%', height: '38%',
        background: `linear-gradient(180deg, transparent 0%, ${s.hint}1A 100%)`,
        mixBlendMode: 'multiply',
      }}/>
      {/* paper grain */}
      <div style={{
        position: 'absolute', inset: 0,
        background: `radial-gradient(circle at 20% 20%, rgba(160,100,40,0.05) 0%, transparent 40%),
                     radial-gradient(circle at 80% 80%, rgba(160,100,40,0.07) 0%, transparent 50%)`,
        mixBlendMode: 'multiply',
      }}/>
      {/* corner stamp (e.g. "tue 14") */}
      {stamp && (
        <div style={{
          position: 'absolute', bottom: 10, right: 12,
          fontFamily: MF.script, fontWeight: 600, fontSize: 18,
          color: e.ink, opacity: 0.85, transform: 'rotate(-4deg)',
          letterSpacing: '-0.01em',
        }}>{stamp}</div>
      )}
    </div>
  );
}

// ─────────────── Surface / paper card ───────────────
function Paper({ children, tilt = 0, style = {}, onClick, pad = MS.md }) {
  return (
    <div onClick={onClick} style={{
      background: '#fff', border: `1px solid ${MC.border}`,
      borderRadius: MR.lg, padding: pad,
      transform: tilt ? `rotate(${tilt}deg)` : undefined,
      cursor: onClick ? 'pointer' : 'default',
      transition: 'transform 220ms cubic-bezier(.22,.61,.36,1)',
      ...style,
    }}>{children}</div>
  );
}

// ─────────────── Inline icon (Lucide-style hand-rolled) ───────────────
function Icon({ name, size = 20, color = 'currentColor', strokeWidth = 1.75, fill = 'none', style = {} }) {
  const paths = {
    book: 'M4 19.5A2.5 2.5 0 016.5 17H20V3H6.5A2.5 2.5 0 004 5.5v14zM4 19.5V21h14',
    calendar: 'M8 2v4M16 2v4M3 9h18M5 5h14a2 2 0 012 2v13a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2z',
    users: 'M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2M14 11a4 4 0 100-8 4 4 0 000 8zM22 21v-2a4 4 0 00-3-3.87M19 11a4 4 0 010-7.75',
    settings: 'M12 15a3 3 0 100-6 3 3 0 000 6z M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 008.91 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82A1.65 1.65 0 003.09 14H3a2 2 0 010-4h.09a1.65 1.65 0 001.51-1A1.65 1.65 0 004.27 7.18l-.06-.06a2 2 0 012.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z',
    plus: 'M12 5v14M5 12h14',
    mic: 'M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z M19 10v2a7 7 0 01-14 0v-2M12 19v4M8 23h8',
    camera: 'M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z M12 17a4 4 0 100-8 4 4 0 000 8z',
    chevronLeft: 'M15 18l-6-6 6-6',
    chevronRight: 'M9 18l6-6-6-6',
    chevronDown: 'M6 9l6 6 6-6',
    x: 'M18 6L6 18M6 6l12 12',
    check: 'M20 6L9 17l-5-5',
    heart: 'M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z',
    search: 'M11 19a8 8 0 100-16 8 8 0 000 16z M21 21l-4.35-4.35',
    sparkle: 'M12 2l1.5 5.5L19 9l-5.5 1.5L12 16l-1.5-5.5L5 9l5.5-1.5z M19 16l.75 2.75L22 19.5l-2.75.75L19 23l-.75-2.75L15.5 19.5l2.75-.75z',
    moon: 'M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z',
    sun: 'M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42 M12 17a5 5 0 100-10 5 5 0 000 10z',
    edit: 'M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7 M18.5 2.5a2.121 2.121 0 113 3L12 15l-4 1 1-4 9.5-9.5z',
    trash: 'M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6',
    arrowRight: 'M5 12h14M12 5l7 7-7 7',
    play: 'M5 3v18l16-9L5 3z',
    volume: 'M11 5L6 9H2v6h4l5 4V5z M19.07 4.93a10 10 0 0 1 0 14.14 M15.54 8.46a5 5 0 0 1 0 7.07',
    volumeOff: 'M11 5L6 9H2v6h4l5 4V5z M22 9l-6 6 M16 9l6 6',
    pause: 'M6 4h4v16H6zM14 4h4v16h-4z',
    stop: 'M5 5h14v14H5z',
    home: 'M3 12l9-9 9 9M5 10v10h14V10',
    video: 'M15 10l4.553-2.277A1 1 0 0121 8.68v6.642a1 1 0 01-1.447.894L15 14M3 8a2 2 0 012-2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z',
    type: 'M4 7V4h16v3M9 20h6M12 4v16',
    paperclip: 'M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48',
    image: 'M4 4h16a2 2 0 012 2v12a2 2 0 01-2 2H4a2 2 0 01-2-2V6a2 2 0 012-2z M8.5 11a1.5 1.5 0 100-3 1.5 1.5 0 000 3z M21 15l-5-5L5 20',
    layers: 'M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
    messageCircle: 'M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z',
    send: 'M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z',
    history: 'M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8M3 3v5h5M12 7v5l4 2',
    clock: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2',
    more: 'M5 12h.01M12 12h.01M19 12h.01',
    maximize: 'M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7',
    refresh: 'M23 4v6h-6M1 20v-6h6M20.49 9A9 9 0 0 0 5.64 5.64L1 10M3.51 15a9 9 0 0 0 14.85 3.36L23 14',
    alert: 'M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4M12 17h.01',
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill}
      stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
      style={style}>
      <path d={paths[name] || ''} />
    </svg>
  );
}

// ─────────────── Media thumbnail placeholder ───────────────
// Used for photo/video memory cards and the new-memory form preview.
function MediaThumbnail({ kind = 'photo', color = '#ddc9a8', style = {}, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: `linear-gradient(145deg, ${color}ee 0%, ${color}88 100%)`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      position: 'relative', overflow: 'hidden', ...style,
    }}>
      {/* subtle diagonal grain */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: 'repeating-linear-gradient(-45deg, transparent 0px, transparent 14px, rgba(255,255,255,0.07) 14px, rgba(255,255,255,0.07) 15px)',
        pointerEvents: 'none',
      }}/>
      {kind === 'video' ? (
        <div style={{
          position: 'relative', width: 44, height: 44, borderRadius: '50%',
          background: 'rgba(255,255,255,0.88)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 4px 16px rgba(0,0,0,0.14)',
        }}>
          <Icon name="play" size={20} color={MC.ink} strokeWidth={2}/>
        </div>
      ) : (
        <Icon name="camera" size={28} color="rgba(255,255,255,0.65)" strokeWidth={1.5}/>
      )}
    </div>
  );
}

Object.assign(window, {
  Eyebrow, Display, Title, Body, Script,
  Button, Field, Input, EmotionChip,
  Avatar, Illustration, Paper, Icon, MediaThumbnail,
});
