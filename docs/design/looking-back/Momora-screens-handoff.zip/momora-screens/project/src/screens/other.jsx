// Calendar + Family + Settings screens
const { c: CC, f: CF, s: CS, r: CR } = window.MOMORA;

// ─────────────────── CALENDAR A — Postage stamp grid ───────────────────
// Days with memories show a tiny illustration tile; today is haloed.
function CalendarA({ onOpen = () => {}, onTab = () => {} }) {
  const memories = window.MOMORA_MOCK.memories;
  // build a synthetic May 2026 grid: 31 days, starts on Fri (day-of-week 5)
  const days = Array.from({ length: 35 }, (_, i) => {
    const dayNum = i - 4; // first row offset
    if (dayNum < 1 || dayNum > 31) return null;
    const iso = `2026-05-${String(dayNum).padStart(2, '0')}`;
    const memory = memories.find(m => m.date === iso);
    return { dayNum, iso, memory, today: dayNum === 24 };
  });
  return (
    <div style={{ height: '100%', background: CC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 130 }}>
        {/* big header — month + year, with a today scrubber */}
        <div style={{ padding: '60px 24px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <Eyebrow color={CC.ink3}>2026</Eyebrow>
            <Display size={48} italic style={{ marginTop: 6 }}>May.</Display>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <button style={iconBtnC}><Icon name="chevronLeft" size={18} color={CC.ink2}/></button>
            <button style={iconBtnC}><Icon name="chevronRight" size={18} color={CC.ink2}/></button>
          </div>
        </div>

        {/* "today" hero card */}
        {(() => {
          const todayMem = memories[0];
          const isMedia = todayMem.memory_type === 'media';
          const caption = todayMem.content
            ? (todayMem.content.length > 48 ? todayMem.content.slice(0, 48) + '…' : todayMem.content)
            : (isMedia ? (todayMem.mediaKind === 'video' ? 'Video' : 'Photo') : '');
          return (
            <div style={{ padding: '20px 20px 0' }}>
              <div onClick={() => onOpen(todayMem)} style={{
                background: '#fff', border: `1px solid ${CC.border}`, borderRadius: 20,
                padding: 14, display: 'flex', gap: 14, alignItems: 'center', cursor: 'pointer',
              }}>
                <div style={{ position: 'relative', flexShrink: 0 }}>
                  {isMedia
                    ? <MediaThumbnail kind={todayMem.mediaKind} color={todayMem.mediaColor} style={{ width: 78, height: 78, borderRadius: 14 }}/>
                    : <Illustration emotion={todayMem.emotion} scene={todayMem.scene} style={{ width: 78, height: 78, borderRadius: 14 }}/>
                  }
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <Eyebrow color={CC.primary} style={{ fontSize: 10 }}>Today's memory</Eyebrow>
                  <Body size={14} style={{ marginTop: 5, lineHeight: 1.35, fontWeight: 600, color: CC.ink }}>{caption}</Body>
                  <Body muted size={12} style={{ marginTop: 3 }}>Tap to revisit</Body>
                </div>
                <Icon name="chevronRight" size={16} color={CC.ink3}/>
              </div>
            </div>
          );
        })()}

        {/* weekday header */}
        <div style={{ padding: '28px 20px 8px', display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 6 }}>
          {['S','M','T','W','T','F','S'].map((d, i) => (
            <div key={i} style={{ textAlign: 'center', fontFamily: CF.sans, fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', color: CC.ink3 }}>{d}</div>
          ))}
        </div>

        {/* day grid */}
        <div style={{ padding: '0 20px', display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 6 }}>
          {days.map((d, i) => {
            if (!d) return <div key={i}/>;
            const m = d.memory;
            return (
              <div key={i} onClick={() => m && onOpen(m)} style={{
                aspectRatio: '1', borderRadius: 12, position: 'relative',
                background: m ? 'transparent' : 'transparent',
                border: d.today ? `2px solid ${CC.primary}` : (m ? 'none' : `1px solid ${CC.border}`),
                overflow: 'hidden', cursor: m ? 'pointer' : 'default',
              }}>
                {m && <Illustration emotion={m.emotion} scene={m.scene} style={{ position: 'absolute', inset: 0, borderRadius: d.today ? 10 : 12 }}/>}
                <div style={{
                  position: 'absolute', top: 4, left: 5,
                  fontFamily: CF.sans, fontSize: 11, fontWeight: 700,
                  color: m ? (d.today ? '#fff' : '#2C2418') : (d.today ? CC.primary : CC.ink2),
                  textShadow: m ? '0 1px 2px rgba(0,0,0,0.25)' : 'none',
                }}>{d.dayNum}</div>
                {d.today && !m && (
                  <div style={{
                    position: 'absolute', bottom: 6, left: '50%', transform: 'translateX(-50%)',
                    width: 4, height: 4, borderRadius: 999, background: CC.primary,
                  }}/>
                )}
              </div>
            );
          })}
        </div>

        {/* gentle "this month" stat — not gamified, just empathy */}
        <div style={{ padding: '28px 20px 8px', display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ flex: 1, height: 1, background: CC.border }}/>
          <Body size={13} muted style={{ textAlign: 'center' }}>
            6 moments this month · 9 days kept
          </Body>
          <div style={{ flex: 1, height: 1, background: CC.border }}/>
        </div>
      </div>
      <ComposeFab/>
      <TabBar active="calendar" onTab={onTab}/>
    </div>
  );
}

// ─────────────────── CALENDAR B — Vertical ribbon of stamps ───────────────────
// Days grouped by week, scrollable, "today" as a big stamp at top.
function CalendarB({ onOpen = () => {}, onTab = () => {} }) {
  const memories = window.MOMORA_MOCK.memories;
  const weeks = [
    { label: 'this week', days: [
      { dow: 'Mon', n: 18, m: memories.find(x => x.date === '2026-05-18') },
      { dow: 'Tue', n: 19 },
      { dow: 'Wed', n: 20, m: memories.find(x => x.date === '2026-05-20') },
      { dow: 'Thu', n: 21 },
      { dow: 'Fri', n: 22, m: memories.find(x => x.date === '2026-05-22') },
      { dow: 'Sat', n: 23, m: memories.find(x => x.date === '2026-05-23') },
      { dow: 'Sun', n: 24, today: true },
    ]},
    { label: 'last week', days: [
      { dow: 'Mon', n: 11 }, { dow: 'Tue', n: 12 }, { dow: 'Wed', n: 13 },
      { dow: 'Thu', n: 14, m: memories.find(x => x.date === '2026-05-14') },
      { dow: 'Fri', n: 15 },
      { dow: 'Sat', n: 16, m: memories.find(x => x.date === '2026-05-16') },
      { dow: 'Sun', n: 17 },
    ]},
  ];
  return (
    <div style={{ height: '100%', background: CC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 130 }}>
        <div style={{ padding: '60px 24px 0' }}>
          <Eyebrow color={CC.ink3}>May 2026</Eyebrow>
          <Display size={48} italic style={{ marginTop: 6 }}>Backwards.</Display>
          <Body muted size={14} style={{ marginTop: 8 }}>
            Each stamp is a moment. Scroll to walk backwards in time.
          </Body>
        </div>

        <div style={{ padding: '24px 0 8px' }}>
          {weeks.map((w, wi) => (
            <div key={wi} style={{ marginBottom: 28 }}>
              <Eyebrow color={CC.ink3} style={{ padding: '0 24px', marginBottom: 12, fontSize: 10 }}>
                {w.label}
              </Eyebrow>
              <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                {w.days.map((d, di) => (
                  <div key={di} onClick={() => d.m && onOpen(d.m)} style={{
                    display: 'flex', alignItems: 'center', gap: 14,
                    padding: '8px 12px', borderRadius: 16,
                    background: d.today ? CC.primaryTint : 'transparent',
                    cursor: d.m ? 'pointer' : 'default',
                  }}>
                    <div style={{
                      width: 44, textAlign: 'center', fontFamily: CF.display, fontWeight: 500,
                      color: d.today ? CC.primary : CC.ink2,
                    }}>
                      <div style={{ fontSize: 11, fontFamily: CF.sans, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: d.today ? CC.primary : CC.ink3 }}>{d.dow}</div>
                      <div style={{ fontSize: 24, lineHeight: 1, marginTop: 2 }}>{d.n}</div>
                    </div>
                    {/* the stamp */}
                    {d.m ? (
                      <>
                        {/* Stamp visual — varies by memory type */}
                        {d.m.memory_type === 'media' ? (
                          <MediaThumbnail kind={d.m.mediaKind} color={d.m.mediaColor}
                            style={{ width: 56, height: 56, borderRadius: 12, flexShrink: 0 }}/>
                        ) : d.m.memory_type === 'text_only' ? (
                          <div style={{
                            width: 56, height: 56, borderRadius: 12, flexShrink: 0,
                            background: d.m.emotion ? window.MOMORA_EMOTIONS[d.m.emotion].soft : CC.surface,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                          }}>
                            <span style={{
                              fontFamily: CF.display, fontSize: 30, fontWeight: 400, lineHeight: 1,
                              color: d.m.emotion ? window.MOMORA_EMOTIONS[d.m.emotion].ink : CC.ink3,
                              opacity: 0.45, marginTop: -4,
                            }}>"</span>
                          </div>
                        ) : (
                          <Illustration emotion={d.m.emotion} scene={d.m.scene}
                            style={{ width: 56, height: 56, borderRadius: 12, flexShrink: 0 }}/>
                        )}
                        {/* Text — content snippet or media indicator */}
                        <div style={{ flex: 1, minWidth: 0 }}>
                          {d.m.content ? (
                            <Body size={14} style={{ fontWeight: 600, lineHeight: 1.3, color: CC.ink,
                              display: '-webkit-box', WebkitLineClamp: 1, WebkitBoxOrient: 'vertical', overflow: 'hidden',
                            }}>{d.m.content}</Body>
                          ) : (
                            <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                              <Icon name={d.m.mediaKind === 'video' ? 'video' : 'camera'} size={14} color={CC.ink3} strokeWidth={1.75}/>
                              <Body size={13} muted>{d.m.mediaKind === 'video' ? 'Video' : 'Photo'}</Body>
                            </div>
                          )}
                          {d.m.emotion && <div style={{ marginTop: 4 }}><EmotionChip emotion={d.m.emotion} size="sm"/></div>}
                        </div>
                      </>
                    ) : (
                      <div style={{
                        flex: 1, height: 36, borderRadius: 12,
                        background: d.today ? 'transparent' : CC.surface,
                        border: d.today ? `1.5px dashed ${CC.primary}40` : 'none',
                        display: 'flex', alignItems: 'center', paddingLeft: 14,
                      }}>
                        {d.today && <Body size={12} style={{ color: CC.primary, fontWeight: 700 }}>+ capture today</Body>}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
      <ComposeFab/>
      <TabBar active="calendar" onTab={onTab}/>
    </div>
  );
}

// ─────────────────── FAMILY A — Cast (portraits as character cards) ───────────────────
function FamilyA({ onTab = () => {}, onAdd = () => {}, onOpen = () => {} }) {
  const family = window.MOMORA_MOCK.family;
  return (
    <div style={{ height: '100%', background: CC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 130 }}>
        <div style={{ padding: '60px 24px 0' }}>
          <Eyebrow color={CC.ink3}>The cast</Eyebrow>
          <Display size={42} style={{ marginTop: 8 }}>Your<br/>people.</Display>
          <Body muted size={14} style={{ marginTop: 10 }}>
            Each one has a character portrait. Edit their photo to redraw it.
          </Body>
        </div>

        <div style={{ padding: '28px 20px 8px', display: 'flex', flexDirection: 'column', gap: 16 }}>
          {family.map(f => (
            <Paper key={f.id} pad={0} onClick={() => onOpen(f)} style={{ overflow: 'hidden', cursor: 'pointer' }}>
              <div style={{ display: 'flex', gap: 0, alignItems: 'stretch' }}>
                <div style={{
                  width: 130, flexShrink: 0,
                  background: `linear-gradient(135deg, ${window.MOMORA_EMOTIONS[f.tint].soft}, ${window.MOMORA_EMOTIONS[f.tint].c})`,
                  position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Display size={64} style={{ color: '#fff', fontStyle: 'italic', textShadow: '0 2px 12px rgba(0,0,0,0.15)' }}>
                    {f.name.charAt(0)}
                  </Display>
                </div>
                <div style={{ padding: '14px 16px', flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <Eyebrow color={CC.ink3} style={{ fontSize: 10 }}>{f.role}</Eyebrow>
                  <Title size={20} style={{ lineHeight: 1.1 }}>{f.name}</Title>
                  <Body size={13} muted>
                    {f.role === 'child' ? `${window.ageOf(f.dob)} old` : `since '88`}
                  </Body>
                  {f.nicknames.length > 0 && (
                    <Body size={12} muted style={{ fontFamily: CF.script, fontSize: 16, color: CC.ink2 }}>
                      "{f.nicknames.join(', ')}"
                    </Body>
                  )}
                </div>
              </div>
            </Paper>
          ))}

          {/* Add member tile */}
          <button onClick={onAdd} style={{
            background: 'transparent', border: `2px dashed ${CC.borderStrong}`, borderRadius: 16,
            padding: '22px 16px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 14,
          }}>
            <div style={{
              width: 56, height: 56, borderRadius: '50%', background: CC.surface,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name="plus" size={24} color={CC.primary} strokeWidth={2}/>
            </div>
            <div style={{ textAlign: 'left' }}>
              <Body size={15} style={{ fontWeight: 700, color: CC.ink }}>Add someone</Body>
              <Body size={12.5} muted>A sibling, a partner, a grandparent</Body>
            </div>
          </button>
        </div>
      </div>
      <TabBar active="family" onTab={onTab}/>
    </div>
  );
}

// ─────────────────── SETTINGS A — Loose, paper-organized ───────────────────
function SettingsA({ onTab = () => {}, onSignOut = () => {} }) {
  const [reminder, setReminder] = React.useState(true);
  const [time, setTime] = React.useState('9:00 PM');
  return (
    <div style={{ height: '100%', background: CC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 130 }}>
        <div style={{ padding: '60px 24px 0' }}>
          <Eyebrow color={CC.ink3}>Account</Eyebrow>
          <Display size={42} style={{ marginTop: 8 }}>Settings.</Display>
        </div>

        {/* identity card */}
        <div style={{ padding: '24px 20px 0' }}>
          <Paper pad={18} style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <Avatar name="Sam" size={56} tint="wonder"/>
            <div style={{ flex: 1 }}>
              <Title size={18}>Sam</Title>
              <Body size={12.5} muted style={{ fontFamily: CF.mono }}>parent@home.com</Body>
            </div>
            <button style={iconBtnC}><Icon name="edit" size={16} color={CC.ink2}/></button>
          </Paper>
        </div>

        {/* sections */}
        <div style={{ padding: '24px 20px 8px', display: 'flex', flexDirection: 'column', gap: 24 }}>
          <SettingsBlock title="Daily reminder">
            <SettingsRow
              label="Remind me to journal"
              right={<Toggle on={reminder} onClick={() => setReminder(!reminder)}/>}
            />
            {reminder && (
              <SettingsRow
                label="Around"
                value={time}
                chevron
              />
            )}
          </SettingsBlock>

          <SettingsBlock title="Privacy">
            <SettingsRow label="Private storage" caption="Your moments live in your account only." />
            <SettingsRow label="Export data" chevron />
          </SettingsBlock>

          <SettingsBlock title="Help">
            <SettingsRow label="How illustrations work" chevron />
            <SettingsRow label="Send feedback" chevron />
            <SettingsRow label="Privacy policy" chevron />
          </SettingsBlock>

          <div style={{ padding: '20px 0 0', display: 'flex', flexDirection: 'column', gap: 10 }}>
            <Button variant="secondary" onClick={onSignOut}>Sign out</Button>
            <button style={{
              background: 'transparent', border: 'none', cursor: 'pointer',
              fontFamily: CF.sans, fontSize: 13, color: CC.error, fontWeight: 600, padding: 8,
            }}>Delete account</button>
          </div>

          <Body size={11} muted style={{ textAlign: 'center', marginTop: 8, fontFamily: CF.mono }}>
            Momora v0.4.2
          </Body>
        </div>
      </div>
      <TabBar active="settings" onTab={onTab}/>
    </div>
  );
}

function SettingsBlock({ title, children }) {
  const kids = React.Children.toArray(children);
  return (
    <div>
      <Eyebrow color={CC.ink3} style={{ marginBottom: 10, fontSize: 10 }}>{title}</Eyebrow>
      <div style={{ background: '#fff', border: `1px solid ${CC.border}`, borderRadius: 16, overflow: 'hidden' }}>
        {kids.map((k, i) => React.cloneElement(k, { _first: i === 0, key: i }))}
      </div>
    </div>
  );
}
function SettingsRow({ label, value, right, chevron, caption, _first }) {
  return (
    <div style={{
      padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12,
      borderTop: _first ? 'none' : `1px solid ${CC.border}`,
    }}>
      <div style={{ flex: 1 }}>
        <Body size={14.5} style={{ fontWeight: 600 }}>{label}</Body>
        {caption && <Body size={12} muted style={{ marginTop: 3 }}>{caption}</Body>}
      </div>
      {value && <Body size={13} muted>{value}</Body>}
      {right}
      {chevron && <Icon name="chevronRight" size={16} color={CC.ink3}/>}
    </div>
  );
}
function Toggle({ on, onClick }) {
  return (
    <button onClick={onClick} style={{
      width: 44, height: 26, borderRadius: 999,
      background: on ? CC.primary : CC.border,
      border: 'none', position: 'relative', cursor: 'pointer',
      transition: 'background 220ms',
    }}>
      <div style={{
        position: 'absolute', top: 2, left: on ? 20 : 2,
        width: 22, height: 22, borderRadius: '50%', background: '#fff',
        boxShadow: '0 1px 2px rgba(0,0,0,0.18)',
        transition: 'left 220ms cubic-bezier(.22,.61,.36,1)',
      }}/>
    </button>
  );
}

const iconBtnC = {
  width: 38, height: 38, borderRadius: '50%', background: '#fff', border: `1px solid ${CC.border}`,
  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
};

// Strip the SettingsBlock CSS leak from first child border-top
Object.assign(window, { CalendarA, CalendarB, FamilyA, SettingsA });
