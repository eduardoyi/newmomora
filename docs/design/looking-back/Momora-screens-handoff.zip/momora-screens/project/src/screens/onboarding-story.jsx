// Onboarding — owner path, story arc S0–S8.
const { c: OC, f: OF, s: OS, r: OR } = window.MOMORA;
const ONB = { name: 'Lila', family: "Lila's Family" };

// Shared shell: optional slot art on top, text block, pinned CTA stack.
function OnbShell({ children, footer, style = {} }) {
  return (
    <div style={{ height: '100%', background: OC.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden', ...style }}>
      {children}
      {footer && <div style={{ padding: '0 24px 40px', display: 'flex', flexDirection: 'column', gap: 10 }}>{footer}</div>}
    </div>
  );
}

// Subtle progress dots (story beats only).
function OnbDots({ n = 3, at = 0 }) {
  return (
    <div style={{ display: 'flex', gap: 6, justifyContent: 'center', padding: '14px 0 0' }}>
      {Array.from({ length: n }).map((_, i) => (
        <div key={i} style={{ width: i === at ? 16 : 5, height: 5, borderRadius: 999, background: i === at ? OC.primary : OC.border, transition: 'all 220ms' }}/>
      ))}
    </div>
  );
}

// ─── S0 · Welcome / fork ───
function OnbWelcome() {
  return (
    <OnbShell footer={
      <>
        <Button style={{ width: '100%' }}>Start your family's journal</Button>
        <Button variant="secondary" style={{ width: '100%' }}>I have an invite</Button>
        <div style={{ textAlign: 'center', paddingTop: 6, fontFamily: OF.sans, fontSize: 13.5, color: OC.ink2 }}>
          I already have an account · <span style={{ color: OC.primary, fontWeight: 700 }}>Log in</span>
        </div>
      </>
    }>
      <div style={{ position: 'relative', flex: '0 0 46%' }}>
        <image-slot id="onb-welcome" shape="rect" placeholder="Warm illustration: parent + child reading in lamplight" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}></image-slot>
        <div style={{ position: 'absolute', top: 58, left: 24, pointerEvents: 'none', fontFamily: OF.display, fontWeight: 500, fontSize: 24, letterSpacing: '-0.01em', color: '#fff', textShadow: '0 1px 10px rgba(0,0,0,0.35)' }}>
          Momora<span style={{ color: OC.primarySoft }}>.</span>
        </div>
      </div>
      <div style={{ flex: 1, padding: '26px 24px 0' }}>
        <Display size={33}>Save the funny little things, before your brain deletes them.</Display>
        <Body muted size={15.5} style={{ marginTop: 14 }}>A journal made by tired parents, for tired parents. No blank pages, no homework.</Body>
      </div>
    </OnbShell>
  );
}

// ─── S1–S3 · Story beats ───
function OnbStoryBeat({ slotId, placeholder, dot, headline, body, cta, dark = false }) {
  return (
    <OnbShell footer={<Button style={{ width: '100%' }}>{cta}</Button>}>
      <div style={{ position: 'relative', flex: '0 0 44%', margin: '0 0 0 0' }}>
        <image-slot id={slotId} shape="rect" placeholder={placeholder} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}></image-slot>
      </div>
      <OnbDots n={3} at={dot}/>
      <div style={{ flex: 1, padding: '20px 26px 0' }}>
        <Display size={31}>{headline}</Display>
        <Body muted size={15.5} style={{ marginTop: 14 }}>{body}</Body>
      </div>
    </OnbShell>
  );
}
const OnbStory1 = () => <OnbStoryBeat slotId="onb-s1-night" dot={0}
  placeholder="Dark illustration: phone glow on a parent's face at 2 a.m."
  headline="You know the 2 a.m. scroll."
  body={<>"Just checking the monitor," you say, forty minutes deep into photos from March. It's fine. No judgment. We do it too.</>}
  cta="That's me"/>;
const OnbStory2 = () => <OnbStoryBeat slotId="onb-s2-book" dot={1}
  placeholder="Soft illustration: baby book shut on a closet shelf, sock on top"
  headline="The baby book stops at month six."
  body={<>Ours stopped at four. Turns out "fill this out nightly" was a big ask during the no-sleep years.</>}
  cta="Who approved that homework"/>;
const OnbStory3 = () => <OnbStoryBeat slotId="onb-s3-babble" dot={2}
  placeholder="Bright illustration: toddler mid-babble, invented words floating"
  headline="The camera caught the first steps."
  body="Nobody caught the word she invented for helicopter. That's the stuff that goes, and 20,000 photos won't bring it back."
  cta="That's the stuff I want to keep"/>;

// ─── S4 · Founder intro A ───
function OnbFounderA() {
  return (
    <OnbShell footer={<Button style={{ width: '100%' }}>Sounds familiar</Button>}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '60px 26px 0' }}>
        <div style={{ width: 210, height: 210, transform: 'rotate(-2deg)' }}>
          <image-slot id="onb-founders" shape="rounded" radius="18" placeholder="Illustrated portrait: Eduardo & Adriana, Momora style" style={{ width: '100%', height: '100%' }}></image-slot>
        </div>
        <Script size={24} color={OC.ink2} style={{ marginTop: 14, transform: 'rotate(-2deg)' }}>made by tired parents, for tired parents</Script>
        <Display size={31} style={{ marginTop: 26, textAlign: 'center' }}>We're Eduardo &amp; Adriana.</Display>
        <Body muted size={15.5} style={{ marginTop: 12, textAlign: 'center' }}>Two kids. Thousands of photos. A baby book that stops at month four (see above).</Body>
      </div>
    </OnbShell>
  );
}

// Compact footer used by the S5 sample cards. Scaled down to match the small card.
function MiniFooter({ day, tint }) {
  return (
    <div style={{ padding: '7px 10px 8px', display: 'flex', alignItems: 'center', gap: 6 }}>
      <span style={{ fontFamily: OF.sans, fontSize: 8, fontWeight: 800, letterSpacing: '0.06em', textTransform: 'uppercase', color: OC.ink3 }}>{day}</span>
      <div style={{ flex: 1 }}/>
      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, background: window.MOMORA_EMOTIONS[tint].soft, borderRadius: 999, padding: '2px 7px' }}>
        <div style={{ width: 4.5, height: 4.5, borderRadius: '50%', background: window.MOMORA_EMOTIONS[tint].c }}/>
        <span style={{ fontFamily: OF.sans, fontSize: 8.5, fontWeight: 700, letterSpacing: '0.03em', color: window.MOMORA_EMOTIONS[tint].ink }}>{window.MOMORA_EMOTIONS[tint].label}</span>
      </div>
    </div>
  );
}

// ─── S5 · Founder intro B — the artifact demo ───
// Three illustrated memory cards, scattered top-left → middle-right → bottom-left.
function OnbFounderB() {
  const cards = [
    { k: 'a', emotion: 'mischief', scene: 'garden', rot: -8, left: 0, top: 0, z: 3, day: 'Sat, Aug 9',
      caption: 'Declared the hose "broken" right after soaking the dog.' },
    { k: 'b', emotion: 'wonder', scene: 'window', rot: 9, left: 106, top: 150, z: 2, day: 'Sun, Oct 12',
      caption: 'Two hours at the zoo. Favourite animal: a pigeon.' },
    { k: 'c', emotion: 'tender', scene: 'bedroom', rot: -5, left: 4, top: 306, z: 1, day: 'Tue, Mar 3',
      caption: 'Fell asleep mid-sentence about dinosaurs.' },
  ];
  return (
    <OnbShell footer={<Button style={{ width: '100%' }}>Show me how it works</Button>}>
      <div style={{ padding: '58px 26px 0' }}>
        <Display size={29}>So we built this for our own kids.</Display>
        <Body muted size={14.5} style={{ marginTop: 9 }}>Things we mumbled into our phones at 9 p.m., turned into hundreds of memories like these.</Body>
      </div>
      <div style={{ flex: 1, position: 'relative', marginTop: 34 }}>
        <div style={{ position: 'relative', width: 318, margin: '0 auto', height: '100%' }}>
        {cards.map(c => (
          <div key={c.k} style={{ position: 'absolute', left: c.left, top: c.top, width: 212, transform: `rotate(${c.rot}deg)`, zIndex: c.z }}>
            <Paper pad={0} style={{ overflow: 'hidden', boxShadow: '0 14px 32px rgba(44,36,24,0.16)' }}>
              <Illustration emotion={c.emotion} scene={c.scene} style={{ width: '100%', aspectRatio: '4/3' }}/>
              <div style={{ padding: '9px 10px 0' }}>
                <Body size={12} style={{ lineHeight: 1.34 }}>{c.caption}</Body>
              </div>
              <MiniFooter day={c.day} tint={c.emotion}/>
            </Paper>
          </div>
        ))}
        </div>
      </div>
    </OnbShell>
  );
}

// Kid tints cycle in entry order.
const KID_TINTS = ['tender', 'wonder', 'joy', 'calm', 'mischief'];
const kidTint = i => KID_TINTS[i % KID_TINTS.length];

// Deletable name chip used on S6.
function KidChip({ name, index = 0, onRemove }) {
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: '#fff', border: `1px solid ${OC.border}`, borderRadius: 999, padding: '5px 9px 5px 5px' }}>
      <Avatar name={name} size={24} tint={kidTint(index)}/>
      <span style={{ fontFamily: OF.sans, fontSize: 14, fontWeight: 700, color: OC.ink }}>{name}</span>
      <div onClick={onRemove} style={{ width: 17, height: 17, borderRadius: '50%', background: OC.surface, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
        <Icon name="x" size={10} color={OC.ink3} strokeWidth={2.5}/>
      </div>
    </div>
  );
}

// ─── S6 · Child's name — multi-kid capable, single-kid default ───
function OnbChildName({ value = '', kids = [] }) {
  const [name, setName] = React.useState(value);
  const [list, setList] = React.useState(kids);
  const add = () => { if (name.trim()) { setList([...list, name.trim()]); setName(''); } };
  return (
    <OnbShell footer={<Button style={{ width: '100%' }}>Continue</Button>}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 26px', position: 'relative' }}>
        <div style={{ position: 'absolute', top: 70, right: 20, width: 96, height: 96, opacity: 0.85, transform: 'rotate(3deg)' }}>
          <image-slot id="onb-s6-doodle" shape="rounded" radius="14" placeholder="Small warm doodle" style={{ width: '100%', height: '100%' }}></image-slot>
        </div>
        <Display size={34}>Who's this journal for?</Display>
        {list.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 22 }}>
            {list.map((k, i) => <KidChip key={k + i} name={k} index={i} onRemove={() => setList(list.filter((_, j) => j !== i))}/>)}
          </div>
        )}
        <input value={name} onChange={e => setName(e.target.value)} placeholder={list.length ? 'And their name' : 'Their first name'} autoFocus style={{
          marginTop: list.length ? 18 : 26, width: '100%', boxSizing: 'border-box', border: 'none', borderBottom: `2px solid ${name ? OC.primary : OC.borderStrong}`, outline: 'none', background: 'transparent',
          fontFamily: OF.display, fontWeight: 500, fontSize: list.length ? 30 : 38, letterSpacing: '-0.015em', color: OC.ink, padding: '4px 0 10px', caretColor: OC.primary,
        }}/>
        <div onClick={add} style={{ marginTop: 14, alignSelf: 'flex-start', fontFamily: OF.sans, fontSize: 14, fontWeight: 700, color: OC.primary, cursor: 'pointer' }}>+ Add another kiddo</div>
        <Body muted size={13.5} style={{ marginTop: 12 }}>Nicknames welcome. No favorites here, add them all.</Body>
      </div>
      {/* keyboard */}
      <OnbKeyboard/>
    </OnbShell>
  );
}

// Static iOS-style keyboard for input screens.
function OnbKeyboard() {
  const rows = ['QWERTYUIOP', 'ASDFGHJKL', 'ZXCVBNM'];
  return (
    <div style={{ background: '#E3E1EC', padding: '8px 4px 4px', flexShrink: 0 }}>
      {rows.map((r, ri) => (
        <div key={ri} style={{ display: 'flex', gap: 5, justifyContent: 'center', marginBottom: 7, padding: ri === 1 ? '0 18px' : 0 }}>
          {ri === 2 && <div style={{ width: 42, borderRadius: 6, background: '#C9C7D4', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13 }}>⇧</div>}
          {r.split('').map(k => (
            <div key={k} style={{ flex: 1, maxWidth: 33, height: 40, background: '#fff', borderRadius: 6, boxShadow: '0 1px 0 rgba(0,0,0,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: OF.sans, fontSize: 17, color: OC.ink }}>{k}</div>
          ))}
          {ri === 2 && <div style={{ width: 42, borderRadius: 6, background: '#C9C7D4', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13 }}>⌫</div>}
        </div>
      ))}
      <div style={{ display: 'flex', gap: 5, padding: '0 2px 6px' }}>
        <div style={{ width: 88, height: 40, background: '#C9C7D4', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: OF.sans, fontSize: 14 }}>123</div>
        <div style={{ flex: 1, height: 40, background: '#fff', borderRadius: 6, boxShadow: '0 1px 0 rgba(0,0,0,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: OF.sans, fontSize: 14, color: OC.ink3 }}>space</div>
        <div style={{ width: 88, height: 40, background: OC.primary, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: OF.sans, fontSize: 14, fontWeight: 600, color: '#fff' }}>done</div>
      </div>
    </div>
  );
}

// "Lila" · "Lila & Miguel" · "Lila, Miguel & Teo"
function kidsPhrase(kids) {
  if (kids.length <= 1) return kids[0] || '';
  return kids.slice(0, -1).join(', ') + ' & ' + kids[kids.length - 1];
}

// ─── S7 · Family name — prefill derives from every kid ───
function OnbFamilyName({ kids = [ONB.name] }) {
  const [val, setVal] = React.useState(`${kidsPhrase(kids)}'s Family`);
  const multi = kids.length > 1;
  return (
    <OnbShell footer={<Button style={{ width: '100%' }}>That's us</Button>}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 26px' }}>
        <div style={{ width: 92, height: 92, marginBottom: 24, transform: 'rotate(-3deg)' }}>
          <image-slot id="onb-s7-nest" shape="rounded" radius="14" placeholder="Nest / house motif" style={{ width: '100%', height: '100%' }}></image-slot>
        </div>
        <Display size={33}>{multi ? 'Their' : `${kids[0]}'s`} stories need a home.</Display>
        <div style={{ marginTop: 26, display: 'flex', alignItems: 'center', gap: 10, background: '#fff', border: `1px solid ${OC.border}`, borderRadius: OR.md, padding: '14px 16px' }}>
          <input value={val} onChange={e => setVal(e.target.value)} style={{ flex: 1, border: 'none', outline: 'none', background: 'transparent', fontFamily: OF.display, fontWeight: 500, fontSize: 22, color: OC.ink }}/>
          <Icon name="edit" size={17} color={OC.ink3}/>
        </div>
        <Body muted size={13.5} style={{ marginTop: 12 }}>You can change this any time, e.g. to "The Rivera Family".</Body>
      </div>
    </OnbShell>
  );
}

// ─── S8 · Bridge to action ───
function OnbBridge() {
  return (
    <OnbShell footer={<Button style={{ width: '100%' }}>Start with tonight</Button>}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 30px' }}>
        <Script size={27} color={OC.primary} style={{ transform: 'rotate(-2deg)', marginBottom: 22 }}>no blank pages here</Script>
        <Display size={36}>You're not behind. There is no behind.</Display>
        <Body muted size={16} style={{ marginTop: 18 }}>{ONB.name}'s journal starts with one little thing from this week. Silly counts. Boring counts double.</Body>
      </div>
    </OnbShell>
  );
}

Object.assign(window, { OnbShell, OnbDots, OnbKeyboard, KidChip, MiniFooter, kidTint, kidsPhrase, OnbWelcome, OnbStory1, OnbStory2, OnbStory3, OnbFounderA, OnbFounderB, OnbChildName, OnbFamilyName, OnbBridge, ONB });
