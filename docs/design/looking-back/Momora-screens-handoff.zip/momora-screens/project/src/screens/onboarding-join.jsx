// Onboarding — join path J1–J5. Zero selling, warm and fast.
const { c: JC, f: JF } = window.MOMORA;

// ─── J1 · Invite code entry ───
function JoinCode() {
  const [val, setVal] = React.useState('sunny-otter-');
  return (
    <div style={{ height: '100%', background: JC.bg, display: 'flex', flexDirection: 'column' }}>
      <div style={{ flex: 1, padding: '92px 26px 0' }}>
        <Display size={33}>Someone saved you a seat.</Display>
        <Body muted size={15} style={{ marginTop: 12 }}>Type your invite code. It's a few words, like <span style={{ fontFamily: JF.mono, fontSize: 13.5, background: JC.surface, padding: '2px 6px', borderRadius: 6 }}>sunny-otter-lake</span>. Whoever invited you has it.</Body>
        <input value={val} onChange={e => setVal(e.target.value)} placeholder="your-invite-code" style={{
          marginTop: 26, width: '100%', boxSizing: 'border-box', background: '#fff', border: `1.5px solid ${JC.primary}`,
          boxShadow: `0 0 0 3px ${JC.primaryTint}`, borderRadius: 14, padding: '16px 16px', outline: 'none',
          fontFamily: JF.mono, fontSize: 18, letterSpacing: '0.02em', color: JC.ink, caretColor: JC.primary,
        }}/>
        <Button style={{ width: '100%', marginTop: 16 }}>Find my family</Button>
      </div>
      <OnbKeyboard/>
    </div>
  );
}

// ─── J2 · Family found ───
function JoinFound() {
  const members = [
    { name: 'Sam', tint: 'wonder' }, { name: 'Lila', tint: 'tender' }, { name: 'Noor', tint: 'joy' }, { name: 'Mateo', tint: 'calm' },
  ];
  return (
    <div style={{ height: '100%', background: JC.bg, display: 'flex', flexDirection: 'column', padding: '0 26px' }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
        <div style={{ display: 'flex', marginBottom: 22 }}>
          {members.map((m, i) => (
            <div key={m.name} style={{ marginLeft: i ? -14 : 0, zIndex: 4 - i }}>
              <Avatar name={m.name} size={58} tint={m.tint} ring/>
            </div>
          ))}
        </div>
        <Display size={34}>Join the Rivera Family?</Display>
        <Body muted size={15} style={{ marginTop: 12, maxWidth: 300 }}>Sam invited you to see and share the family's memories.</Body>
      </div>
      <div style={{ paddingBottom: 40, display: 'flex', flexDirection: 'column', gap: 12 }}>
        <Button style={{ width: '100%' }}>Yes, that's my family</Button>
        <div style={{ textAlign: 'center', fontFamily: JF.sans, fontSize: 13.5, fontWeight: 600, color: JC.ink3 }}>Wrong family? <span style={{ color: JC.primary, fontWeight: 700 }}>Re-enter code</span></div>
      </div>
    </div>
  );
}

// ─── J3 · Display name ───
function JoinName() {
  const [val, setVal] = React.useState('Grandma Rosa');
  return (
    <div style={{ height: '100%', background: JC.bg, display: 'flex', flexDirection: 'column' }}>
      <div style={{ flex: 1, padding: '96px 26px 0' }}>
        <Display size={34}>What should the family call you?</Display>
        <input value={val} onChange={e => setVal(e.target.value)} placeholder="Grandma Ana, Uncle Rob, Dad…" style={{
          marginTop: 26, width: '100%', boxSizing: 'border-box', border: 'none', borderBottom: `2px solid ${JC.primary}`, outline: 'none', background: 'transparent',
          fontFamily: JF.display, fontWeight: 500, fontSize: 32, letterSpacing: '-0.012em', color: JC.ink, padding: '4px 0 10px', caretColor: JC.primary,
        }}/>
        <Body muted size={13.5} style={{ marginTop: 12 }}>This shows up next to your comments and memories.</Body>
        <Button style={{ width: '100%', marginTop: 26 }}>That's me</Button>
      </div>
      <OnbKeyboard/>
    </div>
  );
}

// ─── J4 · Account (email OTP, joiner framing) ───
function JoinAuth() {
  return (
    <div style={{ height: '100%', background: JC.bg, display: 'flex', flexDirection: 'column' }}>
      <div style={{ flex: 1, padding: '96px 26px 0' }}>
        <Display size={33}>Last step, promise.</Display>
        <Body muted size={15} style={{ marginTop: 12 }}>Email in, code back. No passwords, ever.</Body>
        <div style={{ marginTop: 24 }}>
          <Input placeholder="you@email.com" type="email"/>
        </div>
        <Button style={{ width: '100%', marginTop: 14 }}>Send my code</Button>
      </div>
      <OnbKeyboard/>
    </div>
  );
}

// ─── J5 · Approval wait state ───
function JoinWait() {
  return (
    <div style={{ height: '100%', background: JC.bg, display: 'flex', flexDirection: 'column', padding: '0 28px' }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
        <div style={{ width: 170, height: 190, marginBottom: 26 }}>
          <image-slot id="j5-door" shape="rounded" radius="16" placeholder="Illustration: a door with warm light under it" style={{ width: '100%', height: '100%' }}></image-slot>
        </div>
        <Display size={30}>One sec. Sam just needs to wave you in.</Display>
        <Body muted size={15} style={{ marginTop: 14, maxWidth: 300 }}>We told them you're here. You'll get a ping the moment you're in.</Body>
      </div>
      <div style={{ paddingBottom: 44, textAlign: 'center', fontFamily: JF.sans, fontSize: 13.5, fontWeight: 700, color: JC.primary }}>Give them a nudge</div>
    </div>
  );
}

Object.assign(window, { JoinCode, JoinFound, JoinName, JoinAuth, JoinWait });
