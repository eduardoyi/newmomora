// "Who's in it" tag control — shared by New memory + Edit memory.
//
// Problem: a family can have more people than fit in one row of chips.
// Solution: inline, surface the 3 most-tagged members as quick-tap chips plus a
// "More" pill. The pill opens a bottom sheet with the full roster — grouped,
// searchable, multi-select, capped at `max`. Anyone tagged from the sheet who
// isn't in the top 3 also appears inline, so you always see who's in.

const { c: WC, f: WF, r: WR } = window.MOMORA;

// one-time keyframes for the sheet + scrim
if (!document.getElementById('wii-anim')) {
  const st = document.createElement('style');
  st.id = 'wii-anim';
  st.textContent =
    '@keyframes wiiFade{from{opacity:0}to{opacity:1}}' +
    '@keyframes wiiSlide{from{transform:translateY(102%)}to{transform:translateY(0)}}';
  document.head.appendChild(st);
}

const VISIBLE = 3; // most-tagged members shown inline before the "More" pill

function WhosInIt({ tagged = [], setTagged = () => {}, max = 4, defaultOpen = false }) {
  const family = window.MOMORA_MOCK.family;
  const [open, setOpen]   = React.useState(defaultOpen);
  const [query, setQuery] = React.useState('');

  const toggle = (id) => setTagged(t =>
    t.includes(id) ? t.filter(x => x !== id) : (t.length >= max ? t : [...t, id])
  );

  // ranked by how often each person is tagged
  const ranked = React.useMemo(
    () => [...family].sort((a, b) => (b.tagCount || 0) - (a.tagCount || 0)),
    [family]
  );

  // inline = top VISIBLE + anyone currently tagged (stable ranked order)
  const topIds   = new Set(ranked.slice(0, VISIBLE).map(f => f.id));
  const mustShow = new Set([...topIds, ...tagged]);
  const inline   = ranked.filter(f => mustShow.has(f.id));
  const moreCount = family.length - inline.length;

  const atCap = tagged.length >= max;

  const subFor = (f) =>
    f.role === 'child' ? `${f.relation} · ${window.ageOf(f.dob)}` : f.relation;

  // ── roster row (used inside the sheet) ──
  const Row = (f) => {
    const on = tagged.includes(f.id);
    const disabled = !on && atCap;
    return (
      <button key={f.id} onClick={() => !disabled && toggle(f.id)} style={{
        width: '100%', display: 'flex', alignItems: 'center', gap: 14, textAlign: 'left',
        padding: '11px 24px', border: 'none',
        background: on ? WC.primaryTint : 'transparent',
        cursor: disabled ? 'default' : 'pointer', opacity: disabled ? 0.4 : 1,
        transition: 'background 140ms', WebkitTapHighlightColor: 'transparent',
      }}>
        <Avatar name={f.name} size={42} tint={f.tint} ring={on}/>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: WF.sans, fontSize: 15, fontWeight: 700, color: WC.ink }}>{f.name}</div>
          <div style={{ fontFamily: WF.sans, fontSize: 12.5, color: WC.ink3, marginTop: 1 }}>{subFor(f)}</div>
        </div>
        <div style={{
          width: 24, height: 24, borderRadius: '50%', flexShrink: 0,
          background: on ? WC.primary : 'transparent',
          border: on ? 'none' : `1.5px solid ${WC.borderStrong}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'all 140ms',
        }}>
          {on && <Icon name="check" size={13} color="#fff" strokeWidth={3}/>}
        </div>
      </button>
    );
  };

  // filtered roster for the sheet
  const q = query.trim().toLowerCase();
  const matches = (f) =>
    !q || f.name.toLowerCase().includes(q) ||
    f.relation.toLowerCase().includes(q) ||
    (f.nicknames || []).some(n => n.toLowerCase().includes(q));

  const oftenTagged = ranked.slice(0, VISIBLE).filter(matches);
  const everyone    = ranked.slice(VISIBLE).filter(matches);

  const groupHead = (label) => (
    <div style={{
      fontFamily: WF.sans, fontSize: 11, fontWeight: 700,
      letterSpacing: '0.12em', textTransform: 'uppercase', color: WC.ink3,
      padding: '16px 24px 6px',
    }}>{label}</div>
  );

  return (
    <React.Fragment>
      {/* ── Inline strip ── */}
      <div style={{ padding: '12px 20px 0' }}>
        <div style={{
          fontFamily: WF.sans, fontSize: 10, fontWeight: 700,
          letterSpacing: '0.14em', textTransform: 'uppercase', color: WC.ink3, marginBottom: 8,
        }}>
          Who's in it · {tagged.length}/{max}
        </div>
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 2 }}>
          {inline.map(f => {
            const on = tagged.includes(f.id);
            return (
              <button key={f.id} onClick={() => toggle(f.id)} style={{
                display: 'flex', alignItems: 'center', gap: 7,
                padding: '4px 11px 4px 4px',
                background: on ? WC.primaryTint : '#fff',
                border: `1px solid ${on ? WC.primary : WC.border}`,
                borderRadius: 999, cursor: 'pointer', flexShrink: 0,
                transition: 'all 140ms',
              }}>
                <Avatar name={f.name} size={26} tint={f.tint}/>
                <span style={{ fontFamily: WF.sans, fontSize: 13, fontWeight: 700, color: on ? WC.primary : WC.ink }}>
                  {f.name}
                </span>
              </button>
            );
          })}

          {moreCount > 0 && (
            <button onClick={() => { setQuery(''); setOpen(true); }} style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '4px 13px 4px 4px',
              background: '#fff', border: `1px solid ${WC.border}`,
              borderRadius: 999, cursor: 'pointer', flexShrink: 0,
            }}>
              <div style={{
                width: 26, height: 26, borderRadius: '50%', background: WC.surface,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Icon name="plus" size={15} color={WC.ink2} strokeWidth={2.25}/>
              </div>
              <span style={{ fontFamily: WF.sans, fontSize: 13, fontWeight: 700, color: WC.ink2 }}>More</span>
            </button>
          )}
        </div>
      </div>

      {/* ── Roster sheet ── */}
      {open && (
        <React.Fragment>
          {/* scrim */}
          <div onClick={() => setOpen(false)} style={{
            position: 'absolute', inset: 0, zIndex: 40,
            background: 'rgba(36,28,18,0.34)',
            animation: 'wiiFade 200ms ease-out both',
          }}/>
          {/* sheet */}
          <div style={{
            position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 41,
            display: 'flex', flexDirection: 'column', maxHeight: '84%',
            background: '#fff',
            borderTopLeftRadius: 24, borderTopRightRadius: 24,
            boxShadow: '0 -14px 44px rgba(40,30,20,0.22)',
            animation: 'wiiSlide 320ms cubic-bezier(.22,.61,.36,1) both',
          }}>
            {/* grabber */}
            <div style={{ display: 'flex', justifyContent: 'center', padding: '10px 0 4px' }}>
              <div style={{ width: 38, height: 5, borderRadius: 999, background: WC.border }}/>
            </div>

            {/* header */}
            <div style={{
              display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between',
              padding: '8px 24px 0',
            }}>
              <div style={{ fontFamily: WF.display, fontWeight: 500, fontSize: 23, letterSpacing: '-0.012em', color: WC.ink }}>
                Who's in it
              </div>
              <div style={{
                fontFamily: WF.sans, fontSize: 13, fontWeight: 700,
                color: tagged.length ? WC.primary : WC.ink3,
              }}>
                {tagged.length} of {max}
              </div>
            </div>
            <div style={{ fontFamily: WF.sans, fontSize: 13, color: WC.ink3, padding: '4px 24px 0', lineHeight: 1.45 }}>
              {atCap
                ? 'That is the most you can tag — remove someone to swap them out.'
                : 'Tag everyone who shared this moment.'}
            </div>

            {/* search */}
            <div style={{
              display: 'flex', alignItems: 'center', gap: 10, margin: '14px 24px 0',
              background: WC.surface, border: `1px solid ${WC.border}`,
              borderRadius: 12, padding: '10px 12px',
            }}>
              <Icon name="search" size={16} color={WC.ink3} strokeWidth={2}/>
              <input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search family"
                style={{
                  flex: 1, border: 'none', outline: 'none', background: 'transparent',
                  fontFamily: WF.sans, fontSize: 15, color: WC.ink, minWidth: 0,
                }}
              />
              {query && (
                <button onClick={() => setQuery('')} style={{
                  border: 'none', background: 'none', cursor: 'pointer', padding: 0,
                  display: 'flex', alignItems: 'center',
                }}>
                  <Icon name="x" size={15} color={WC.ink3} strokeWidth={2.25}/>
                </button>
              )}
            </div>

            {/* roster */}
            <div style={{ flex: 1, overflowY: 'auto', marginTop: 4 }}>
              {oftenTagged.length === 0 && everyone.length === 0 ? (
                <div style={{ padding: '32px 24px', textAlign: 'center', fontFamily: WF.sans, fontSize: 14, color: WC.ink3 }}>
                  No one by that name.
                </div>
              ) : q ? (
                [...oftenTagged, ...everyone].map(Row)
              ) : (
                <React.Fragment>
                  {oftenTagged.length > 0 && groupHead('Often tagged')}
                  {oftenTagged.map(Row)}
                  {everyone.length > 0 && groupHead('Everyone')}
                  {everyone.map(Row)}
                </React.Fragment>
              )}
            </div>

            {/* done */}
            <div style={{ padding: '12px 24px 26px', borderTop: `1px solid ${WC.border}`, flexShrink: 0 }}>
              <Button onClick={() => setOpen(false)} style={{ width: '100%' }}>
                {tagged.length ? `Done · ${tagged.length} tagged` : 'Done'}
              </Button>
            </div>
          </div>
        </React.Fragment>
      )}
    </React.Fragment>
  );
}

Object.assign(window, { WhosInIt });
