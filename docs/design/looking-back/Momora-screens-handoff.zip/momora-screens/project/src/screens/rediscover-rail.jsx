// Rediscovery rail — "Looking back" packages at the top of the Timeline.
// Three cover directions (stack / contact sheet / plate) + the resolved one.
const { c: RC, f: RF } = window.MOMORA;

// ── Cover art ────────────────────────────────────────────────────────────────
function PkgCoverArt({ pkg, radius = 11, style = {} }) {
  const cv = pkg.cover;
  if (cv.type === 'text') {
    const e = window.MOMORA_EMOTIONS[cv.emotion || pkg.tint];
    return (
      <div style={{
        borderRadius: radius, overflow: 'hidden', position: 'relative',
        background: `linear-gradient(160deg, ${e.soft} 0%, #FBF8F2 58%, ${e.soft} 100%)`,
        containerType: 'inline-size', ...style,
      }}>
        <div style={{
          position: 'absolute', left: '11%', top: '4%', fontFamily: RF.display, fontWeight: 400,
          fontSize: '52cqw', lineHeight: 1, color: e.ink, opacity: 0.17, userSelect: 'none',
        }}>”</div>
      </div>
    );
  }
  if (cv.type === 'photo') {
    return (
      <div style={{
        borderRadius: radius, overflow: 'hidden', position: 'relative',
        background: `linear-gradient(150deg, ${cv.color}f2 0%, ${cv.color}9c 100%)`, ...style,
      }}>
        <div style={{
          position: 'absolute', inset: 0, mixBlendMode: 'multiply',
          background: `radial-gradient(ellipse at 70% 22%, rgba(255,255,255,.5) 0%, transparent 55%),
                       radial-gradient(ellipse at 25% 85%, rgba(120,80,40,.16) 0%, transparent 60%)`,
        }}/>
      </div>
    );
  }
  return (
    <div style={{ borderRadius: radius, overflow: 'hidden', position: 'relative', ...style }}>
      <Illustration emotion={cv.emotion} scene={cv.scene} style={{ width: '100%', height: '100%', borderRadius: 0, filter: 'saturate(1.16) contrast(1.03)' }}/>
      <div style={{
        position: 'absolute', inset: 0, mixBlendMode: 'multiply',
        background: `radial-gradient(120% 80% at 50% -10%, rgba(255,255,255,.28) 0%, transparent 60%),
                     radial-gradient(110% 70% at 50% 112%, rgba(120,70,30,.22) 0%, transparent 62%)`,
      }}/>
    </div>
  );
}

// Count line — plain, factual, never a badge
function PkgMeta({ pkg }) {
  return (
    <div style={{ fontFamily: RF.sans, fontSize: 10.5, fontWeight: 600, color: RC.ink3, letterSpacing: '0.01em' }}>
      {pkg.viewed ? pkg.seenLabel : `${pkg.chapters.length} memories · ${pkg.era}`}
    </div>
  );
}

// ── A · Stack of prints (RESOLVED) ───────────────────────────────────────────
// Layered paper prints read instantly as "several memories, kept together" and
// separate the package from a single Timeline card without any ring or badge.
function PkgCardStack({ pkg, w = 178, onClick = () => {} }) {
  const [press, setPress] = React.useState(false);
  const viewed = pkg.viewed;
  return (
    <div style={{ padding: '9px 12px 16px', scrollSnapAlign: 'start', flexShrink: 0 }}>
      <div
        onClick={() => onClick(pkg)}
        onPointerDown={() => setPress(true)} onPointerUp={() => setPress(false)} onPointerLeave={() => setPress(false)}
        style={{
          position: 'relative', width: w, cursor: 'pointer',
          opacity: press ? 0.9 : 1, transition: 'opacity 140ms cubic-bezier(.22,.61,.36,1)',
        }}>
        {/* prints beneath */}
        <div style={{
          position: 'absolute', left: 11, right: -9, top: 13, bottom: -1, borderRadius: 16,
          background: pkg.layers[1], border: `1px solid ${RC.border}`,
          transform: `rotate(${viewed ? 1.6 : 3.2}deg)`, opacity: viewed ? 0.45 : 1,
        }}/>
        <div style={{
          position: 'absolute', left: -7, right: 9, top: 7, bottom: 4, borderRadius: 16,
          background: pkg.layers[0], border: `1px solid ${RC.border}`,
          transform: `rotate(${viewed ? -1 : -2.2}deg)`, opacity: viewed ? 0.5 : 1,
        }}/>
        {/* front print */}
        <div style={{
          position: 'relative', background: '#fff', border: `1px solid ${RC.border}`,
          borderRadius: 16, padding: 7,
          boxShadow: viewed ? 'none' : '0 10px 26px rgba(40,30,20,0.11)',
        }}>
          <div style={{ position: 'relative' }}>
            <PkgCoverArt pkg={pkg} style={{ width: '100%', aspectRatio: '1/1', filter: viewed ? 'saturate(.82)' : 'none' }}/>
            {viewed && (
              <div style={{ position: 'absolute', inset: 0, borderRadius: 11, background: 'rgba(250,250,253,0.3)' }}/>
            )}
          </div>
          <div style={{ padding: '11px 5px 4px', display: 'flex', flexDirection: 'column', gap: 5 }}>
            <Eyebrow style={{ fontSize: 9.5, letterSpacing: '0.15em', color: viewed ? RC.ink3 : RC.primary }}>{pkg.kind}</Eyebrow>
            <div style={{
              fontFamily: RF.display, fontWeight: 500, fontSize: 16.5, lineHeight: 1.16,
              letterSpacing: '-0.012em', color: RC.ink, textWrap: 'pretty',
              display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
            }}>{pkg.title}</div>
            <PkgMeta pkg={pkg}/>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── B · Contact sheet ────────────────────────────────────────────────────────
function PkgCardSheet({ pkg, w = 212, onClick = () => {} }) {
  const tiles = pkg.layers;
  return (
    <div style={{ padding: '7px 0 12px', scrollSnapAlign: 'start', flexShrink: 0 }}>
      <div onClick={() => onClick(pkg)} style={{
        width: w, cursor: 'pointer', background: '#fff', border: `1px solid ${RC.border}`,
        borderRadius: 16, padding: 8, boxShadow: '0 6px 18px rgba(40,30,20,0.07)',
      }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
          <PkgCoverArt pkg={pkg} radius={9} style={{ gridColumn: 'span 2', width: '100%', aspectRatio: '16/10' }}/>
          {tiles.map((t, i) => (
            <div key={i} style={{
              width: '100%', aspectRatio: '1/1', borderRadius: 9,
              background: `linear-gradient(145deg, ${t} 0%, ${t}88 100%)`,
            }}/>
          ))}
        </div>
        <div style={{ padding: '11px 4px 3px', display: 'flex', flexDirection: 'column', gap: 5 }}>
          <Eyebrow style={{ fontSize: 9.5, letterSpacing: '0.15em' }}>{pkg.kind}</Eyebrow>
          <div style={{ fontFamily: RF.display, fontWeight: 500, fontSize: 17, lineHeight: 1.14, letterSpacing: '-0.012em', color: RC.ink }}>{pkg.title}</div>
          <PkgMeta pkg={pkg}/>
        </div>
      </div>
    </div>
  );
}

// ── C · Warm plate (RESOLVED) ────────────────────────────────────────────────
// Full-bleed cover under a warm scrim, cream type over it. Text-only packages
// get a light quote plate instead of art, with ink type — same composition.
function PkgCardPlate({ pkg, w = 168, onClick = () => {} }) {
  const [press, setPress] = React.useState(false);
  const viewed = pkg.viewed;
  const isText = pkg.cover.type === 'text';
  const e = window.MOMORA_EMOTIONS[pkg.cover.emotion || pkg.tint];
  const eyebrowColor = isText ? e.ink : (viewed ? 'rgba(251,246,238,0.66)' : '#F6E9D8');
  const titleColor = isText ? RC.ink : '#FBF6EE';
  const metaColor = isText ? RC.ink3 : 'rgba(251,246,238,0.72)';
  return (
    <div style={{ padding: '7px 0 14px', scrollSnapAlign: 'start', flexShrink: 0 }}>
      <div
        onClick={() => onClick(pkg)}
        onPointerDown={() => setPress(true)} onPointerUp={() => setPress(false)} onPointerLeave={() => setPress(false)}
        style={{
          width: w, height: 244, cursor: 'pointer', position: 'relative',
          borderRadius: 20, overflow: 'hidden',
          border: `1px solid ${isText ? e.soft : RC.border}`,
          boxShadow: viewed ? '0 1px 2px rgba(40,30,20,0.05)' : '0 12px 28px rgba(40,30,20,0.13)',
          opacity: press ? 0.9 : 1, transition: 'opacity 140ms cubic-bezier(.22,.61,.36,1)',
        }}>
        <PkgCoverArt pkg={pkg} radius={0}
          style={{ position: 'absolute', inset: 0, filter: viewed ? 'saturate(.78)' : 'none' }}/>

        {/* viewed: a quiet lavender veil instead of any badge */}
        {viewed && <div style={{ position: 'absolute', inset: 0, background: isText ? 'rgba(250,250,253,0.5)' : 'rgba(250,250,253,0.2)' }}/>}

        {/* text-only packages carry a single quotation mark — no excerpt */}

        {!isText && (
          <div style={{
            position: 'absolute', left: 0, right: 0, bottom: 0, height: '64%',
            background: viewed
              ? 'linear-gradient(180deg, rgba(38,28,20,0) 0%, rgba(38,28,20,0.5) 56%, rgba(38,28,20,0.74) 100%)'
              : 'linear-gradient(180deg, rgba(38,28,20,0) 0%, rgba(38,28,20,0.62) 58%, rgba(38,28,20,0.86) 100%)',
          }}/>
        )}

        <div style={{ position: 'absolute', left: 14, right: 14, bottom: 14, display: 'flex', flexDirection: 'column', gap: 6 }}>
          <Eyebrow style={{ fontSize: 9.5, letterSpacing: '0.15em', color: eyebrowColor }}>{pkg.kind}</Eyebrow>
          <div style={{
            fontFamily: RF.display, fontWeight: 500, fontSize: isText ? 16.5 : 18, lineHeight: 1.14,
            letterSpacing: '-0.014em', color: titleColor,
            display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
          }}>{pkg.title}</div>
          <div style={{ fontFamily: RF.sans, fontSize: 10.5, fontWeight: 600, color: metaColor }}>
            {viewed ? pkg.seenLabel : `${pkg.chapters.length} memories · ${pkg.era}`}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── The rail ─────────────────────────────────────────────────────────────────
// Absent entirely when the archive has nothing worth collecting today.
function PackageRail({
  packages = window.MOMORA_ARCHIVE.packages,
  variant = 'plate',
  onOpen = () => {},
  label = 'Looking back',
  style = {},
}) {
  if (!packages || packages.length === 0) return null;
  const Card = variant === 'sheet' ? PkgCardSheet : variant === 'stack' ? PkgCardStack : PkgCardPlate;
  const edge = variant === 'stack' ? 12 : 24;
  return (
    <div style={{ ...style }}>
      <div style={{ padding: '0 24px', display: 'flex', alignItems: 'baseline', gap: 9 }}>
        <Eyebrow color={RC.ink3} style={{ fontSize: 10.5 }}>{label}</Eyebrow>
        <div style={{ flex: 1, height: 1, background: RC.border }}/>
      </div>
      <div className="mo-hs" style={{
        marginTop: 8, display: 'flex', overflowX: 'auto', scrollSnapType: 'x mandatory',
        scrollPaddingLeft: edge, gap: variant === 'stack' ? 0 : 12,
      }}>
        {/* explicit edge spacers — survive scroll-snap, unlike container padding */}
        <div style={{ width: edge, flexShrink: 0 }}/>
        {packages.map(p => <Card key={p.id} pkg={p} onClick={onOpen}/>)}
        <div style={{ width: edge, flexShrink: 0 }}/>
      </div>
    </div>
  );
}

// ── Timeline with the rail integrated ────────────────────────────────────────
function TimelineRediscover({
  packages = window.MOMORA_ARCHIVE.packages,
  variant = 'plate',
  onOpenPackage = () => {},
  onOpen = () => {}, onCompose = () => {}, onTab = () => {}, onComment = () => {},
}) {
  const mem = window.MOMORA_MOCK.memories;
  const hasRail = packages && packages.length > 0;
  return (
    <div style={{ height: '100%', background: RC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 130 }}>
        <TimelineHeader/>
        {hasRail && <PackageRail packages={packages} variant={variant} onOpen={onOpenPackage} style={{ marginTop: 24 }}/>}
        <div style={{ padding: hasRail ? '14px 24px 0' : '26px 24px 0' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 9 }}>
            <Eyebrow color={RC.ink3} style={{ fontSize: 10.5 }}>Recently</Eyebrow>
            <div style={{ flex: 1, height: 1, background: RC.border }}/>
          </div>
        </div>
        <div style={{ padding: '14px 20px 8px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {mem.map(mm =>
            mm.memory_type === 'text_only'
              ? <MemoryCardQuote key={mm.id} m={mm} onClick={() => onOpen(mm)} onComment={() => onComment(mm)}/>
              : <MemoryCardSpread key={mm.id} m={mm} onClick={() => onOpen(mm)} onComment={() => onComment(mm)}/>
          )}
        </div>
      </div>
      <ComposeFab onClick={onCompose}/>
      <TabBar active="timeline" onTab={onTab}/>
    </div>
  );
}

Object.assign(window, {
  PkgCoverArt, PkgCardStack, PkgCardSheet, PkgCardPlate, PackageRail, TimelineRediscover,
});
