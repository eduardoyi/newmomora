// Portrait timeline — /family/[id]/portraits
// A newest-first record of every dated source photo + its generated portrait,
// so a child's illustrated character ages alongside them.
const { c: PT, f: PTF, s: PTS, r: PTR } = window.MOMORA;

const ptIconBtn = {
  width: 38, height: 38, borderRadius: '50%', background: '#fff',
  border: `1px solid ${PT.border}`,
  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
};

// ── Source chip — how a version's date was set ───────────────────────────────
function SourceChip({ source }) {
  const map = {
    exif:          { icon: 'camera', label: 'From photo' },
    manual:        { icon: 'edit',   label: 'Set manually' },
    default_today: { icon: 'clock',  label: 'Added today' },
    legacy_unknown:{ icon: 'clock',  label: 'Date unknown' },
  };
  const s = map[source] || map.manual;
  const legacy = source === 'legacy_unknown';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding: '3px 9px 3px 7px', borderRadius: PTR.pill,
      background: legacy ? PT.surface : PT.surface,
      border: `1px solid ${PT.border}`,
      fontFamily: PTF.sans, fontSize: 11.5, fontWeight: 600,
      color: PT.ink2, letterSpacing: '0.01em',
    }}>
      <Icon name={s.icon} size={12} color={PT.ink3} strokeWidth={2}/>
      {s.label}
    </span>
  );
}

// Small corner label on each half of the pair
function PairTag({ children, style }) {
  return (
    <span style={{
      position: 'absolute',
      padding: '2px 7px', borderRadius: PTR.pill,
      background: 'rgba(28,20,10,0.5)', color: '#fff',
      fontFamily: PTF.sans, fontSize: 9, fontWeight: 700,
      letterSpacing: '0.1em', textTransform: 'uppercase',
      ...style,
    }}>{children}</span>
  );
}

// ── One version = source photo + portrait, paired ───────────────────────────
function VersionCard({ v, member, isCurrent, onActions, onOpen, onRetry }) {
  const generating = v.status === 'generating';
  const failed = v.status === 'failed';
  const dead = generating; // actions locked while generating

  return (
    <Paper pad={0} style={{ overflow: 'hidden' }}>
      {/* ── The pair — 50/50, each 1:1 ── */}
      <div style={{ display: 'flex', gap: 2, background: PT.border }}>
        {/* source photo */}
        <div
          onClick={v.status === 'ready' ? onOpen : undefined}
          style={{ flex: 1, minWidth: 0, aspectRatio: '1 / 1', position: 'relative',
            cursor: v.status === 'ready' ? 'pointer' : 'default' }}>
          <MediaThumbnail kind="photo" color={v.photo} style={{ width: '100%', height: '100%' }}/>
        </div>
        {/* generated portrait */}
        <div
          onClick={v.status === 'ready' ? onOpen : undefined}
          style={{
            flex: 1, minWidth: 0, aspectRatio: '1 / 1', position: 'relative',
            cursor: v.status === 'ready' ? 'pointer' : 'default',
          }}>
          {v.status === 'ready' && (
            <>
              <Illustration emotion={v.emotion} scene={v.scene}
                style={{ width: '100%', height: '100%', borderRadius: 0 }}/>
              {isCurrent && (
                <span style={{
                  position: 'absolute', top: 8, right: 8,
                  display: 'inline-flex', alignItems: 'center', gap: 5,
                  padding: '3px 9px 3px 8px', borderRadius: PTR.pill,
                  background: PT.primary, color: '#fff',
                  fontFamily: PTF.sans, fontSize: 10.5, fontWeight: 700,
                  boxShadow: '0 2px 8px rgba(214,62,120,0.35)',
                }}>
                  <span style={{ width: 5, height: 5, borderRadius: 999, background: '#fff' }}/>
                  Current
                </span>
              )}
            </>
          )}
          {generating && (
            <div style={{
              width: '100%', height: '100%',
              background: `linear-gradient(160deg, ${window.MOMORA_EMOTIONS[v.emotion].soft}, ${PT.surface})`,
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10,
              animation: 'ptpulse 1.6s ease-in-out infinite',
            }}>
              <div style={{
                width: 30, height: 30, borderRadius: '50%',
                border: `2.5px solid ${PT.primary}33`, borderTopColor: PT.primary,
                animation: 'ptspin 0.9s linear infinite',
              }}/>
              <span style={{ fontFamily: PTF.sans, fontSize: 12, fontWeight: 600, color: PT.ink2 }}>
                Generating…
              </span>
            </div>
          )}
          {failed && (
            <div style={{
              width: '100%', height: '100%', background: PT.surface,
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8,
            }}>
              <Icon name="alert" size={26} color={PT.error} strokeWidth={1.75}/>
              <span style={{ fontFamily: PTF.sans, fontSize: 12, fontWeight: 600, color: PT.ink2 }}>
                Couldn't generate
              </span>
            </div>
          )}
        </div>
      </div>

      {/* ── Info row ── */}
      <div style={{ padding: '13px 14px 14px', display: 'flex', alignItems: 'flex-start', gap: 10 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <Title size={17} style={{ lineHeight: 1.15 }}>
            {v.refDate ? window.fmtDateLong(v.refDate) : 'Date unknown'}
          </Title>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 7, flexWrap: 'wrap' }}>
            {v.refDate && (
              <Body size={13} muted>{window.ageAt(member.dob, v.refDate)} old</Body>
            )}
            <SourceChip source={v.dateSource}/>
          </div>
        </div>
        {generating ? (
          <span style={{
            fontFamily: PTF.sans, fontSize: 11.5, fontWeight: 700, color: PT.ink3,
            display: 'inline-flex', alignItems: 'center', gap: 6, padding: '9px 4px 0 0',
          }}>
            <span style={{ width: 6, height: 6, borderRadius: 999, background: PT.sun,
              animation: 'ptpulse 1.4s ease-in-out infinite' }}/>
            Working
          </span>
        ) : (
          <button onClick={onActions} aria-label="Portrait options" style={{ ...ptIconBtn, width: 34, height: 34 }}>
            <Icon name="more" size={18} color={PT.ink2} strokeWidth={2.5}/>
          </button>
        )}
      </div>

      {/* ── Failed retry row ── */}
      {failed && (
        <div style={{ padding: '0 14px 14px' }}>
          <button onClick={onRetry} style={{
            width: '100%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            padding: '11px 0', borderRadius: PTR.md, cursor: 'pointer',
            background: PT.primaryTint, border: `1px solid ${PT.primary}44`,
            fontFamily: PTF.sans, fontSize: 14, fontWeight: 700, color: PT.primary,
          }}>
            <Icon name="refresh" size={15} color={PT.primary} strokeWidth={2}/>
            Try again
          </button>
        </div>
      )}
    </Paper>
  );
}

// ── Bottom sheet shell ───────────────────────────────────────────────────────
function Sheet({ children, onClose }) {
  return (
    <>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, zIndex: 40,
        background: 'rgba(28,20,10,0.34)',
      }}/>
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 50,
        background: '#fff', borderRadius: '24px 24px 0 0',
        boxShadow: '0 -12px 40px rgba(28,20,10,0.22)',
        padding: '10px 20px 34px',
      }}>
        <div style={{ width: 38, height: 4, borderRadius: 999, background: PT.border, margin: '0 auto 16px' }}/>
        {children}
      </div>
    </>
  );
}

// Row used in the add + actions sheets
function SheetRow({ icon, iconColor, title, sub, onClick, danger, disabled }) {
  return (
    <button onClick={disabled ? undefined : onClick} style={{
      width: '100%', display: 'flex', alignItems: 'center', gap: 14,
      padding: '13px 6px', background: 'none', border: 'none',
      cursor: disabled ? 'default' : 'pointer', textAlign: 'left',
      opacity: disabled ? 0.4 : 1,
    }}>
      <div style={{
        width: 42, height: 42, borderRadius: 12, flexShrink: 0,
        background: danger ? PT.errorSoft : PT.surface,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name={icon} size={20} color={iconColor || (danger ? PT.error : PT.ink)} strokeWidth={1.9}/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: PTF.sans, fontSize: 15.5, fontWeight: 700, color: danger ? PT.error : PT.ink }}>{title}</div>
        {sub && <div style={{ fontFamily: PTF.sans, fontSize: 12.5, color: PT.ink3, marginTop: 1 }}>{sub}</div>}
      </div>
    </button>
  );
}

// ── The screen ───────────────────────────────────────────────────────────────
function PortraitTimeline({
  member = window.MOMORA_MOCK.family[0],
  onBack = () => {},
  topStatus,          // force newest card into 'generating' | 'failed' (for canvas)
  sheet: initialSheet,// force a sheet open: 'add' | 'actions' | 'date' | 'fullscreen'
}) {
  // Working copy of this member's versions (newest-first).
  const versions = React.useMemo(() => {
    const list = window.portraitsFor(member.id).map(v => ({ ...v }));
    if (topStatus && list[0]) list[0].status = topStatus;
    return list;
  }, [member.id, topStatus]);

  const readyCount = versions.filter(v => v.status === 'ready').length;
  const currentId = versions.find(v => v.status === 'ready')?.id;

  const [sheet, setSheet] = React.useState(initialSheet || null);
  const [focusV, setFocusV] = React.useState(
    versions.find(v => v.status === 'ready') || versions[0]
  );
  const emo = window.MOMORA_EMOTIONS[member.tint] || window.MOMORA_EMOTIONS.joy;

  const openActions = (v) => { setFocusV(v); setSheet('actions'); };

  return (
    <div style={{ height: '100%', background: PT.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative' }}>

      {/* ── Header ── */}
      <div style={{ padding: '60px 20px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <button onClick={onBack} style={ptIconBtn}><Icon name="chevronLeft" size={18} color={PT.ink2}/></button>
        <span style={{ fontFamily: PTF.sans, fontSize: 15, fontWeight: 700, color: PT.ink }}>Then &amp; now</span>
        <button onClick={() => setSheet('add')} aria-label="Add a portrait" style={ptIconBtn}>
          <Icon name="plus" size={19} color={PT.primary} strokeWidth={2.25}/>
        </button>
      </div>

      {/* ── Scroll body ── */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: '18px 24px 8px' }}>
          <Eyebrow>Through the years</Eyebrow>
          <Title size={27} style={{ marginTop: 7 }}>{member.name}</Title>
          <Body size={13} muted style={{ marginTop: 5 }}>
            {readyCount} {readyCount === 1 ? 'portrait' : 'portraits'} · how {member.name} has looked over time
          </Body>
        </div>

        <div style={{ padding: '10px 24px 44px', display: 'flex', flexDirection: 'column', gap: 16 }}>
          {versions.map(v => (
            <VersionCard
              key={v.id} v={v} member={member}
              isCurrent={v.id === currentId}
              onActions={() => openActions(v)}
              onOpen={() => { setFocusV(v); setSheet('fullscreen'); }}
              onRetry={() => {}}
            />
          ))}

          {readyCount <= 1 && (
            <div style={{
              marginTop: 4, padding: '20px 18px', borderRadius: PTR.lg,
              background: PT.surface, border: `1px solid ${PT.border}`,
              display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: 8,
            }}>
              <div style={{
                width: 40, height: 40, borderRadius: '50%', background: PT.primaryTint,
                display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 2,
              }}>
                <Icon name="history" size={19} color={PT.primary} strokeWidth={2}/>
              </div>
              <Title size={17}>One portrait so far</Title>
              <Body size={13.5} muted style={{ lineHeight: 1.5, maxWidth: 250 }}>
                The first of many. Add a new photo whenever {member.name} changes, and watch the years gather here.
              </Body>
            </div>
          )}
        </div>
      </div>

      {/* ── Add sheet ── */}
      {sheet === 'add' && (
        <Sheet onClose={() => setSheet(null)}>
          <Title size={22} style={{ marginBottom: 4 }}>Add a portrait</Title>
          <Body size={14} muted style={{ marginBottom: 12 }}>
            Add a new photo to capture how {member.name} looks now.
          </Body>
          <SheetRow icon="camera" iconColor={PT.sea}
            title="Take photo"
            sub={`Dated today, ${window.fmtDateLong('2026-05-25')}`}
            onClick={() => setSheet(null)}/>
          <div style={{ height: 1, background: PT.border, margin: '2px 0' }}/>
          <SheetRow icon="image" iconColor={PT.primary}
            title="Choose from library"
            sub="Uses the photo's own date when available"
            onClick={() => setSheet('date')}/>
          <div style={{
            marginTop: 12, padding: '10px 12px', borderRadius: PTR.md,
            background: PT.surface, border: `1px solid ${PT.border}`,
            display: 'flex', gap: 9, alignItems: 'flex-start',
          }}>
            <Icon name="sparkle" size={15} color={PT.primary} strokeWidth={1.9} style={{ marginTop: 1, flexShrink: 0 }}/>
            <Body size={12.5} muted style={{ lineHeight: 1.45 }}>
              The portrait generates after the photo is saved. The current one stays until the new one is ready.
            </Body>
          </div>
        </Sheet>
      )}

      {/* ── Date / source sheet (library import) ── */}
      {sheet === 'date' && (
        <Sheet onClose={() => setSheet(null)}>
          <Title size={22} style={{ marginBottom: 4 }}>Portrait date</Title>
          <Body size={14} muted style={{ marginBottom: 16 }}>
            This sets {member.name}'s age in the illustration.
          </Body>
          <div style={{
            padding: '16px 16px', borderRadius: PTR.lg,
            background: PT.surface, border: `1px solid ${PT.border}`,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <div>
              <Title size={20}>November 8, 2025</Title>
              <Body size={12.5} muted style={{ marginTop: 4 }}>{window.ageAt(member.dob, '2025-11-08')} old</Body>
            </div>
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '5px 11px 5px 9px', borderRadius: PTR.pill,
              background: PT.seaSoft, color: PT.seaInk,
              fontFamily: PTF.sans, fontSize: 12, fontWeight: 700,
            }}>
              <Icon name="camera" size={13} color={PT.seaInk} strokeWidth={2}/>
              From photo
            </span>
          </div>
          <button style={{
            width: '100%', marginTop: 12, padding: '13px 0', borderRadius: PTR.md,
            background: '#fff', border: `1px solid ${PT.border}`, cursor: 'pointer',
            fontFamily: PTF.sans, fontSize: 14, fontWeight: 600, color: PT.ink2,
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}>
            <Icon name="calendar" size={15} color={PT.ink2}/>
            Set the date manually
          </button>
          <Body size={12} muted style={{ marginTop: 10, textAlign: 'center' }}>
            Can't be after today or before {member.name}'s birthday.
          </Body>
          <div style={{ marginTop: 16 }}>
            <Button variant="primary" style={{ width: '100%' }} onClick={() => setSheet(null)}>Save portrait</Button>
          </div>
        </Sheet>
      )}

      {/* ── Version actions sheet ── */}
      {sheet === 'actions' && focusV && (
        <Sheet onClose={() => setSheet(null)}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 2px 12px' }}>
            <Illustration emotion={focusV.emotion} scene={focusV.scene}
              style={{ width: 46, height: 46, borderRadius: 12, flexShrink: 0 }}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <Title size={16}>{focusV.refDate ? window.fmtDateLong(focusV.refDate) : 'Date unknown'}</Title>
              <Body size={12.5} muted>
                {focusV.refDate ? `${window.ageAt(member.dob, focusV.refDate)} old` : 'Legacy portrait'}
              </Body>
            </div>
            {focusV.id === currentId && (
              <span style={{
                padding: '3px 9px', borderRadius: PTR.pill, background: PT.primaryTint,
                fontFamily: PTF.sans, fontSize: 10.5, fontWeight: 700, color: PT.primary,
              }}>Current</span>
            )}
          </div>
          <div style={{ height: 1, background: PT.border, marginBottom: 4 }}/>
          <SheetRow icon="calendar" title="Edit date"
            sub={focusV.dateSource === 'legacy_unknown' ? 'Add a date to place this portrait' : null}
            onClick={() => setSheet('date')}/>
          <SheetRow icon="refresh" title="Regenerate portrait"
            sub="Make a new illustration from the same photo"
            onClick={() => setSheet(null)}/>
          <div style={{ height: 1, background: PT.border, margin: '4px 0' }}/>
          {focusV.id === currentId && readyCount === 1 ? (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 14, padding: '13px 6px', opacity: 0.55,
            }}>
              <div style={{ width: 42, height: 42, borderRadius: 12, background: PT.surface,
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Icon name="trash" size={19} color={PT.ink3} strokeWidth={1.9}/>
              </div>
              <div>
                <div style={{ fontFamily: PTF.sans, fontSize: 15.5, fontWeight: 700, color: PT.ink3 }}>Delete</div>
                <div style={{ fontFamily: PTF.sans, fontSize: 12.5, color: PT.ink3, marginTop: 1 }}>
                  {member.name}'s only ready portrait — can't be removed
                </div>
              </div>
            </div>
          ) : (
            <SheetRow icon="trash" danger title="Delete portrait"
              onClick={() => setSheet(null)}/>
          )}
        </Sheet>
      )}

      {/* ── Full-screen viewer ── */}
      {sheet === 'fullscreen' && focusV && (
        <div style={{
          position: 'absolute', inset: 0, zIndex: 60, background: '#1b140c',
          display: 'flex', flexDirection: 'column',
        }}>
          <div style={{ padding: '58px 20px 0', display: 'flex', justifyContent: 'flex-end' }}>
            <button onClick={() => setSheet(null)} aria-label="Close" style={{
              width: 40, height: 40, borderRadius: '50%', cursor: 'pointer',
              background: 'rgba(255,255,255,0.14)', border: 'none',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name="x" size={20} color="#fff" strokeWidth={2.25}/>
            </button>
          </div>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 20px' }}>
            <Illustration emotion={focusV.emotion} scene={focusV.scene}
              style={{ width: '100%', aspectRatio: '1/1', borderRadius: PTR.xl,
                boxShadow: '0 24px 60px rgba(0,0,0,0.5)' }}/>
          </div>
          <div style={{ padding: '20px 24px 40px', textAlign: 'center' }}>
            <Title size={20} style={{ color: '#fff' }}>
              {focusV.refDate ? window.fmtDateLong(focusV.refDate) : 'Date unknown'}
            </Title>
            {focusV.refDate && (
              <Body size={13} style={{ color: 'rgba(255,255,255,0.6)', marginTop: 4 }}>
                {member.name} · {window.ageAt(member.dob, focusV.refDate)} old
              </Body>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

window.PortraitTimeline = PortraitTimeline;
window.PT_SourceChip = SourceChip;
