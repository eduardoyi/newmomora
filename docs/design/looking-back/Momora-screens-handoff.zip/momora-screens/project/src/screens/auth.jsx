// Auth + onboarding screens
const { c: AC, f: AF, s: AS, r: AR } = window.MOMORA;

// ─────────────────── Wordmark (interim typographic mark) ───────────────────
function Wordmark({ size = 28, color = AC.ink }) {
  return (
    <div style={{
      fontFamily: AF.display, fontWeight: 500, fontSize: size,
      letterSpacing: '-0.025em', color, lineHeight: 1, display: 'inline-flex', alignItems: 'baseline',
    }}>
      Momora
      <span style={{ color: AC.primary, marginLeft: '0.05em' }}>.</span>
    </div>
  );
}

// ─────────────────── LOGIN A — soft editorial ───────────────────
function LoginA({ onSubmit = () => {} }) {
  const [email, setEmail] = React.useState('');
  const [pwd, setPwd] = React.useState('');
  return (
    <div style={{ height: '100%', background: AC.bg, padding: '88px 28px 32px', display: 'flex', flexDirection: 'column', boxSizing: 'border-box' }}>
      <Wordmark size={26} />
      <div style={{ marginTop: 48, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <Display size={44}>Welcome<br/>back.</Display>
        <Body muted size={15} style={{ marginTop: 8 }}>
          Pick up where you left off — your moments are waiting.
        </Body>
      </div>
      <div style={{ marginTop: 36, display: 'flex', flexDirection: 'column', gap: 16 }}>
        <Field label="Email"><Input value={email} onChange={setEmail} placeholder="parent@home.com"/></Field>
        <Field label="Password" hint="At least 8 characters."><Input type="password" value={pwd} onChange={setPwd} placeholder="••••••••"/></Field>
        <div style={{ alignSelf: 'flex-end' }}>
          <Body size={13}><a style={{ color: AC.primary, textDecoration: 'none', fontWeight: 600 }}>Forgot password?</a></Body>
        </div>
      </div>
      <div style={{ flex: 1 }}/>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, paddingBottom: 8 }}>
        <Button onClick={onSubmit} style={{ width: '100%' }}>Sign in</Button>
        <Body muted size={14} style={{ textAlign: 'center' }}>
          New here? <a onClick={() => onSubmit('signup')} style={{ color: AC.primary, fontWeight: 700, cursor: 'pointer' }}>Create an account</a>
        </Body>
      </div>
    </div>
  );
}

// ─────────────────── LOGIN B — illustrated hero ───────────────────
function LoginB({ onSubmit = () => {} }) {
  return (
    <div style={{ height: '100%', background: AC.bg, display: 'flex', flexDirection: 'column' }}>
      {/* hero illustration band */}
      <div style={{ position: 'relative', height: 320, padding: '64px 24px 0', boxSizing: 'border-box' }}>
        <Illustration emotion="tender" scene="window" style={{ position: 'absolute', inset: '64px 24px 0', borderRadius: 0, borderBottomLeftRadius: 32, borderBottomRightRadius: 32 }}/>
        <div style={{ position: 'relative', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Wordmark size={22} color="#fff" />
          <Body size={13} style={{ color: '#fff', fontWeight: 600, opacity: 0.85 }}>Sign in</Body>
        </div>
        <div style={{ position: 'absolute', left: 24, bottom: 28, right: 24 }}>
          <Display size={42} style={{ color: '#2C2418', textShadow: '0 1px 2px rgba(255,255,255,0.4)' }}>
            Tiny moments<br/><em style={{ fontStyle: 'italic', color: AC.primary }}>worth keeping.</em>
          </Display>
        </div>
      </div>
      <div style={{ flex: 1, padding: '28px 24px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Field label="Email"><Input placeholder="parent@home.com"/></Field>
        <Field label="Password"><Input type="password" placeholder="••••••••"/></Field>
        <div style={{ flex: 1 }}/>
        <Button onClick={onSubmit} style={{ width: '100%' }}>Sign in</Button>
        <Body muted size={14} style={{ textAlign: 'center' }}>
          New here? <a onClick={() => onSubmit('signup')} style={{ color: AC.primary, fontWeight: 700, cursor: 'pointer' }}>Create an account</a>
        </Body>
      </div>
    </div>
  );
}

// ─────────────────── SIGNUP ───────────────────
function SignupA({ onSubmit = () => {} }) {
  return (
    <div style={{ height: '100%', background: AC.bg, padding: '78px 28px 28px', display: 'flex', flexDirection: 'column', boxSizing: 'border-box' }}>
      <Wordmark size={24} />
      <Display size={40} style={{ marginTop: 36 }}>Start your<br/>family journal.</Display>
      <Body muted size={15} style={{ marginTop: 12 }}>
        Private by default. Just for you and your people.
      </Body>
      <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Field label="How should we greet you?"><Input placeholder="A name, a nickname — your call"/></Field>
        <Field label="Email"><Input placeholder="parent@home.com"/></Field>
        <Field label="Password" hint="At least 8 characters."><Input type="password" placeholder="••••••••"/></Field>
      </div>
      <div style={{ flex: 1 }}/>
      <Button onClick={onSubmit} style={{ width: '100%' }}>Create account</Button>
      <Body muted size={13} style={{ textAlign: 'center', marginTop: 14, lineHeight: 1.5 }}>
        By continuing you agree to the<br/>
        <a style={{ color: AC.ink2, textDecoration: 'underline' }}>Terms</a> and <a style={{ color: AC.ink2, textDecoration: 'underline' }}>Privacy policy</a>.
      </Body>
    </div>
  );
}

// ─────────────────── ADD FAMILY MEMBER A ───────────────────
// The "first child" onboarding — gentle nudge, big photo well
function AddMemberA({ onSubmit = () => {} }) {
  const [photo, setPhoto] = React.useState(false);
  const [name, setName] = React.useState('');
  return (
    <div style={{ height: '100%', background: AC.bg, padding: '72px 24px 24px', display: 'flex', flexDirection: 'column', boxSizing: 'border-box' }}>
      <Eyebrow color={AC.primary}>Step 1 of 2</Eyebrow>
      <Display size={36} style={{ marginTop: 14 }}>Who comes first?</Display>
      <Body muted size={14.5} style={{ marginTop: 10, lineHeight: 1.55 }}>
        Add your child first — Momora is about their moments.
        We'll draw their portrait so every memory features them.
      </Body>

      {/* Photo well */}
      <div onClick={() => setPhoto(!photo)} style={{
        marginTop: 28, alignSelf: 'center',
        width: 168, height: 168, borderRadius: '50%',
        background: photo ? `linear-gradient(135deg, ${AC.tenderSoft}, ${AC.tender})` : AC.surface,
        border: `2px dashed ${photo ? 'transparent' : AC.borderStrong}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', position: 'relative', overflow: 'hidden',
        transition: 'all 220ms cubic-bezier(.22,.61,.36,1)',
      }}>
        {photo ? (
          <Display size={56} style={{ color: '#fff', fontStyle: 'italic' }}>L</Display>
        ) : (
          <div style={{ textAlign: 'center', color: AC.ink3 }}>
            <Icon name="camera" size={28} color={AC.ink3} />
            <Body size={12} style={{ color: AC.ink3, marginTop: 6 }}>Tap to add a photo</Body>
          </div>
        )}
      </div>

      <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Field label="Their name"><Input value={name} onChange={setName} placeholder="Lila"/></Field>
        <Field label="Date of birth"><Input placeholder="March 14, 2022"/></Field>
      </div>
      <div style={{ flex: 1 }}/>
      <Button onClick={onSubmit} style={{ width: '100%' }}>Save and continue</Button>
    </div>
  );
}

// ─────────────────── PORTRAIT REVEAL ───────────────────
// The hero "your portrait is ready" moment — the aha.
function PortraitReveal({ name = 'Lila', tint = 'tender', state = 'ready', onContinue = () => {} }) {
  return (
    <div style={{ height: '100%', background: AC.bg, padding: '88px 28px 32px', display: 'flex', flexDirection: 'column', boxSizing: 'border-box' }}>
      {state === 'generating' ? (
        <>
          <Eyebrow color={AC.sea}>Drawing now…</Eyebrow>
          <Display size={36} style={{ marginTop: 14 }}>Meeting <em style={{ fontStyle: 'italic', color: AC.primary }}>{name}</em>.</Display>
          <Body muted size={14.5} style={{ marginTop: 10 }}>
            We're sketching their character portrait. Usually takes about 20 seconds.
          </Body>
        </>
      ) : (
        <>
          <Eyebrow color={AC.success}>Ready</Eyebrow>
          <Display size={36} style={{ marginTop: 14 }}>Meet <em style={{ fontStyle: 'italic', color: AC.primary }}>{name}</em>.</Display>
          <Body muted size={14.5} style={{ marginTop: 10 }}>
            From now on every memory will feature this character.
            They'll grow up with you in the illustrations.
          </Body>
        </>
      )}

      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {/* Portrait card — pulses while generating, settled when ready */}
        <div style={{
          position: 'relative', width: 232, height: 232,
          borderRadius: 24, overflow: 'hidden',
          boxShadow: state === 'ready'
            ? '0 32px 60px rgba(214, 62, 120, 0.15), 0 1px 0 rgba(0,0,0,0.04)'
            : 'none',
          transform: state === 'ready' ? 'scale(1)' : 'scale(0.96)',
          transition: 'transform 380ms cubic-bezier(.22,.61,.36,1), box-shadow 380ms',
          animation: state === 'generating' ? 'pulse 1800ms ease-in-out infinite' : 'none',
        }}>
          <Illustration emotion={tint} scene="window" style={{ width: '100%', height: '100%', borderRadius: 24 }}/>
          {state === 'ready' && (
            <div style={{
              position: 'absolute', bottom: 14, left: 14,
              fontFamily: AF.script, fontSize: 24, color: AC.ink,
              transform: 'rotate(-3deg)',
            }}>{name}</div>
          )}
        </div>
      </div>
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes pulse {
          0%, 100% { opacity: 0.7; transform: scale(0.96); }
          50% { opacity: 1; transform: scale(0.99); }
        }
      `}}/>

      {state === 'ready'
        ? <Button onClick={onContinue} style={{ width: '100%' }}>Capture your first moment</Button>
        : <Body muted size={13} style={{ textAlign: 'center' }}>You can leave this screen — we'll keep working.</Body>
      }
    </div>
  );
}

Object.assign(window, { Wordmark, LoginA, LoginB, SignupA, AddMemberA, PortraitReveal });
