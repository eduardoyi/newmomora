// Onboarding — trust screens, paywall, portrait kickoff. S13–S16.
const { c: TRC, f: TRF, s: TRS, r: TRR } = window.MOMORA;
const TNB = window.ONB;

// ─── S13 · Trust A — trial timeline ───
function OnbTrial() {
  const nodes = [
    { icon: 'check', tint: 'calm', t: 'Today', d: 'Full access. You pay $0.00 today.' },
    { icon: 'send', tint: 'joy', t: 'Day 5', d: 'We remind you the trial is ending. Email and notification. No surprises.' },
    { icon: 'clock', tint: 'wonder', t: 'Day 7', d: 'Only then does the subscription start. Cancelling takes about 10 seconds, we timed it.' },
  ];
  return (
    <div style={{ height: '100%', background: TRC.bg, display: 'flex', flexDirection: 'column', padding: '0 26px' }}>
      <div style={{ paddingTop: 90 }}>
        <Display size={33}>Try everything free for 7 days.</Display>
      </div>
      <div style={{ marginTop: 34, position: 'relative' }}>
        <div style={{ position: 'absolute', left: 23, top: 24, bottom: 24, width: 2, background: TRC.border }}/>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 30 }}>
          {nodes.map(n => {
            const e = window.MOMORA_EMOTIONS[n.tint];
            return (
              <div key={n.t} style={{ display: 'flex', gap: 16, position: 'relative' }}>
                <div style={{ width: 48, height: 48, borderRadius: '50%', background: e.soft, border: `2px solid ${TRC.bg}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, boxShadow: `0 0 0 1px ${TRC.border}` }}>
                  <Icon name={n.icon} size={20} color={e.ink} strokeWidth={2}/>
                </div>
                <div style={{ paddingTop: 3 }}>
                  <Title size={19}>{n.t}</Title>
                  <Body muted size={14} style={{ marginTop: 4 }}>{n.d}</Body>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <div style={{ flex: 1 }}/>
      <div style={{ paddingBottom: 40 }}>
        <Button style={{ width: '100%' }}>Sounds fair</Button>
      </div>
    </div>
  );
}

// ─── S14 · Trust B — what's included + the promise ───
function OnbIncluded() {
  const items = [
    'Unlimited memories: talk, type, photos, video',
    `${TNB.name}'s illustrated portrait and storybook pages`,
    'The whole family can join, grandparents included, free',
    'Every memory searchable, finally out of the camera roll',
  ];
  return (
    <div style={{ height: '100%', background: TRC.bg, display: 'flex', flexDirection: 'column', padding: '0 26px' }}>
      <div style={{ paddingTop: 84 }}>
        <Display size={30}>Everything {TNB.name}'s journal comes with:</Display>
      </div>
      <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 14 }}>
        {items.map(t => (
          <div key={t} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <div style={{ width: 22, height: 22, borderRadius: '50%', background: TRC.primaryTint, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>
              <Icon name="check" size={13} color={TRC.primary} strokeWidth={2.5}/>
            </div>
            <Body size={15} style={{ lineHeight: 1.45 }}>{t}</Body>
          </div>
        ))}
      </div>
      {/* the promise — a signed card */}
      <div style={{ marginTop: 28, background: '#fff', border: `1.5px solid ${TRC.borderStrong}`, borderRadius: 18, padding: '20px 20px 16px', position: 'relative', transform: 'rotate(-0.6deg)', boxShadow: '0 10px 28px rgba(44,36,24,0.08)' }}>
        <Script size={20} color={TRC.primary} style={{ position: 'absolute', top: -12, left: 18, background: TRC.bg, padding: '0 8px', transform: 'rotate(-2deg)' }}>our promise</Script>
        <Title size={18}>Your memories are always yours.</Title>
        <Body muted size={14} style={{ marginTop: 8 }}>Export everything, free, whenever you want, even if you cancel someday. We've been burned by those apps too.</Body>
        <Script size={26} color={TRC.ink2} style={{ marginTop: 12, textAlign: 'right' }}>Eduardo &amp; Adriana</Script>
      </div>
      <div style={{ flex: 1 }}/>
      <div style={{ paddingBottom: 40 }}>
        <Button style={{ width: '100%' }}>Almost done</Button>
      </div>
    </div>
  );
}

// ─── S15 · Paywall ───
function OnbPaywall({ closeSheet = false }) {
  const pages = [
    { id: 'onb-page-1', rot: -6, x: -104 }, { id: 'onb-page-3', rot: 2, x: 0 }, { id: 'onb-page-4', rot: 7, x: 104 },
  ];
  return (
    <div style={{ height: '100%', background: TRC.bg, display: 'flex', flexDirection: 'column', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 56, right: 18, zIndex: 5, width: 30, height: 30, borderRadius: '50%', background: 'rgba(44,36,24,0.06)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
        <Icon name="x" size={15} color={TRC.ink3} strokeWidth={2}/>
      </div>
      {/* backdrop pages */}
      <div style={{ position: 'relative', height: 208, marginTop: 44 }}>
        {pages.map((p, i) => (
          <div key={p.id} style={{ position: 'absolute', left: '50%', top: 26, width: 132, height: 168, transform: `translateX(calc(-50% + ${p.x}px)) rotate(${p.rot}deg)`, zIndex: i === 1 ? 2 : 1, background: '#fff', border: `1px solid ${TRC.border}`, borderRadius: 12, padding: 5, boxShadow: '0 12px 28px rgba(44,36,24,0.12)' }}>
            <image-slot id={p.id} shape="rounded" radius="8" placeholder="Illustrated page" style={{ width: '100%', height: '100%' }}></image-slot>
          </div>
        ))}
      </div>
      <div style={{ padding: '10px 26px 0', textAlign: 'center' }}>
        <Display size={27}>Turn {TNB.name}'s little moments into something you'll hold forever.</Display>
      </div>
      <div style={{ padding: '18px 24px 0' }}>
        <div style={{ background: '#fff', border: `2px solid ${TRC.primary}`, borderRadius: 18, padding: '16px 18px', display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <Title size={17}>7 days free, then $99.99/year</Title>
            <Body muted size={13} style={{ marginTop: 3 }}>That's $8.33/month</Body>
          </div>
          <div style={{ width: 22, height: 22, borderRadius: '50%', background: TRC.primary, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="check" size={13} color="#fff" strokeWidth={3}/>
          </div>
        </div>
        <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 5 }}>
          {['$0.00 today', 'Reminder before your trial ends', 'Cancelling takes about 10 seconds', 'Your memories export free, forever'].map(t => (
            <div key={t} style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <Icon name="check" size={12} color={TRC.calm} strokeWidth={2.5}/>
              <Body muted size={12.5}>{t}</Body>
            </div>
          ))}
        </div>
      </div>
      <div style={{ flex: 1 }}/>
      <div style={{ padding: '0 24px 14px' }}>
        <Button style={{ width: '100%' }}>Start my free week</Button>
        <div style={{ marginTop: 10, display: 'flex', justifyContent: 'center', gap: 16, fontFamily: TRF.sans, fontSize: 11, color: TRC.ink3, paddingBottom: 14 }}>
          <span>Restore purchases</span><span>Terms</span><span>Privacy</span>
        </div>
      </div>
      {closeSheet && (
        <>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(44,36,24,0.32)', zIndex: 8 }}/>
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 9, background: '#fff', borderRadius: '24px 24px 0 0', padding: '26px 24px 40px', boxShadow: '0 -12px 40px rgba(44,36,24,0.18)', animation: 'ptsheet 320ms cubic-bezier(.22,.61,.36,1)' }}>
          <div style={{ width: 36, height: 4, borderRadius: 999, background: TRC.border, margin: '0 auto 18px' }}/>
          <Title size={20}>Leave {TNB.name}'s first page here for now?</Title>
          <Body muted size={14.5} style={{ marginTop: 8 }}>It'll be waiting if you come back.</Body>
          <div style={{ marginTop: 20, display: 'flex', gap: 10 }}>
            <Button variant="secondary" style={{ flex: 1 }}>Leave</Button>
            <Button style={{ flex: 2 }}>Stay</Button>
          </div>
          </div>
        </>
      )}
    </div>
  );
}

// ─── S16 · Portrait kickoff ───
// state: 'pick' | 'painting'
function OnbPortrait({ state = 'pick', multi = false }) {
  return (
    <div style={{ height: '100%', background: TRC.bg, display: 'flex', flexDirection: 'column', padding: '0 26px' }}>
      {state === 'pick' ? (
        <>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <div style={{ display: 'flex', gap: 12, alignItems: 'flex-end', marginBottom: 26 }}>
              <div style={{ width: 108, height: 128, background: '#fff', border: `1px solid ${TRC.border}`, borderRadius: 12, padding: 6, transform: 'rotate(-4deg)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 8px 22px rgba(44,36,24,0.09)' }}>
                <Icon name="image" size={30} color={TRC.ink3} strokeWidth={1.5}/>
              </div>
              <Icon name="arrowRight" size={20} color={TRC.ink3} style={{ marginBottom: 50 }}/>
              <div style={{ width: 108, height: 128, transform: 'rotate(3deg)', background: '#fff', border: `1px solid ${TRC.border}`, borderRadius: 12, padding: 6, boxShadow: '0 8px 22px rgba(44,36,24,0.09)' }}>
                <image-slot id="onb-portrait-sample" shape="rounded" radius="8" placeholder="Sample portrait" style={{ width: '100%', height: '100%' }}></image-slot>
              </div>
            </div>
            <Display size={32}>Let's make {TNB.name}'s portrait.</Display>
            <Body muted size={15} style={{ marginTop: 12 }}>Pick a photo you love. We'll illustrate {TNB.name} in Momora's style.</Body>
          </div>
          <div style={{ paddingBottom: 40 }}>
            <Button style={{ width: '100%' }} icon={<Icon name="image" size={18} color="#fff"/>}>Choose a photo</Button>
            {multi && <Body muted size={13} style={{ marginTop: 12, textAlign: 'center' }}>The others get their turn next, promise.</Body>}
          </div>
        </>
      ) : (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
          <div style={{ width: 148, height: 176, background: '#fff', border: `1px solid ${TRC.border}`, borderRadius: 14, padding: 7, transform: 'rotate(-2deg)', boxShadow: '0 12px 30px rgba(44,36,24,0.1)' }}>
            <Illustration emotion="tender" scene="bedroom" style={{ width: '100%', height: '100%', animation: 'ptpulse 2s ease-in-out infinite' }}/>
          </div>
          <Script size={22} color={TRC.primary} style={{ marginTop: 16, transform: 'rotate(-2deg)' }}>painting…</Script>
          <Title size={22} style={{ marginTop: 20 }}>We're painting.</Title>
          <Body muted size={14.5} style={{ marginTop: 10, maxWidth: 280 }}>It takes a few minutes, so go do literally anything else. It'll be here when you get back.</Body>
          <Button variant="secondary" size="md" style={{ marginTop: 26 }}>Take me to the journal</Button>
        </div>
      )}
    </div>
  );
}

// ─── S17 · Portrait reveal ───
// Fires in-app when a portrait finishes. Also the path to sibling portraits.
function OnbReveal({ nextKid = null, name = TNB.name }) {
  return (
    <div style={{ height: '100%', background: TRC.bg, display: 'flex', flexDirection: 'column', padding: '0 20px' }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', minHeight: 0 }}>
        <div style={{ position: 'relative', animation: 'revealSettle 640ms cubic-bezier(0.22,0.61,0.36,1) both' }}>
          <Paper pad={0} style={{ overflow: 'hidden', boxShadow: '0 18px 44px rgba(44,36,24,0.14)' }}>
            <image-slot id="onb-portrait-final" shape="rect" placeholder="Finished illustrated portrait of Lila" style={{ width: '100%', aspectRatio: '1/1' }}></image-slot>
          </Paper>
          <div style={{ position: 'absolute', bottom: -12, right: -6, width: 40, height: 40, borderRadius: '50%', background: '#fff', border: `1px solid ${TRC.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 6px 16px rgba(44,36,24,0.14)', animation: 'revealHeart 460ms cubic-bezier(0.34,1.56,0.64,1) 760ms both' }}>
            <Icon name="heart" size={19} color={TRC.primary} fill={TRC.primary} strokeWidth={1.5}/>
          </div>
        </div>
        <div style={{ padding: '26px 6px 0' }}>
          <Display size={32}>Meet {name}.</Display>
          <Body muted size={13.5} style={{ marginTop: 10 }}>Painted from the photo you picked. This is how {name} shows up in the journal from now on.</Body>
        </div>
      </div>
      <div style={{ padding: '0 6px 40px' }}>
        {nextKid ? (
          <>
            <Button style={{ width: '100%' }} icon={<Icon name="image" size={18} color="#fff"/>}>{nextKid}'s turn. Pick a photo</Button>
            <div style={{ marginTop: 14, textAlign: 'center', fontFamily: TRF.sans, fontSize: 13.5, fontWeight: 700, color: TRC.ink3, cursor: 'pointer' }}>Later</div>
          </>
        ) : (
          <Button style={{ width: '100%' }}>Take me to the journal</Button>
        )}
      </div>
      <style>{`@keyframes revealSettle{from{opacity:0;transform:translateY(14px) scale(0.97)}to{opacity:1;transform:none}}@keyframes revealHeart{0%{opacity:0;transform:scale(0)}60%{transform:scale(1.22)}100%{opacity:1;transform:scale(1)}}`}</style>
    </div>
  );
}

// Companion state: an unpainted kid in the family tab. An invitation, not a task.
function UnpaintedKidCard({ name = 'Miguel', tint = 'wonder' }) {
  const e = window.MOMORA_EMOTIONS[tint];
  return (
    <Paper pad={0} style={{ padding: '16px 16px', display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer' }}>
      <div style={{ width: 54, height: 54, borderRadius: 16, background: TRC.bg, border: `1.5px dashed ${e.c}88`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon name="users" size={24} color={`${e.ink}`} strokeWidth={1.25}/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <Title size={17}>{name}</Title>
        <Script size={19} color={TRC.ink3} style={{ marginTop: 1 }}>waiting to be painted</Script>
      </div>
      <Icon name="chevronRight" size={18} color={TRC.ink3}/>
    </Paper>
  );
}

// Framing card for the canvas: shows the waiting card in the cast list context.
function CastWaitingState() {
  return (
    <div style={{ height: '100%', background: TRC.bg, padding: '58px 22px 0' }}>
      <Eyebrow>The cast</Eyebrow>
      <Display size={28} style={{ marginTop: 8 }}>The Rivera Family</Display>
      <div style={{ marginTop: 22, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Paper pad={0} style={{ padding: '16px 16px', display: 'flex', alignItems: 'center', gap: 14 }}>
          <Avatar name="Lila" size={54} tint="tender"/>
          <div style={{ flex: 1 }}>
            <Title size={17}>Lila</Title>
            <Body muted size={13} style={{ marginTop: 2 }}>32 memories</Body>
          </div>
        </Paper>
        <UnpaintedKidCard name="Miguel" tint="wonder"/>
        <UnpaintedKidCard name="Teo" tint="joy"/>
      </div>
    </div>
  );
}

Object.assign(window, { OnbTrial, OnbIncluded, OnbPaywall, OnbPortrait, OnbReveal, UnpaintedKidCard, CastWaitingState });
