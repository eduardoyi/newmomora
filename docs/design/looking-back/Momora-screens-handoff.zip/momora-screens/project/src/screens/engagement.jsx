// Likes + comments — Instagram-style engagement layer for memories.
// A tiny shared store keyed by memory id keeps every instance in sync
// (like on the timeline persists into the detail view, etc.)
const { c: EC, f: EF, s: ES, r: ER } = window.MOMORA;

// ── Animation keyframes (injected once) ──────────────────────────────────────
(function injectEngagementCss() {
  if (document.getElementById('momora-engagement-css')) return;
  const el = document.createElement('style');
  el.id = 'momora-engagement-css';
  el.textContent = `
    @keyframes momHeartPop  { 0%{transform:scale(1)} 30%{transform:scale(1.34)} 60%{transform:scale(.9)} 100%{transform:scale(1)} }
    @keyframes momHeartRing { 0%{transform:scale(.5);opacity:.55} 100%{transform:scale(1.9);opacity:0} }
    @keyframes momDrawerIn  { from{transform:translateY(100%)} to{transform:translateY(0)} }
    @keyframes momScrimIn   { from{opacity:0} to{opacity:1} }
    @keyframes momCommentIn { from{opacity:0;transform:translateY(7px)} to{opacity:1;transform:translateY(0)} }
  `;
  document.head.appendChild(el);
})();

// ── Shared store ─────────────────────────────────────────────────────────────
const engStore = (function () {
  const data = {};   // id -> { liked, likeCount, comments }
  const subs = {};   // id -> Set<fn>
  return {
    ensure(m) {
      if (!data[m.id]) {
        data[m.id] = {
          liked: !!m.likedByMe,
          likeCount: m.likeCount || 0,
          comments: (m.comments || []).map(c => ({ ...c })),
        };
      }
      return data[m.id];
    },
    get(id) { return data[id]; },
    sub(id, fn) { (subs[id] = subs[id] || new Set()).add(fn); return () => subs[id] && subs[id].delete(fn); },
    emit(id) { (subs[id] || []).forEach(fn => fn()); },
  };
})();

function useEngagement(m) {
  engStore.ensure(m);
  const [, force] = React.useReducer(x => x + 1, 0);
  React.useEffect(() => engStore.sub(m.id, force), [m.id]);
  const [pop, setPop] = React.useState(0);
  const s = engStore.get(m.id);

  const toggleLike = () => {
    const st = engStore.get(m.id);
    st.liked = !st.liked;
    st.likeCount += st.liked ? 1 : -1;
    if (st.liked) setPop(p => p + 1);
    engStore.emit(m.id);
  };
  const addComment = (text) => {
    const t = (text || '').trim();
    if (!t) return;
    const st = engStore.get(m.id);
    st.comments = [...st.comments, { id: 'c_' + Date.now(), author: 'sam', text: t, ago: 'now', mine: true }];
    engStore.emit(m.id);
  };
  return { liked: s.liked, likeCount: s.likeCount, comments: s.comments, pop, toggleLike, addComment };
}

const engBtn = {
  background: 'none', border: 'none', padding: 0, cursor: 'pointer',
  display: 'inline-flex', alignItems: 'center', gap: 7, WebkitTapHighlightColor: 'transparent',
};

// ── Like button — outline heart → filled with a gentle pop ───────────────────
function LikeButton({ liked, count, pop, onToggle, size = 22 }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onToggle(); }}
      aria-label={liked ? 'Unlike' : 'Like'}
      style={engBtn}>
      <span style={{ position: 'relative', width: size, height: size, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
        {liked && pop > 0 && (
          <span key={'ring' + pop} style={{
            position: 'absolute', width: size, height: size, borderRadius: '50%',
            border: `2px solid ${EC.primary}`, pointerEvents: 'none',
            animation: 'momHeartRing 460ms cubic-bezier(.22,.61,.36,1) forwards',
          }}/>
        )}
        <span key={liked ? 'on' + pop : 'off'} style={{
          display: 'inline-flex',
          animation: liked && pop > 0 ? 'momHeartPop 380ms cubic-bezier(.22,.61,.36,1)' : 'none',
        }}>
          <Icon name="heart" size={size} strokeWidth={1.9}
            color={liked ? EC.primary : EC.ink2}
            fill={liked ? EC.primary : 'none'}/>
        </span>
      </span>
      {count > 0 && (
        <span style={{ fontFamily: EF.sans, fontSize: 13.5, fontWeight: 700, color: liked ? EC.primary : EC.ink2, minWidth: 8 }}>
          {count}
        </span>
      )}
    </button>
  );
}

// ── Comment button — speech bubble + count ───────────────────────────────────
function CommentButton({ count, onClick, size = 22 }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      aria-label="Comments"
      style={engBtn}>
      <Icon name="messageCircle" size={size} strokeWidth={1.9} color={EC.ink2}/>
      {count > 0 && (
        <span style={{ fontFamily: EF.sans, fontSize: 13.5, fontWeight: 700, color: EC.ink2, minWidth: 8 }}>
          {count}
        </span>
      )}
    </button>
  );
}

// ── Combined bar — heart + comment ───────────────────────────────────────────
function EngagementBar({ eng, onOpenComments, iconSize = 22, style = {} }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 20, ...style }}>
      <LikeButton liked={eng.liked} count={eng.likeCount} pop={eng.pop} onToggle={eng.toggleLike} size={iconSize}/>
      <CommentButton count={eng.comments.length} onClick={onOpenComments} size={iconSize}/>
    </div>
  );
}

// ── Comments bottom sheet ────────────────────────────────────────────────────
function CommentsDrawer({ open, onClose, eng }) {
  const [text, setText] = React.useState('');
  const listRef = React.useRef(null);
  const count = eng.comments.length;

  React.useEffect(() => {
    if (open && listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [count, open]);

  if (!open) return null;
  const you = window.MOMORA_MOCK.byId['sam'];
  const submit = () => { if (!text.trim()) return; eng.addComment(text); setText(''); };

  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 60, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
      {/* scrim */}
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: 'rgba(44,36,24,0.34)',
        animation: 'momScrimIn 220ms ease-out',
      }}/>
      {/* sheet */}
      <div style={{
        position: 'relative', height: '80%', background: '#fff',
        borderRadius: '24px 24px 0 0', boxShadow: '0 -14px 44px rgba(40,30,20,0.20)',
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
        animation: 'momDrawerIn 380ms cubic-bezier(.22,.61,.36,1)',
      }}>
        {/* grabber */}
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 10 }}>
          <div style={{ width: 40, height: 5, borderRadius: 999, background: EC.border }}/>
        </div>
        {/* header */}
        <div style={{ padding: '12px 20px', borderBottom: `1px solid ${EC.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Title size={18}>Comments</Title>
          <span style={{ fontFamily: EF.sans, fontSize: 13, fontWeight: 700, color: EC.ink3 }}>{count}</span>
        </div>
        {/* list */}
        <div ref={listRef} style={{ flex: 1, overflowY: 'auto', padding: '18px 20px 10px', display: 'flex', flexDirection: 'column', gap: 20 }}>
          {count === 0 ? (
            <div style={{ margin: 'auto', textAlign: 'center', padding: '20px 0' }}>
              <Body size={15} style={{ fontWeight: 700, color: EC.ink }}>No comments yet</Body>
              <Body size={13} muted style={{ marginTop: 4 }}>Be the first to say something.</Body>
            </div>
          ) : eng.comments.map(c => {
            const a = window.MOMORA_MOCK.byId[c.author] || { name: 'Someone', tint: 'joy' };
            return (
              <div key={c.id} style={{ display: 'flex', gap: 11, animation: c.mine ? 'momCommentIn 260ms cubic-bezier(.22,.61,.36,1)' : 'none' }}>
                <Avatar name={a.name} size={34} tint={a.tint}/>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                    <span style={{ fontFamily: EF.sans, fontSize: 13.5, fontWeight: 700, color: EC.ink }}>
                      {a.name}{c.author === 'sam' ? ' · you' : ''}
                    </span>
                    <span style={{ fontFamily: EF.sans, fontSize: 11, fontWeight: 500, color: EC.ink3 }}>{c.ago}</span>
                  </div>
                  <div style={{ fontFamily: EF.sans, fontSize: 14, lineHeight: 1.5, color: EC.ink, marginTop: 2, wordBreak: 'break-word' }}>
                    {c.text}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        {/* input */}
        <div style={{ borderTop: `1px solid ${EC.border}`, padding: '12px 16px 26px', display: 'flex', alignItems: 'center', gap: 10, background: '#fff' }}>
          <Avatar name={you.name} size={34} tint={you.tint}/>
          <input
            value={text}
            onChange={e => setText(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') submit(); }}
            placeholder="Add a comment…"
            style={{
              flex: 1, border: 'none', outline: 'none', background: EC.surface,
              borderRadius: 999, padding: '11px 16px',
              fontFamily: EF.sans, fontSize: 14, color: EC.ink,
            }}/>
          <button onClick={submit} disabled={!text.trim()} aria-label="Post comment" style={{
            width: 40, height: 40, borderRadius: '50%', flexShrink: 0, border: 'none',
            background: text.trim() ? EC.primary : EC.border, cursor: text.trim() ? 'pointer' : 'default',
            display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'background 140ms',
          }}>
            <Icon name="send" size={17} color="#fff" strokeWidth={2}/>
          </button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { useEngagement, LikeButton, CommentButton, EngagementBar, CommentsDrawer });
