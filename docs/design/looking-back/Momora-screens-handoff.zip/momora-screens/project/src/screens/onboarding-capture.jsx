// Onboarding — capture, aha, permission, account. S9–S12.
const { c: CC, f: CF, s: CS, r: CR } = window.MOMORA;
const CNB = window.ONB;

// ─── S9 · Guided first capture ───
// mode: 'idle' | 'recording' | 'transcribing' | 'typed' | 'photo'
function OnbCapture({ mode = 'idle', kids = [], selected = [0] }) {
  const recording = mode === 'recording', transcribing = mode === 'transcribing';
  const typed = mode === 'typed', photo = mode === 'photo';
  const multi = kids.length > 1;
  const who = !multi ? CNB.name
    : selected.length === 1 ? kids[selected[0]]
    : selected.length === 2 ? 'the two of them'
    : 'all of them';
  // Multi-kid families get one prompt about the moment, not about a name.
  const prompt = multi
    ? "What's something small from this week that made you smile?"
    : `What's something small ${who} did this week that made you smile?`;
  const typedText = "She lined up all her stuffed animals facing the window and told them to \"watch for the garbage truck, it's the best part.\"";
  return (
    <div style={{ height: '100%', background: CC.bg, display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '58px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Button variant="ghost" size="sm">Cancel</Button>
        <Eyebrow color={CC.ink3}>First page</Eyebrow>
        <div style={{ width: 60 }}/>
      </div>
      {multi && (
        <div style={{ display: 'flex', gap: 8, padding: '16px 20px 0', flexWrap: 'wrap' }}>
          {kids.map((k, i) => {
            const on = selected.includes(i);
            return (
              <div key={k} style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: on ? CC.primaryTint : '#fff', border: `1.5px solid ${on ? CC.primary : CC.border}`, borderRadius: 999, padding: '4px 11px 4px 4px', cursor: 'pointer' }}>
                <Avatar name={k} size={24} tint={window.kidTint(i)}/>
                <span style={{ fontFamily: CF.sans, fontSize: 13.5, fontWeight: 700, color: on ? CC.primaryDark : CC.ink2 }}>{k}</span>
              </div>
            );
          })}
        </div>
      )}
      <div style={{ padding: '18px 28px 0' }}>
        <Display size={27}>{prompt}</Display>
      </div>

      {(typed || photo) ? (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '18px 24px 0' }}>
          {photo && (
            <div style={{ width: 130, height: 130, marginBottom: 14, position: 'relative' }}>
              <MediaThumbnail kind="photo" color="#ddc9a8" style={{ width: '100%', height: '100%', borderRadius: 14 }}/>
              <div style={{ position: 'absolute', top: -7, right: -7, width: 24, height: 24, borderRadius: '50%', background: CC.ink, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="x" size={12} color="#fff" strokeWidth={2.5}/>
              </div>
            </div>
          )}
          <textarea defaultValue={photo ? 'Garbage truck fan club, front row seats.' : typedText} rows={photo ? 3 : 5} style={{
            width: '100%', boxSizing: 'border-box', border: 'none', outline: 'none', resize: 'none', background: 'transparent',
            fontFamily: CF.display, fontWeight: 400, fontSize: 21, lineHeight: 1.45, color: CC.ink, caretColor: CC.primary,
          }}/>
          <div style={{ flex: 1 }}/>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 0 12px', borderTop: `1px solid ${CC.border}` }}>
            <button style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: CC.surface, border: `1px solid ${CC.border}`, borderRadius: 999, padding: '7px 13px', fontFamily: CF.sans, fontSize: 12.5, fontWeight: 700, color: CC.ink2, cursor: 'pointer' }}>
              <Icon name="mic" size={14}/> Talk instead
            </button>
            {!photo && <button style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: CC.surface, border: `1px solid ${CC.border}`, borderRadius: 999, padding: '7px 13px', fontFamily: CF.sans, fontSize: 12.5, fontWeight: 700, color: CC.ink2, cursor: 'pointer' }}>
              <Icon name="camera" size={14}/> Add a photo
            </button>}
            <div style={{ flex: 1 }}/>
            <Button size="md">Keep this one</Button>
          </div>
          <OnbKeyboard/>
        </div>
      ) : (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 32px' }}>
          <div style={{ position: 'relative', width: 230, height: 230, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(circle, ${CC.primaryTint} 0%, transparent 70%)`, borderRadius: '50%', transform: recording ? 'scale(1.1)' : 'scale(0.85)', transition: 'transform 1200ms ease-in-out', animation: recording ? 'ptpulse 1.6s ease-in-out infinite' : 'none' }}/>
            <div style={{ position: 'absolute', inset: 34, background: `radial-gradient(circle at 40% 35%, ${CC.primarySoft} 0%, ${CC.primary}44 85%)`, borderRadius: '50%', transform: recording ? 'scale(1)' : 'scale(0.78)', transition: 'transform 220ms cubic-bezier(.22,.61,.36,1)' }}/>
            <button style={{ position: 'relative', width: 94, height: 94, borderRadius: '50%', background: recording ? '#fff' : CC.primary, border: 'none', cursor: 'pointer', boxShadow: `0 16px 40px ${CC.primary}55`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {transcribing
                ? <div style={{ width: 30, height: 30, border: `3px solid ${CC.primarySoft}`, borderTopColor: '#fff', borderRadius: '50%', animation: 'ptspin 0.9s linear infinite' }}/>
                : recording ? <Icon name="stop" size={26} color={CC.primary} strokeWidth={2}/>
                : <Icon name="mic" size={34} color="#fff" strokeWidth={2}/>}
            </button>
          </div>
          <div style={{ marginTop: 26, textAlign: 'center', minHeight: 80 }}>
            {mode === 'idle' && <>
              <Body size={15} style={{ fontWeight: 700 }}>Tap and talk</Body>
              <Script size={22} color={CC.ink2} style={{ marginTop: 6 }}>say it like you'd text your best friend</Script>
            </>}
            {recording && <>
              {/* soft waveform, no countdown */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 3.5, height: 34 }}>
                {[10,18,26,14,30,22,12,26,18,8,20,28,14].map((h, i) => (
                  <div key={i} style={{ width: 4, height: h, borderRadius: 999, background: CC.primary, opacity: 0.4 + (h / 44), animation: `ptpulse ${1 + (i % 4) * 0.22}s ease-in-out infinite` }}/>
                ))}
              </div>
              <Body size={14} muted style={{ marginTop: 10 }}>Listening. Take your time.</Body>
            </>}
            {transcribing && <>
              <Body size={15} style={{ fontWeight: 700, color: CC.primaryDark }}>One second…</Body>
              <Body size={13.5} muted style={{ marginTop: 8 }}>Turning your words into a page.</Body>
            </>}
          </div>
        </div>
      )}

      {!typed && !photo && (
        <div style={{ padding: '0 24px 36px', display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'center' }}>
          <div style={{ display: 'flex', gap: 10 }}>
            <button style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: '#fff', border: `1px solid ${CC.border}`, borderRadius: 999, padding: '10px 16px', fontFamily: CF.sans, fontSize: 13.5, fontWeight: 700, color: CC.ink, cursor: 'pointer' }}>
              <Icon name="type" size={15}/> I'd rather type
            </button>
            <button style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: '#fff', border: `1px solid ${CC.border}`, borderRadius: 999, padding: '10px 16px', fontFamily: CF.sans, fontSize: 13.5, fontWeight: 700, color: CC.ink2, cursor: 'pointer' }}>
              <Icon name="plus" size={15}/> Add a photo or video
            </button>
          </div>
          <Body size={12.5} muted style={{ textAlign: 'center' }}>Twenty seconds of rambling is plenty. Grammar optional.</Body>
        </div>
      )}
    </div>
  );
}

// ─── S10 · The aha — their first page ───
// variant: 'quote' (text only) | 'spread' (photo attached)
function OnbAha({ variant = 'quote', tagged = [CNB.name] }) {
  const emo = window.MOMORA_EMOTIONS.joy;
  const text = "She lined up all her stuffed animals facing the window and told them to \"watch for the garbage truck, it's the best part.\"";
  return (
    <div style={{ height: '100%', background: CC.bg, display: 'flex', flexDirection: 'column', padding: '0 22px' }}>
      <div style={{ paddingTop: 66, textAlign: 'center' }}>
        <Eyebrow color={CC.ink3} style={{ fontSize: 10.5 }}>That cost you about 20 seconds of your evening</Eyebrow>
      </div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '14px 0' }}>
        <div style={{ width: '100%', animation: 'ptfade 600ms cubic-bezier(.22,.61,.36,1)' }}>
          <Paper pad={0} style={{ overflow: 'hidden', boxShadow: '0 18px 44px rgba(44,36,24,0.12)' }}>
            {variant === 'spread' ? (
              <MediaThumbnail kind="photo" color="#ddc9a8" style={{ width: '100%', aspectRatio: '4/3' }}/>
            ) : (
              <div style={{ position: 'relative', padding: '34px 24px 8px', background: `linear-gradient(170deg, ${emo.soft}55 0%, transparent 60%)` }}>
                <div style={{ position: 'absolute', top: 6, left: 14, fontFamily: CF.display, fontSize: 84, color: emo.c, opacity: 0.18, lineHeight: 1 }}>&ldquo;</div>
                <div style={{ fontFamily: CF.display, fontStyle: 'italic', fontSize: 21.5, lineHeight: 1.45, color: CC.ink, position: 'relative' }}>{text}</div>
              </div>
            )}
            {variant === 'spread' && (
              <div style={{ padding: '14px 18px 0' }}>
                <Body size={14.5}>Garbage truck fan club, front row seats.</Body>
              </div>
            )}
            <div style={{ padding: '12px 18px 16px', display: 'flex', alignItems: 'center', gap: 8 }}>
              <Eyebrow color={CC.ink3} style={{ fontSize: 10 }}>Tonight</Eyebrow>
              <Avatar name={CNB.name} size={22} tint="tender"/>
              <span style={{ fontFamily: CF.sans, fontSize: 12.5, fontWeight: 700, color: CC.ink2 }}>{CNB.name}</span>
              <div style={{ flex: 1 }}/>
              <EmotionChip emotion="joy" size="sm"/>
              {/* like-heart pop, same curve as the likes feature */}
              <div style={{ animation: 'onbHeartPop 480ms cubic-bezier(.34,1.56,.64,1) 1.2s both' }}>
                <Icon name="heart" size={22} color={CC.primary} fill={CC.primary} strokeWidth={1.5}/>
              </div>
            </div>
          </Paper>
          <Script size={17} color={CC.ink3} style={{ textAlign: 'right', marginTop: 8, transform: 'rotate(-1.5deg)' }}>saved · {CNB.name}'s journal</Script>
        </div>
      </div>
      <div style={{ paddingBottom: 40, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Body size={15.5} style={{ textAlign: 'center' }}>{tagged.length > 1 ? 'Their' : `${tagged[0]}'s`} first page. Imagine a year of these.</Body>
        <Button style={{ width: '100%' }}>Keep it going</Button>
      </div>
      <style>{`@keyframes onbHeartPop { 0% { transform: scale(0); opacity: 0 } 60% { transform: scale(1.25) } 100% { transform: scale(1); opacity: 1 } }`}</style>
    </div>
  );
}

// ─── S11 · Notification question ───
function OnbNotify({ selected = null }) {
  const opts = [
    { id: 'eve', icon: 'moon', tint: 'wonder', label: "Evenings, once they're finally asleep", meta: '8:00 pm' },
    { id: 'late', icon: 'moon', tint: 'mischief', label: 'Later, when the dishes are done', meta: '10:00 pm' },
    { id: 'morn', icon: 'sun', tint: 'joy', label: 'Mornings, coffee in hand', meta: '8:00 am' },
    { id: 'none', icon: 'x', tint: 'calm', label: "No reminders. I'll show up on my own" },
  ];
  return (
    <div style={{ height: '100%', background: CC.bg, display: 'flex', flexDirection: 'column', padding: '0 24px' }}>
      <div style={{ paddingTop: 84 }}>
        <Display size={31}>When's a good time for a gentle nudge?</Display>
      </div>
      <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {opts.map(o => {
          const e = window.MOMORA_EMOTIONS[o.tint], on = selected === o.id;
          return (
            <div key={o.id} style={{ display: 'flex', alignItems: 'center', gap: 14, background: on ? CC.primaryTint : '#fff', border: `1.5px solid ${on ? CC.primary : CC.border}`, borderRadius: 16, padding: '14px 16px', cursor: 'pointer' }}>
              <div style={{ width: 40, height: 40, borderRadius: 12, background: e.soft, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Icon name={o.icon} size={19} color={e.ink} strokeWidth={1.75}/>
              </div>
              <span style={{ flex: 1, fontFamily: CF.sans, fontSize: 15, fontWeight: 600, color: CC.ink, lineHeight: 1.35 }}>{o.label}</span>
              {o.meta && <span style={{ fontFamily: CF.sans, fontSize: 12.5, fontWeight: 700, color: on ? CC.primary : CC.ink3, flexShrink: 0 }}>{o.meta}</span>}
            </div>
          );
        })}
      </div>
      <Body size={12.5} muted style={{ marginTop: 18 }}>One nudge a day at most, and you can change the time later. Never a notification that starts with "Don't forget…"</Body>
    </div>
  );
}

// ─── S12 · Account (email OTP) ───
function OnbEmail() {
  return (
    <div style={{ height: '100%', background: CC.bg, display: 'flex', flexDirection: 'column' }}>
      <div style={{ flex: 1, padding: '84px 26px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
          <div style={{ width: 54, height: 54, borderRadius: 10, background: '#fff', border: `1px solid ${CC.border}`, padding: 4, transform: 'rotate(-3deg)', boxShadow: '0 6px 16px rgba(44,36,24,0.1)' }}>
            <Illustration emotion="joy" scene="window" style={{ width: '100%', height: '100%', borderRadius: 7 }}/>
          </div>
          <Script size={19} color={CC.ink3}>your first page, safe and sound</Script>
        </div>
        <Display size={31}>Let's put {CNB.name}'s first memory somewhere safe.</Display>
        <Body muted size={15} style={{ marginTop: 12 }}>Email in, code back. No passwords, ever.</Body>
        <div style={{ marginTop: 24 }}>
          <Input placeholder="you@email.com" type="email"/>
        </div>
        <Button style={{ width: '100%', marginTop: 14 }}>Send my code</Button>
        <Body size={12.5} muted style={{ marginTop: 14, textAlign: 'center' }}>The memory is already saved on this phone either way.</Body>
      </div>
      <OnbKeyboard/>
    </div>
  );
}

function OnbCode({ filled = 3 }) {
  const code = '481937';
  return (
    <div style={{ height: '100%', background: CC.bg, display: 'flex', flexDirection: 'column' }}>
      <div style={{ flex: 1, padding: '96px 26px 0' }}>
        <Display size={32}>Check your inbox.</Display>
        <Body muted size={15} style={{ marginTop: 12 }}>We sent a 6-digit code to sam@rivera.family.</Body>
        <div style={{ marginTop: 30, display: 'flex', gap: 9, justifyContent: 'center' }}>
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} style={{
              width: 46, height: 58, borderRadius: 12, background: '#fff',
              border: `1.5px solid ${i === filled ? CC.primary : CC.border}`,
              boxShadow: i === filled ? `0 0 0 3px ${CC.primaryTint}` : 'none',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: CF.display, fontWeight: 500, fontSize: 27, color: CC.ink,
            }}>{i < filled ? code[i] : ''}</div>
          ))}
        </div>
        <div style={{ marginTop: 22, textAlign: 'center', fontFamily: CF.sans, fontSize: 13.5, fontWeight: 700, color: CC.primary }}>Resend code</div>
      </div>
      <OnbKeyboard/>
    </div>
  );
}

Object.assign(window, { OnbCapture, OnbAha, OnbNotify, OnbEmail, OnbCode });
