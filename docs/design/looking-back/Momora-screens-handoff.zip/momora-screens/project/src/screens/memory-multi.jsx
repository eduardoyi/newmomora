// Multi-media memory — carousel detail, new memory composer, edit
const { c: MMC, f: MMF, s: MMS, r: MMR } = window.MOMORA;

const mmIconBtn = {
  width: 38, height: 38, borderRadius: '50%', background: '#fff',
  border: `1px solid ${window.MOMORA.c.border}`,
  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
};

// ─── MEDIA CAROUSEL ──────────────────────────────────────────────────────────
// Swipeable (mouse + touch). Dots below; counter badge top-right.
// startIdx: open at a specific slide (for static artboard snapshots).
function MediaCarousel({ items = [], borderRadius = 14, startIdx = 0 }) {
  const [idx, setIdx] = React.useState(Math.min(startIdx, items.length - 1));
  const total = items.length;
  const [dragStartX, setDragStartX] = React.useState(null);
  const [liveOffset, setLiveOffset] = React.useState(0);

  const begin = (x) => setDragStartX(x);
  const move  = (x) => {
    if (dragStartX === null) return;
    setLiveOffset(Math.max(-100, Math.min(100, x - dragStartX)));
  };
  const commit = () => {
    if (dragStartX === null) return;
    if (liveOffset < -50 && idx < total - 1) setIdx(i => i + 1);
    else if (liveOffset > 50 && idx > 0)    setIdx(i => i - 1);
    setDragStartX(null);
    setLiveOffset(0);
  };

  const dragging = dragStartX !== null;
  const trackX   = `calc(-${idx * 100}% + ${dragging ? liveOffset : 0}px)`;

  return (
    <div>
      {/* Slide track */}
      <div
        style={{ position: 'relative', overflow: 'hidden', borderRadius, userSelect: 'none',
          cursor: total > 1 ? 'grab' : 'default' }}
        onMouseDown={e => { e.preventDefault(); begin(e.clientX); }}
        onMouseMove={e => move(e.clientX)}
        onMouseUp={commit}
        onMouseLeave={() => { if (dragging) commit(); }}
        onTouchStart={e => begin(e.touches[0].clientX)}
        onTouchMove={e => { e.preventDefault(); move(e.touches[0].clientX); }}
        onTouchEnd={commit}
      >
        {/* Sliding row — each item occupies 100% of the container width */}
        <div style={{
          display: 'flex',
          transform: `translateX(${trackX})`,
          transition: dragging ? 'none' : 'transform 300ms cubic-bezier(0.22,0.61,0.36,1)',
        }}>
          {items.map((item, i) => (
            <div key={i} style={{ minWidth: '100%', aspectRatio: '4/3', flexShrink: 0, position: 'relative' }}>
              <MediaThumbnail
                kind={item.kind} color={item.color}
                style={{ width: '100%', height: '100%', borderRadius: 0 }}
              />
              {item.kind === 'video' && (
                <div style={{
                  position: 'absolute', bottom: 10, right: 12,
                  background: 'rgba(0,0,0,0.48)', borderRadius: 999,
                  padding: '4px 10px', display: 'flex', alignItems: 'center', gap: 5,
                  pointerEvents: 'none',
                }}>
                  <Icon name="play" size={11} color="#fff" strokeWidth={2.5}/>
                  <span style={{ fontFamily: MMF.sans, fontSize: 12, fontWeight: 600, color: '#fff' }}>
                    {item.duration || '0:32'}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Counter badge — "X/N" pill, top-right inside the image */}
        {total > 1 && (
          <div style={{
            position: 'absolute', top: 10, right: 10,
            background: 'rgba(0,0,0,0.52)', borderRadius: 999,
            padding: '4px 10px', pointerEvents: 'none',
          }}>
            <span style={{ fontFamily: MMF.sans, fontSize: 12, fontWeight: 700, color: '#fff', letterSpacing: '0.01em' }}>
              {idx + 1}/{total}
            </span>
          </div>
        )}
      </div>

      {/* Pagination dots — below the image, tappable */}
      {total > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 5, padding: '10px 0 4px' }}>
          {items.map((_, i) => (
            <div
              key={i}
              onClick={() => setIdx(i)}
              style={{
                width:  i === idx ? 8 : 5,
                height: i === idx ? 8 : 5,
                borderRadius: '50%',
                background: i === idx ? MMC.primary : MMC.border,
                transition: 'all 220ms cubic-bezier(0.22,0.61,0.36,1)',
                flexShrink: 0, cursor: 'pointer',
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── MEMORY DETAIL — MULTI-MEDIA ─────────────────────────────────────────────
function MemoryDetailMultiMedia({
  m        = window.MOMORA_MOCK.memories.find(x => x.memory_type === 'multi_media') || window.MOMORA_MOCK.memories[0],
  onBack   = () => {},
  onEdit   = () => {},
  startIdx = 0,
  autoOpenComments = false,
}) {
  const items = m.mediaItems || [];
  const eng = useEngagement(m);
  const [commentsOpen, setCommentsOpen] = React.useState(!!autoOpenComments);

  return (
    <div style={{ height: '100%', background: MMC.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative' }}>

      {/* Header */}
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <button onClick={onBack} style={mmIconBtn}>
          <Icon name="chevronLeft" size={18} color={MMC.ink2}/>
        </button>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={onEdit} style={mmIconBtn}><Icon name="edit" size={16} color={MMC.ink2}/></button>
          <button style={mmIconBtn}><Icon name="trash" size={15} color={MMC.error}/></button>
        </div>
      </div>

      {/* Scrollable body */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: '16px 24px 40px' }}>

          {/* White memory card — same framed-print structure as MemoryDetailA */}
          <div style={{
            background: '#fff', border: `1px solid ${MMC.border}`,
            borderRadius: 24, padding: 14,
            boxShadow: '0 6px 24px rgba(40,30,20,0.07)',
          }}>
            <MediaCarousel items={items} borderRadius={14} startIdx={startIdx}/>

            {/* Metadata */}
            <div style={{ padding: '14px 10px 6px', display: 'flex', flexDirection: 'column', gap: 10 }}>
              <EngagementBar eng={eng} onOpenComments={() => setCommentsOpen(true)} iconSize={24}/>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Eyebrow color={MMC.primary} style={{ fontSize: 11 }}>{window.fmtDate(m.date)}</Eyebrow>
                {/* item-count badge */}
                <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: 4,
                  background: MMC.surface, border: `1px solid ${MMC.border}`,
                  borderRadius: 999, padding: '3px 9px 3px 7px',
                }}>
                  <Icon name="layers" size={11} color={MMC.ink3} strokeWidth={1.75}/>
                  <span style={{ fontFamily: MMF.sans, fontSize: 11, fontWeight: 600, color: MMC.ink3 }}>
                    {items.length} {items.length === 1 ? 'item' : 'items'}
                  </span>
                </div>
              </div>

              {m.emotion && (
                <div style={{ alignSelf: 'flex-start' }}>
                  <EmotionChip emotion={m.emotion} size="md"/>
                </div>
              )}

              {m.content && (
                <span style={{ fontFamily: MMF.display, fontSize: 17, fontWeight: 400, lineHeight: 1.6, color: MMC.ink }}>
                  {m.content}
                </span>
              )}

              {m.tagged && m.tagged.length > 0 && (
                <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', paddingTop: 10, borderTop: `1px solid ${MMC.border}` }}>
                  {m.tagged.map(id => {
                    const fam = window.MOMORA_MOCK.byId[id];
                    return (
                      <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <Avatar name={fam.name} size={24} tint={fam.tint}/>
                        <Body size={13} style={{ fontWeight: 600 }}>{fam.name}, {window.ageOf(fam.dob)}</Body>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <CommentsDrawer open={commentsOpen} onClose={() => setCommentsOpen(false)} eng={eng}/>
    </div>
  );
}

// ─── MEDIA GRID TILE ─────────────────────────────────────────────────────────
// Single tile in the new/edit memory grid. Draggable; shows sequence number,
// a remove button, and a video-duration badge when applicable.
function MediaGridTile({ item, seqIdx, onRemove, isDragging, isDropTarget, dragHandlers }) {
  return (
    <div
      draggable
      {...dragHandlers}
      style={{
        position: 'relative',
        aspectRatio: '1 / 1',
        borderRadius: 12,
        overflow: 'hidden',
        opacity: isDragging ? 0.25 : 1,
        outline: isDropTarget ? `2.5px solid ${MMC.primary}` : 'none',
        outlineOffset: 2,
        transform: isDropTarget ? 'scale(1.05)' : 'scale(1)',
        transition: 'opacity 150ms, transform 150ms',
        cursor: 'grab',
        flexShrink: 0,
      }}
    >
      <MediaThumbnail
        kind={item.kind} color={item.color}
        style={{ width: '100%', height: '100%', borderRadius: 0 }}
      />

      {/* Video duration — bottom-left */}
      {item.kind === 'video' && (
        <div style={{
          position: 'absolute', bottom: 5, left: 5,
          background: 'rgba(0,0,0,0.52)', borderRadius: 999,
          padding: '2px 6px', display: 'flex', alignItems: 'center', gap: 3,
          pointerEvents: 'none',
        }}>
          <Icon name="play" size={8} color="#fff" strokeWidth={2.5}/>
          <span style={{ fontFamily: MMF.sans, fontSize: 10, fontWeight: 700, color: '#fff' }}>
            {item.duration || '0:32'}
          </span>
        </div>
      )}

      {/* Sequence number — bottom-right */}
      <div style={{
        position: 'absolute', bottom: 5, right: 5,
        background: 'rgba(0,0,0,0.44)', borderRadius: 999,
        padding: '1px 6px', pointerEvents: 'none',
      }}>
        <span style={{ fontFamily: MMF.sans, fontSize: 10, fontWeight: 700, color: '#fff' }}>
          {seqIdx + 1}
        </span>
      </div>

      {/* Remove button — top-right */}
      <button
        onClick={e => { e.stopPropagation(); onRemove(seqIdx); }}
        style={{
          position: 'absolute', top: 5, right: 5,
          width: 22, height: 22, borderRadius: '50%',
          background: 'rgba(0,0,0,0.52)', border: 'none',
          cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}
      >
        <Icon name="x" size={11} color="#fff" strokeWidth={2.5}/>
      </button>
    </div>
  );
}

// ─── ADD TILE ─────────────────────────────────────────────────────────────────
function AddMediaGridTile({ onClick, disabled }) {
  const [hov, setHov] = React.useState(false);
  const active = hov && !disabled;
  return (
    <button
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        aspectRatio: '1 / 1', borderRadius: 12,
        border: `2px dashed ${active ? MMC.primary : MMC.borderStrong}`,
        background: active ? MMC.primaryTint : MMC.surface,
        cursor: disabled ? 'not-allowed' : 'pointer',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4,
        transition: 'border-color 140ms, background 140ms',
        flexShrink: 0, opacity: disabled ? 0.35 : 1,
      }}
    >
      <Icon name="plus" size={20} color={active ? MMC.primary : MMC.ink3} strokeWidth={2}/>
      <span style={{ fontFamily: MMF.sans, fontSize: 10, fontWeight: 600, color: active ? MMC.primary : MMC.ink3 }}>
        Add
      </span>
    </button>
  );
}

// ─── NEW / EDIT MEMORY — MULTI-MEDIA ─────────────────────────────────────────
const MM_PHOTO_COLORS = ['#ddc9a8','#c9d4b8','#d4bfb0','#c5bfd6','#d4c4b8','#c8d4cc','#e0d0bc','#ccd6e0'];

function NewMemoryMultiMedia({
  onCancel      = () => {},
  onSave        = () => {},
  initialItems  = [],
  initialText   = '',
  initialTagged = ['lila'],
  isEditing     = false,
  pickerOpen    = false,
}) {
  const [text,   setText]   = React.useState(initialText);
  const [tagged, setTagged] = React.useState(initialTagged);
  const [items,  setItems]  = React.useState(initialItems);
  const [draggingIdx, setDraggingIdx] = React.useState(null);
  const [dropIdx,     setDropIdx]     = React.useState(null);
  const MAX = 10;
  const canSave = items.length > 0;

  const removeItem = (i) => setItems(prev => prev.filter((_, j) => j !== i));

  const addFake = (kind) => {
    if (items.length >= MAX) return;
    const color = kind === 'video'
      ? '#b8cdb0'
      : MM_PHOTO_COLORS[items.length % MM_PHOTO_COLORS.length];
    setItems(prev => [...prev, {
      id: `mm_${Date.now()}_${Math.random().toString(36).slice(2)}`,
      kind, color, ...(kind === 'video' ? { duration: '0:18' } : {}),
    }]);
  };

  // HTML5 drag-to-reorder
  const onDragStart = (i) => (e) => {
    setDraggingIdx(i);
    e.dataTransfer.effectAllowed = 'move';
  };
  const onDragOver = (i) => (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (i !== draggingIdx) setDropIdx(i);
  };
  const onDrop = (targetIdx) => (e) => {
    e.preventDefault();
    if (draggingIdx === null || draggingIdx === targetIdx) {
      setDraggingIdx(null); setDropIdx(null); return;
    }
    const next = [...items];
    const [moved] = next.splice(draggingIdx, 1);
    next.splice(targetIdx, 0, moved);
    setItems(next);
    setDraggingIdx(null); setDropIdx(null);
  };
  const onDragEnd = () => { setDraggingIdx(null); setDropIdx(null); };

  return (
    <div style={{ height: '100%', background: MMC.bg, display: 'flex', flexDirection: 'column' }}>

      {/* ── Header ── */}
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <button onClick={onCancel} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          fontFamily: MMF.sans, fontSize: 16, fontWeight: 600, color: MMC.primary, padding: 0,
        }}>Cancel</button>

        {/* type pill */}
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 5,
          background: MMC.surface, border: `1px solid ${MMC.border}`,
          borderRadius: 999, padding: '5px 11px 5px 8px',
        }}>
          <Icon name="layers" size={12} color={MMC.ink2} strokeWidth={2}/>
          <span style={{ fontFamily: MMF.sans, fontSize: 12, fontWeight: 700, color: MMC.ink2 }}>
            Multi-media
          </span>
        </div>

        <button
          onClick={canSave ? onSave : undefined}
          style={{
            background: 'none', border: 'none', cursor: canSave ? 'pointer' : 'default',
            fontFamily: MMF.sans, fontSize: 16, fontWeight: 700,
            color: canSave ? MMC.primary : MMC.ink3, padding: 0,
          }}
        >{isEditing ? 'Update' : 'Save'}</button>
      </div>

      {/* ── Date pill ── */}
      <div style={{ padding: '14px 20px 0' }}>
        <button style={{
          background: '#fff', border: `1px solid ${MMC.border}`, borderRadius: 999,
          padding: '6px 13px', fontFamily: MMF.sans, fontSize: 13, fontWeight: 600,
          color: MMC.ink2, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 7,
        }}>
          <Icon name="calendar" size={13} color={MMC.ink2}/>Today · Sun, May 25
          <Icon name="chevronDown" size={13} color={MMC.ink2}/>
        </button>
      </div>

      {/* ── Text — always grows to fill available space ── */}
      <div style={{ padding: '14px 20px 0', flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <textarea
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="What happened?"
          style={{
            width: '100%', background: 'transparent', border: 'none', outline: 'none',
            fontFamily: MMF.display, fontWeight: 400, fontSize: 24, lineHeight: 1.35,
            color: MMC.ink, resize: 'none', boxSizing: 'border-box',
            flex: 1, minHeight: 80,
          }}
        />
      </div>

      {/* ── Media grid — anchored at bottom, capped height ── */}
      {items.length > 0 && (
        <div style={{ flexShrink: 0, padding: '4px 20px 0' }}>
          {/* section header */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <Eyebrow color={MMC.ink3} style={{ fontSize: 10 }}>Photos &amp; videos</Eyebrow>
            <span style={{
              fontFamily: MMF.sans, fontSize: 12, fontWeight: 700,
              color: items.length >= MAX ? MMC.error : MMC.ink2,
            }}>
              {items.length}/{MAX}
            </span>
          </div>
          {/* tile grid */}
          <div style={{ maxHeight: 224, overflowY: 'auto' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
              {items.map((item, i) => (
                <MediaGridTile
                  key={item.id || i}
                  item={item}
                  seqIdx={i}
                  onRemove={removeItem}
                  isDragging={draggingIdx === i}
                  isDropTarget={dropIdx === i && draggingIdx !== i}
                  dragHandlers={{
                    onDragStart: onDragStart(i),
                    onDragOver:  onDragOver(i),
                    onDrop:      onDrop(i),
                    onDragEnd,
                  }}
                />
              ))}
              {items.length < MAX && (
                <AddMediaGridTile onClick={() => addFake('photo')} disabled={items.length >= MAX}/>
              )}
            </div>
            <div style={{ textAlign: 'center', marginTop: 8, paddingBottom: 4 }}>
              <span style={{ fontFamily: MMF.sans, fontSize: 11, color: MMC.ink3 }}>
                Drag to reorder
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ── Tag strip ── */}
      <WhosInIt tagged={tagged} setTagged={setTagged} max={4} defaultOpen={pickerOpen}/>

      {/* ── Bottom toolbar ── */}
      <div style={{
        padding: '13px 20px 28px', borderTop: `1px solid ${MMC.border}`, marginTop: 12,
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        {/* Mic */}
        <button style={{
          width: 46, height: 46, borderRadius: '50%', flexShrink: 0,
          background: '#fff', border: `1px solid ${MMC.border}`,
          cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="mic" size={20} color={MMC.sea} strokeWidth={2}/>
        </button>
        {/* Add photo */}
        <button
          onClick={() => addFake('photo')}
          style={{
            width: 46, height: 46, borderRadius: '50%', flexShrink: 0,
            background: '#fff', border: `1px solid ${MMC.border}`,
            cursor: items.length < MAX ? 'pointer' : 'default',
            opacity: items.length >= MAX ? 0.35 : 1,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'opacity 140ms',
          }}>
          <Icon name="camera" size={20} color={MMC.ink2} strokeWidth={1.75}/>
        </button>
        {/* Add video */}
        <button
          onClick={() => addFake('video')}
          style={{
            width: 46, height: 46, borderRadius: '50%', flexShrink: 0,
            background: '#fff', border: `1px solid ${MMC.border}`,
            cursor: items.length < MAX ? 'pointer' : 'default',
            opacity: items.length >= MAX ? 0.35 : 1,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'opacity 140ms',
          }}>
          <Icon name="video" size={20} color={MMC.ink2} strokeWidth={1.75}/>
        </button>
      </div>
    </div>
  );
}

// ─── EDIT MEMORY — MULTI-MEDIA ────────────────────────────────────────────────
function EditMemoryMultiMedia({
  m         = window.MOMORA_MOCK.memories.find(x => x.memory_type === 'multi_media') || window.MOMORA_MOCK.memories[0],
  onCancel  = () => {},
  onSave    = () => {},
}) {
  return (
    <NewMemoryMultiMedia
      onCancel={onCancel}
      onSave={onSave}
      initialItems={m.mediaItems || []}
      initialText={m.content || ''}
      initialTagged={m.tagged || ['lila']}
      isEditing={true}
    />
  );
}

Object.assign(window, { MediaCarousel, MemoryDetailMultiMedia, NewMemoryMultiMedia, EditMemoryMultiMedia });
