// Story viewer — the immersive "looking back" player.
// Warm dark mat (never black) + cream prints. One chapter per memory;
// multi-asset memories play as consecutive frames inside one chapter.
const { c: VC, f: VF } = window.MOMORA;
const A = window.MOMORA_ARCHIVE;

const CREAM = '#F6F1E7';
const cream = (o) => `rgba(246,241,231,${o})`;
const MAT = '#1B1610';

const ratioIsTall = (r) => { const [w, h] = String(r || '4/3').split('/').map(Number); return w / h < 0.86; };

function matBg(emotion) {
  const e = window.MOMORA_EMOTIONS[emotion] || window.MOMORA_EMOTIONS.tender;
  return `radial-gradient(118% 60% at 50% 0%, ${e.c}5C 0%, ${e.c}24 40%, transparent 70%),
          radial-gradient(95% 55% at 18% 102%, ${e.c}30 0%, transparent 68%),
          linear-gradient(180deg, #241C14 0%, ${MAT} 52%, #16110B 100%)`;
}

// ── Progress: one segment per memory, hairline ticks for its frames ──────────
function StoryProgress({ pkg, frames, index, frameProgress, dim = false }) {
  const byChapter = pkg.chapters.map((_, ci) => frames.filter(f => f.chapterIdx === ci));
  return (
    <div style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
      {byChapter.map((fs, ci) => {
        const total = fs.reduce((s, f) => s + f.dur, 0);
        return (
          <div key={ci} style={{ flex: total, display: 'flex', gap: fs.length > 1 ? 2 : 0, minWidth: 8 }}>
            {fs.map(f => {
              const fill = index > f.i ? 1 : index === f.i ? frameProgress : 0;
              return (
                <div key={f.i} style={{
                  flex: f.dur, height: 3, borderRadius: 2, overflow: 'hidden',
                  background: cream(dim ? 0.14 : 0.2),
                }}>
                  <div style={{
                    width: `${Math.min(1, fill) * 100}%`, height: '100%', borderRadius: 2,
                    background: cream(index === f.i ? 0.95 : 0.68),
                    transition: 'width 90ms linear',
                  }}/>
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}

// ── Small parts ──────────────────────────────────────────────────────────────
const stopIt = { onPointerDown: (e) => e.stopPropagation(), onPointerUp: (e) => e.stopPropagation() };

function RoundBtn({ icon, onClick, size = 34, tone = 0.14, iconSize = 15, title }) {
  return (
    <button onClick={onClick} title={title} {...stopIt} style={{
      width: size, height: size, borderRadius: '50%', flexShrink: 0,
      background: cream(tone), border: `1px solid ${cream(0.16)}`, cursor: 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0,
    }}>
      <Icon name={icon} size={iconSize} color={CREAM} strokeWidth={2}/>
    </button>
  );
}

function EmotionDot({ emotion }) {
  const e = window.MOMORA_EMOTIONS[emotion];
  if (!e) return null;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
      <span style={{ width: 6, height: 6, borderRadius: 999, background: e.c }}/>
      <span style={{ color: cream(0.66) }}>{emotion}</span>
    </span>
  );
}

// Persistent chapter identity for multi-asset memories
function ChapterMarker({ frame }) {
  if (frame.assetCount < 2) return null;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 9 }}>
      <Icon name="layers" size={12} color={cream(0.55)} strokeWidth={1.9}/>
      <div style={{ display: 'flex', gap: 4 }}>
        {Array.from({ length: frame.assetCount }).map((_, i) => (
          <span key={i} style={{
            width: i === frame.assetIdx ? 13 : 5, height: 5, borderRadius: 999,
            background: cream(i === frame.assetIdx ? 0.9 : 0.28),
            transition: 'width 220ms cubic-bezier(.22,.61,.36,1)',
          }}/>
        ))}
      </div>
      <span style={{ fontFamily: VF.sans, fontSize: 11, fontWeight: 700, color: cream(0.6), letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>
        {frame.assetIdx + 1} of {frame.assetCount}
      </span>
    </div>
  );
}

// ── Media surfaces ───────────────────────────────────────────────────────────
// Fits any aspect inside the frame without cropping or overflowing.
function StoryPhoto({ asset, video = false, elapsed = 0 }) {
  const box = React.useRef(null);
  const [dims, setDims] = React.useState(null);
  React.useLayoutEffect(() => {
    const el = box.current;
    if (!el) return;
    const measure = () => setDims({ w: el.clientWidth, h: el.clientHeight });
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const [rw, rh] = String(asset.ratio || '4/3').split('/').map(Number);
  let fit = { width: '100%' };
  if (dims && dims.w && dims.h) {
    const s = Math.min(dims.w / rw, dims.h / rh);
    fit = { width: Math.round(rw * s), height: Math.round(rh * s) };
  }
  return (
    <div ref={box} style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{
        aspectRatio: asset.ratio, ...fit,
        borderRadius: 20, overflow: 'hidden', position: 'relative', flexShrink: 0,
        background: `linear-gradient(150deg, ${asset.color}f2 0%, ${asset.color}96 100%)`,
        boxShadow: '0 26px 60px rgba(0,0,0,0.45)', border: `1px solid ${cream(0.1)}`,
      }}>
        <div style={{
          position: 'absolute', inset: 0, mixBlendMode: 'multiply',
          background: `radial-gradient(ellipse at 68% 20%, rgba(255,255,255,.42) 0%, transparent 55%),
                       radial-gradient(ellipse at 22% 88%, rgba(110,70,35,.2) 0%, transparent 62%)`,
        }}/>
        {video && (
          <div style={{ position: 'absolute', left: 12, bottom: 12, display: 'flex', alignItems: 'center', gap: 7 }}>
            <div style={{
              background: 'rgba(20,15,10,0.5)', borderRadius: 999, padding: '4px 10px',
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <Icon name="play" size={9} color={CREAM} strokeWidth={2.6} fill={CREAM}/>
              <span style={{ fontFamily: VF.mono, fontSize: 10.5, color: cream(0.9), whiteSpace: 'nowrap' }}>
                0:{String(Math.min(asset.duration, Math.round(elapsed * asset.duration))).padStart(2, '0')} / 0:{String(asset.duration).padStart(2, '0')}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function StoryIllustration({ chapter }) {
  return (
    <div style={{
      background: CREAM, padding: 9, borderRadius: 22, width: '100%',
      boxShadow: '0 26px 60px rgba(0,0,0,0.45)',
    }}>
      <Illustration emotion={chapter.emotion} scene={chapter.scene}
        style={{ width: '100%', aspectRatio: '4/5', borderRadius: 14 }}/>
    </div>
  );
}

// Text memories invert to a cream page, tinted with the memory's emotion —
// same language as the text-only memory detail screen (quote glyph included).
function StoryText({ chapter, long = false }) {
  const emo = window.MOMORA_EMOTIONS[chapter.emotion];
  return (
    <div style={{
      background: emo ? `linear-gradient(165deg, ${emo.soft} 0%, ${CREAM} 52%, ${CREAM} 100%)` : CREAM,
      borderRadius: 24, padding: long ? '38px 24px 30px' : '42px 26px 34px',
      width: '100%', maxHeight: '100%', overflow: 'hidden', position: 'relative',
      boxShadow: '0 26px 60px rgba(0,0,0,0.45)',
      display: 'flex', flexDirection: 'column', justifyContent: long ? 'flex-start' : 'center',
    }}>
      {/* decorative opening quote — as on the memory-detail text layout */}
      <div style={{
        position: 'absolute', top: long ? 10 : 14, left: 15,
        fontFamily: VF.display, fontSize: 88, fontWeight: 400, lineHeight: 1,
        color: emo ? emo.ink : VC.ink3, opacity: 0.14,
        userSelect: 'none', pointerEvents: 'none',
      }}>“</div>
      {long ? (
        <>
          <div style={{ fontFamily: VF.display, fontWeight: 400, fontSize: 18.5, lineHeight: 1.62, letterSpacing: '-0.004em', color: VC.ink, textWrap: 'pretty', position: 'relative' }}>
            {chapter.content}
          </div>
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 58, background: `linear-gradient(180deg, rgba(246,241,231,0) 0%, ${CREAM} 78%)`, pointerEvents: 'none' }}/>
        </>
      ) : (
        <div style={{ fontFamily: VF.display, fontWeight: 400, fontSize: 27, lineHeight: 1.34, letterSpacing: '-0.012em', color: VC.ink, textWrap: 'pretty', position: 'relative' }}>
          {chapter.content}
        </div>
      )}
    </div>
  );
}

function MediaLoading() {
  return (
    <div style={{
      width: '100%', aspectRatio: '4/3', borderRadius: 20, background: cream(0.07),
      border: `1px solid ${cream(0.1)}`, display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', gap: 12, animation: 'ptpulse 1600ms ease-in-out infinite',
    }}>
      <div style={{ width: 22, height: 22, borderRadius: '50%', border: `2px solid ${cream(0.22)}`, borderTopColor: cream(0.8), animation: 'ptspin 900ms linear infinite' }}/>
      <div style={{ fontFamily: VF.sans, fontSize: 12.5, fontWeight: 600, color: cream(0.6) }}>Loading this photo…</div>
    </div>
  );
}

function MediaUnavailable() {
  return (
    <div style={{
      width: '100%', aspectRatio: '4/3', borderRadius: 20, background: cream(0.05),
      border: `1px dashed ${cream(0.24)}`, display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', gap: 10, padding: '0 30px', textAlign: 'center',
    }}>
      <Icon name="image" size={22} color={cream(0.5)} strokeWidth={1.6}/>
      <div style={{ fontFamily: VF.display, fontSize: 18, color: cream(0.9), lineHeight: 1.3 }}>
        This photo isn’t on this device right now.
      </div>
      <div style={{ fontFamily: VF.sans, fontSize: 12.5, color: cream(0.55), lineHeight: 1.5 }}>
        It may still be syncing. The memory and its words are safe.
      </div>
    </div>
  );
}

// ── Bottom block: date · emotion · caption · who · open ──────────────────────
function StoryFoot({ frame, expanded, onOpenDetail }) {
  const ch = frame.chapter;
  return (
    <div style={{ padding: '0 22px 30px', position: 'relative', zIndex: 4 }}>
      <ChapterMarker frame={frame}/>
      <div style={{ fontFamily: VF.sans, fontSize: 11.5, fontWeight: 700, letterSpacing: '0.05em', color: cream(0.58), display: 'flex', alignItems: 'center', gap: 9, flexWrap: 'wrap' }}>
        <span>{A.fmtFrameDate(ch.date)}</span>
        {ch.emotion && <span style={{ color: cream(0.28) }}>·</span>}
        {ch.emotion && <EmotionDot emotion={ch.emotion}/>}
      </div>
      {ch.content && frame.kind !== 'text_short' && frame.kind !== 'text_long' && (
        <div style={{
          marginTop: 9, fontFamily: VF.display, fontWeight: 400, fontSize: 19.5, lineHeight: 1.42,
          letterSpacing: '-0.008em', color: cream(0.95), textWrap: 'pretty',
          ...(expanded ? {} : { display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }),
        }}>{ch.content}</div>
      )}
      <div style={{ marginTop: 15, display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex' }}>
            {ch.tagged.map((id, i) => {
              const p = window.MOMORA_MOCK.byId[id];
              return <div key={id} style={{ marginLeft: i ? -8 : 0, borderRadius: '50%', boxShadow: `0 0 0 2px ${MAT}` }}>
                <Avatar name={p.name} size={24} tint={p.tint}/>
              </div>;
            })}
          </div>
          {/* one tagged person → name (plus age if they're a child); more than one → faces only */}
          {ch.tagged.length === 1 && (() => {
            const p = window.MOMORA_MOCK.byId[ch.tagged[0]];
            const showAge = p.role === 'child' && new Date(p.dob) <= new Date(ch.date);
            return (
              <div style={{ fontFamily: VF.sans, fontSize: 11.5, fontWeight: 600, color: cream(0.6), whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {showAge ? `${p.name}, ${window.ageAt(p.dob, ch.date)}` : p.name}
              </div>
            );
          })()}
        </div>
        <button onClick={onOpenDetail} {...stopIt} style={{
          flexShrink: 0, background: 'transparent', border: `1px solid ${cream(0.28)}`,
          borderRadius: 999, padding: '7px 13px', cursor: 'pointer',
          display: 'inline-flex', alignItems: 'center', gap: 6,
          fontFamily: VF.sans, fontSize: 12, fontWeight: 700, color: cream(0.92),
        }}>
          Open memory
          <Icon name="arrowRight" size={12} color={cream(0.92)} strokeWidth={2.2}/>
        </button>
      </div>
    </div>
  );
}

// ── Intro + completion cards ─────────────────────────────────────────────────
function PkgMiniStack({ pkg, size = 62 }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', gap: -6 }}>
      {[-6, 0, 6].map((rot, i) => (
        <div key={i} style={{
          width: size, height: size, borderRadius: 10, marginLeft: i ? -14 : 0,
          transform: `rotate(${rot}deg)`, background: CREAM, padding: 4,
          boxShadow: '0 12px 26px rgba(0,0,0,0.4)',
        }}>
          {i === 1
            ? <PkgCoverArt pkg={pkg} radius={7} style={{ width: '100%', height: '100%' }}/>
            : <div style={{ width: '100%', height: '100%', borderRadius: 7, background: `linear-gradient(145deg, ${pkg.layers[i === 0 ? 0 : 1]} 0%, ${pkg.layers[i === 0 ? 0 : 1]}88 100%)` }}/>}
        </div>
      ))}
    </div>
  );
}

function StoryIntro({ pkg }) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 34px', gap: 22, animation: 'ptfade 380ms cubic-bezier(.22,.61,.36,1)' }}>
      <PkgMiniStack pkg={pkg}/>
      <div style={{ textAlign: 'center' }}>
        <Eyebrow color={cream(0.5)} style={{ fontSize: 10.5 }}>{pkg.kind}</Eyebrow>
        <div style={{ marginTop: 12, fontFamily: VF.display, fontWeight: 400, fontSize: 36, lineHeight: 1.08, letterSpacing: '-0.02em', color: CREAM, textWrap: 'balance' }}>
          {pkg.title}
        </div>
        <div style={{ marginTop: 13, fontFamily: VF.sans, fontSize: 13, fontWeight: 600, color: cream(0.55) }}>
          {pkg.chapters.length} memories · {pkg.sub}
        </div>
      </div>
      <div style={{ marginTop: 6, fontFamily: VF.sans, fontSize: 11.5, color: cream(0.58), letterSpacing: '0.04em' }}>
        Tap to move · hold to pause
      </div>
    </div>
  );
}

function StoryComplete({ pkg, onReplay, onClose }) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 32px', gap: 20, animation: 'ptfade 380ms cubic-bezier(.22,.61,.36,1)' }}>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        {pkg.chapters.slice(0, 4).map((ch, i) => (
          <div key={ch.id} style={{
            width: 52, height: 52, borderRadius: 9, marginLeft: i ? -12 : 0, background: CREAM, padding: 3,
            transform: `rotate(${(i - 1.5) * 4}deg)`, boxShadow: '0 10px 22px rgba(0,0,0,0.38)',
          }}>
            {ch.type === 'text_illustration' || ch.type === 'text_only'
              ? <Illustration emotion={ch.emotion || 'calm'} scene={ch.scene || 'window'} style={{ width: '100%', height: '100%', borderRadius: 6 }}/>
              : <div style={{ width: '100%', height: '100%', borderRadius: 6, background: `linear-gradient(145deg, ${ch.assets[0].color} 0%, ${ch.assets[0].color}88 100%)` }}/>}
          </div>
        ))}
      </div>
      <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', gap: 13 }}>
        <div style={{ fontFamily: VF.display, fontWeight: 400, fontSize: 28, lineHeight: 1.16, letterSpacing: '-0.018em', color: CREAM, textWrap: 'balance' }}>
          That was {pkg.chapters.length} from {pkg.era.toLowerCase()}.
        </div>
        <div style={{ fontFamily: VF.sans, fontSize: 13, lineHeight: 1.55, color: cream(0.55) }}>
          Every one of them is still in your timeline.
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, width: '100%', maxWidth: 260, marginTop: 4 }}>
        <button onClick={onClose} {...stopIt} style={{
          background: CREAM, color: '#2C2418', border: 'none', borderRadius: 999,
          padding: '14px 20px', fontFamily: VF.sans, fontSize: 14.5, fontWeight: 700, cursor: 'pointer',
        }}>Back to your timeline</button>
        <button onClick={onReplay} {...stopIt} style={{
          background: 'transparent', color: cream(0.75), border: 'none', borderRadius: 999,
          padding: '10px 20px', fontFamily: VF.sans, fontSize: 13.5, fontWeight: 700, cursor: 'pointer',
        }}>Play it again</button>
      </div>
    </div>
  );
}

// ── The viewer ───────────────────────────────────────────────────────────────
function StoryViewer({
  pkgId = 'p-onthisday',
  stage = 'frame',            // intro | frame | complete
  startChapter = 0, startAsset = 0,
  frameState = 'playing',     // playing | paused | loading | unavailable
  seed = 0.42,                // static progress fill when not autoplaying
  autoplay = false,
  onClose = () => {}, onOpenDetail = null,
  resumeAt = null,            // {chapterIdx, assetIdx, progress} — restores position
}) {
  const pkg = window.pkgById(pkgId);
  const frames = React.useMemo(() => A.framesOf(pkg), [pkgId]);
  const findIdx = (c, a) => Math.max(0, frames.findIndex(f => f.chapterIdx === c && f.assetIdx === a));

  const [phase, setPhase] = React.useState(stage);
  const [index, setIndex] = React.useState(() => resumeAt ? findIdx(resumeAt.chapterIdx, resumeAt.assetIdx) : findIdx(startChapter, startAsset));
  const [prog, setProg] = React.useState(() => (resumeAt ? resumeAt.progress : autoplay ? 0 : seed));
  const [held, setHeld] = React.useState(false);
  const heldRef = React.useRef(false);
  const [hidden, setHidden] = React.useState(false);
  const [muted, setMuted] = React.useState(true);
  const rootRef = React.useRef(null);
  const holdT = React.useRef(null);

  const frame = frames[Math.min(index, frames.length - 1)];
  const blocked = frameState === 'loading';
  const paused = held || hidden || frameState === 'paused' || blocked;

  // App backgrounded → pause
  React.useEffect(() => {
    const h = () => setHidden(document.visibilityState === 'hidden');
    document.addEventListener('visibilitychange', h);
    return () => document.removeEventListener('visibilitychange', h);
  }, []);

  // Automatic advancement
  React.useEffect(() => {
    if (!autoplay || paused) return;
    if (phase === 'complete') return;
    const step = 60;
    const dur = phase === 'intro' ? A.DUR.intro : frame.dur;
    const t = setInterval(() => {
      setProg(p => {
        const n = p + step / dur;
        if (n >= 1) {
          if (phase === 'intro') { setPhase('frame'); return 0; }
          if (index >= frames.length - 1) { setPhase('complete'); return 1; }
          setIndex(i => i + 1);
          return 0;
        }
        return n;
      });
    }, step);
    return () => clearInterval(t);
  }, [autoplay, paused, phase, index, frame && frame.dur]);

  const go = (d) => {
    if (phase === 'intro') { setPhase('frame'); setProg(0); return; }
    if (phase === 'complete') { if (d < 0) { setPhase('frame'); setIndex(frames.length - 1); setProg(0); } return; }
    const n = index + d;
    if (n < 0) { setProg(0); return; }
    if (n > frames.length - 1) { setPhase('complete'); return; }
    setIndex(n); setProg(0);
  };

  const releaseHold = () => {
    clearTimeout(holdT.current);
    if (heldRef.current) { heldRef.current = false; setHeld(false); return true; }
    return false;
  };
  const down = (e) => {
    if (!autoplay) return;
    holdT.current = setTimeout(() => { heldRef.current = true; setHeld(true); }, 220);
  };
  const up = (e) => {
    const wasHeld = releaseHold();
    if (!autoplay || wasHeld) return;
    const r = rootRef.current.getBoundingClientRect();
    go(e.clientX - r.left < r.width * 0.32 ? -1 : 1);
  };

  React.useEffect(() => {
    if (!autoplay) return;
    const k = (e) => {
      if (e.key === 'ArrowRight') go(1);
      else if (e.key === 'ArrowLeft') go(-1);
      else if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [autoplay, index, phase]);

  const ch = frame.chapter;
  const glowEmotion = phase === 'intro' || phase === 'complete' ? pkg.tint : (ch.emotion || pkg.tint);
  const isTextFrame = frame.kind === 'text_short' || frame.kind === 'text_long';

  const media = () => {
    if (frameState === 'unavailable' && frame.kind !== 'illustration' && !isTextFrame) return <MediaUnavailable/>;
    if (blocked && frame.kind !== 'illustration' && !isTextFrame) return <MediaLoading/>;
    if (frame.kind === 'illustration') return <StoryIllustration chapter={ch}/>;
    if (isTextFrame) return <StoryText chapter={ch} long={frame.kind === 'text_long'}/>;
    return <StoryPhoto asset={frame.asset} video={frame.kind === 'video'} elapsed={prog}/>;
  };

  return (
    <div ref={rootRef}
      onPointerDown={down} onPointerUp={up} onPointerLeave={releaseHold} onPointerCancel={releaseHold}
      style={{
        height: '100%', position: 'relative', overflow: 'hidden',
        background: matBg(glowEmotion), userSelect: 'none',
        transition: 'background 380ms cubic-bezier(.22,.61,.36,1)',
        display: 'flex', flexDirection: 'column',
      }}>

      {/* top chrome */}
      <div style={{ padding: '52px 18px 0', flexShrink: 0, position: 'relative', zIndex: 5 }}>
        <StoryProgress pkg={pkg} frames={frames} index={phase === 'complete' ? frames.length : index}
          frameProgress={phase === 'intro' ? 0 : prog} dim={phase === 'intro'}/>
        <div style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <Eyebrow color={cream(0.62)} style={{ fontSize: 9.5 }}>{pkg.kind}</Eyebrow>
            <div style={{ marginTop: 3, fontFamily: VF.display, fontWeight: 500, fontSize: 15.5, letterSpacing: '-0.01em', color: cream(0.94), whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {pkg.title}
            </div>
          </div>
          {frame.kind === 'video' && phase === 'frame' && (
            <RoundBtn icon={muted ? 'volumeOff' : 'volume'} iconSize={15} onClick={() => setMuted(m => !m)} title={muted ? 'Unmute' : 'Mute'}/>
          )}
          <RoundBtn icon="x" onClick={onClose} title="Close"/>
        </div>
      </div>

      {/* body */}
      {phase === 'intro' ? <StoryIntro pkg={pkg}/>
        : phase === 'complete' ? <StoryComplete pkg={pkg} onClose={onClose} onReplay={() => { setPhase('frame'); setIndex(0); setProg(0); }}/>
        : (
          <>
            <div style={{
              flex: 1, minHeight: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
              padding: isTextFrame ? '18px 20px 14px' : '20px 20px 16px', position: 'relative', zIndex: 2,
            }}>
              <div key={frame.i} style={{
                width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                animation: 'ptfade 300ms cubic-bezier(.22,.61,.36,1)',
              }}>
                {media()}
              </div>
            </div>
            <StoryFoot frame={frame} expanded={paused} onOpenDetail={() => onOpenDetail && onOpenDetail(ch, { chapterIdx: frame.chapterIdx, assetIdx: frame.assetIdx, progress: prog })}/>
          </>
        )}

      {/* paused veil + label */}
      {phase === 'frame' && (held || frameState === 'paused') && (
        <>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(18,13,8,0.34)', zIndex: 3, pointerEvents: 'none' }}/>
          <div style={{
            position: 'absolute', left: 0, right: 0, top: 116, display: 'flex', justifyContent: 'center', zIndex: 6, pointerEvents: 'none',
          }}>
            <div style={{
              background: cream(0.14), border: `1px solid ${cream(0.2)}`, borderRadius: 999,
              padding: '6px 14px 6px 11px', display: 'flex', alignItems: 'center', gap: 7,
              backdropFilter: 'blur(6px)',
            }}>
              <Icon name="pause" size={11} color={CREAM} strokeWidth={2} fill={CREAM}/>
              <span style={{ fontFamily: VF.sans, fontSize: 11.5, fontWeight: 700, letterSpacing: '0.05em', color: cream(0.9) }}>Paused</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

Object.assign(window, {
  StoryViewer, StoryProgress, StoryIntro, StoryComplete, PkgMiniStack,
  StoryPhoto, StoryIllustration, StoryText, MediaLoading, MediaUnavailable,
});
