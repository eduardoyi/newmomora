// Timeline screens — filled + empty + variations
const { c: TC, f: TF, s: TS, r: TR } = window.MOMORA;

// ─────────────────── Streak strip ───────────────────
function StreakStrip({ days = window.MOMORA_MOCK.recentDays, style = {} }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, ...style }}>
      <div style={{ fontFamily: TF.sans, fontSize: 11, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: TC.ink3 }}>
        This week
      </div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        {days.map((d, i) => (
          <div key={i} style={{ position: 'relative', width: 10, height: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{
              width: 8, height: 8, borderRadius: 999,
              background: d.has ? TC.primary : TC.border,
              boxShadow: d.today ? `0 0 0 3px ${TC.primaryTint}` : 'none',
              transition: 'all 220ms',
            }}/>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────── Tab bar ───────────────────
function TabBar({ active = 'timeline', onTab = () => {}, style = {} }) {
  const tabs = [
    { id: 'timeline', label: 'Timeline', icon: 'book' },
    { id: 'calendar', label: 'Calendar', icon: 'calendar' },
    { id: 'family',   label: 'Family',   icon: 'users' },
    { id: 'settings', label: 'Settings', icon: 'settings' },
  ];
  return (
    <div style={{
      position: 'absolute', left: 16, right: 16, bottom: 28,
      background: 'rgba(255,255,255,0.85)', backdropFilter: 'blur(20px) saturate(180%)', WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      border: `1px solid ${TC.border}`, borderRadius: 999, padding: '8px 10px',
      display: 'flex', justifyContent: 'space-around', alignItems: 'center',
      boxShadow: '0 12px 28px rgba(40,30,20,0.08), 0 1px 0 rgba(0,0,0,0.03)',
      zIndex: 30, ...style,
    }}>
      {tabs.map(t => {
        const isActive = active === t.id;
        return (
          <button key={t.id} onClick={() => onTab(t.id)} style={{
            border: 'none', background: isActive ? TC.primary : 'transparent',
            color: isActive ? '#fff' : TC.ink2,
            borderRadius: 999, padding: isActive ? '8px 14px' : 8,
            display: 'inline-flex', alignItems: 'center', gap: 6, cursor: 'pointer',
            fontFamily: TF.sans, fontSize: 13, fontWeight: 700,
            transition: 'all 220ms cubic-bezier(.22,.61,.36,1)',
          }}>
            <Icon name={t.icon} size={18} strokeWidth={isActive ? 2 : 1.75}/>
            {isActive && <span>{t.label}</span>}
          </button>
        );
      })}
    </div>
  );
}

// ─────────────────── FAB ───────────────────
function ComposeFab({ onClick = () => {}, style = {} }) {
  return (
    <button onClick={onClick} style={{
      position: 'absolute', right: 26, bottom: 100, zIndex: 25,
      width: 60, height: 60, borderRadius: '50%', border: 'none',
      background: TC.primary, color: '#fff', cursor: 'pointer',
      boxShadow: '0 12px 28px rgba(214,62,120,0.36), 0 1px 0 rgba(255,255,255,0.4) inset',
      display: 'flex', alignItems: 'center', justifyContent: 'center', ...style,
    }}>
      <Icon name="plus" size={26} strokeWidth={2.2}/>
    </button>
  );
}

// ─────────────────── Shared card footer ───────────────────
// Unified row: dayLabel · avatar cluster · emotion chip
function MemoryCardFooter({ m }) {
  return (
    <div style={{ padding: '9px 16px 13px', display: 'flex', alignItems: 'center', gap: 8 }}>
      <Eyebrow color={TC.ink3} style={{ fontSize: 10, flexShrink: 0 }}>{m.dayLabel}</Eyebrow>
      {/* avatar cluster */}
      <div style={{ display: 'flex', marginLeft: 2 }}>
        {m.tagged.map((id, i) => {
          const mm = window.MOMORA_MOCK.byId[id];
          return (
            <div key={id} style={{ marginLeft: i ? -7 : 0 }}>
              <Avatar name={mm.name} size={22} tint={mm.tint}/>
            </div>
          );
        })}
      </div>
      {/* spacer */}
      <div style={{ flex: 1 }}/>
      {/* emotion OR media type badge */}
      {m.emotion ? (
        <EmotionChip emotion={m.emotion} size="sm"/>
      ) : m.memory_type === 'multi_media' ? (
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, background: TC.surface, border: `1px solid ${TC.border}`, borderRadius: 999, padding: '3px 9px 3px 7px' }}>
          <Icon name="layers" size={11} color={TC.ink3} strokeWidth={1.75}/>
          <span style={{ fontFamily: TF.sans, fontSize: 11, fontWeight: 600, color: TC.ink3 }}>
            {(m.mediaItems || []).length} items
          </span>
        </div>
      ) : m.memory_type === 'media' ? (
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, background: TC.surface, border: `1px solid ${TC.border}`, borderRadius: 999, padding: '3px 9px 3px 7px' }}>
          <Icon name={m.mediaKind === 'video' ? 'video' : 'camera'} size={11} color={TC.ink3} strokeWidth={2}/>
          <span style={{ fontFamily: TF.sans, fontSize: 11, fontWeight: 600, color: TC.ink3 }}>
            {m.mediaKind === 'video' ? 'Video' : 'Photo'}
          </span>
        </div>
      ) : null}
    </div>
  );
}

// ─────────────────── Card A — Spread (text_illustration + media + multi_media) ────
// Visual on top, caption below (if any), unified footer.
function MemoryCardSpread({ m, onClick, onComment = () => {} }) {
  const eng = useEngagement(m);
  const isMedia      = m.memory_type === 'media';
  const isMultiMedia = m.memory_type === 'multi_media';
  const hasCaption   = m.content && m.content.trim().length > 0;
  const mediaItems   = m.mediaItems || [];
  const firstItem    = isMultiMedia ? mediaItems[0] : null;

  return (
    <Paper onClick={onClick} pad={0} style={{ overflow: 'hidden' }}>
      {/* Visual */}
      <div style={{ position: 'relative' }}>
        {isMultiMedia ? (
          <MediaThumbnail kind={firstItem.kind} color={firstItem.color}
            style={{ width: '100%', aspectRatio: '4/3', borderRadius: 0 }}/>
        ) : isMedia ? (
          <MediaThumbnail kind={m.mediaKind} color={m.mediaColor}
            style={{ width: '100%', aspectRatio: '4/3', borderRadius: 0 }}/>
        ) : (
          <Illustration emotion={m.emotion} scene={m.scene}
            style={{ width: '100%', aspectRatio: '4/3', borderRadius: 0 }}/>
        )}
        {/* tagged members — top left */}
        <div style={{
          position: 'absolute', top: 10, left: 10,
          background: 'rgba(255,255,255,0.88)', borderRadius: 999,
          padding: '4px 8px 4px 4px', display: 'inline-flex', alignItems: 'center', gap: 4,
        }}>
          {m.tagged.map(id => {
            const mm = window.MOMORA_MOCK.byId[id];
            return <Avatar key={id} name={mm.name} size={18} tint={mm.tint}/>;
          })}
        </div>
        {/* multi-media counter badge — top right */}
        {isMultiMedia && mediaItems.length > 1 && (
          <div style={{
            position: 'absolute', top: 10, right: 10,
            background: 'rgba(0,0,0,0.5)', borderRadius: 999,
            padding: '3px 9px', pointerEvents: 'none',
          }}>
            <span style={{ fontFamily: TF.sans, fontSize: 11, fontWeight: 700, color: '#fff' }}>
              1/{mediaItems.length}
            </span>
          </div>
        )}
        {/* video duration — bottom right (single-media only) */}
        {isMedia && m.mediaKind === 'video' && (
          <div style={{
            position: 'absolute', bottom: 8, right: 10,
            background: 'rgba(0,0,0,0.45)', borderRadius: 999,
            padding: '3px 8px', display: 'flex', alignItems: 'center', gap: 4,
          }}>
            <Icon name="play" size={9} color="#fff" strokeWidth={2.5}/>
            <span style={{ fontFamily: TF.sans, fontSize: 11, fontWeight: 600, color: '#fff' }}>0:32</span>
          </div>
        )}
      </div>

      {/* Engagement — like + comment (Instagram-style, under the visual) */}
      <div style={{ padding: '11px 16px 0' }}>
        <EngagementBar eng={eng} onOpenComments={onComment} iconSize={23}/>
      </div>

      {/* Pagination dots — only for multi_media, signals there's more to swipe */}
      {isMultiMedia && mediaItems.length > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 5, padding: '8px 0 2px' }}>
          {mediaItems.map((_, i) => (
            <div key={i} style={{
              width: i === 0 ? 7 : 4.5, height: i === 0 ? 7 : 4.5,
              borderRadius: '50%',
              background: i === 0 ? TC.primary : TC.border,
              flexShrink: 0,
            }}/>
          ))}
        </div>
      )}

      {/* Caption — only shown if content exists */}
      {hasCaption && (
        <div style={{ padding: '13px 16px 2px' }}>
          <Body size={14.5} style={{
            lineHeight: 1.55, color: TC.ink,
            display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden',
          }}>{m.content}</Body>
        </div>
      )}

      <MemoryCardFooter m={m}/>
    </Paper>
  );
}

// ─────────────────── Card B — Quote (text_only) ───────────────────
// Full-width italic serif text, same unified footer.
function MemoryCardQuote({ m, onClick, onComment = () => {} }) {
  const eng     = useEngagement(m);
  const emo     = m.emotion ? window.MOMORA_EMOTIONS[m.emotion] : null;
  const excerpt = m.content && m.content.length > 110
    ? m.content.slice(0, 110) + '…'
    : m.content || '';

  return (
    <Paper onClick={onClick} pad={0} style={{ overflow: 'hidden' }}>
      {/* Optional emotion accent — hairline left border */}
      {emo && (
        <div style={{ height: 3, background: emo.soft, borderRadius: '16px 16px 0 0' }}/>
      )}
      <div style={{ padding: '18px 18px 4px' }}>
        <Display size={23} italic style={{ lineHeight: 1.25, color: TC.ink }}>
          {excerpt}
        </Display>
      </div>
      <div style={{ padding: '13px 18px 0' }}>
        <EngagementBar eng={eng} onOpenComments={onComment} iconSize={23}/>
      </div>
      <MemoryCardFooter m={m}/>
    </Paper>
  );
}

// ─────────────────── Timeline header (shared) ───────────────────
function TimelineHeader({ subtitle = 'Sunday · May 25' }) {
  return (
    <div style={{ padding: '60px 24px 0' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Eyebrow color={TC.ink3}>{subtitle}</Eyebrow>
        <button style={{
          width: 38, height: 38, borderRadius: '50%', background: '#fff', border: `1px solid ${TC.border}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}>
          <Icon name="search" size={18} color={TC.ink2}/>
        </button>
      </div>
      <Display size={36} style={{ marginTop: 12 }}>Your<br/>moments.</Display>
      <StreakStrip style={{ marginTop: 18 }}/>
    </div>
  );
}

// ─────────────────── TIMELINE A — Auto-typed mixed feed ───────────────────
// text_illustration + media → MemoryCardSpread
// text_only → MemoryCardQuote
function TimelineA({ onOpen = () => {}, onCompose = () => {}, onTab = () => {}, onComment = () => {} }) {
  const m = window.MOMORA_MOCK.memories;
  return (
    <div style={{ height: '100%', background: TC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 130 }}>
        <TimelineHeader/>
        <div style={{ padding: '24px 20px 8px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {m.map(mm =>
            mm.memory_type === 'text_only'
              ? <MemoryCardQuote  key={mm.id} m={mm} onClick={() => onOpen(mm)} onComment={() => onComment(mm)}/>
              : <MemoryCardSpread key={mm.id} m={mm} onClick={() => onOpen(mm)} onComment={() => onComment(mm)}/>
          )}
        </div>
      </div>
      <ComposeFab onClick={onCompose}/>
      <TabBar active="timeline" onTab={onTab}/>
    </div>
  );
}

// ─────────────────── TIMELINE B — All spreads ───────────────────
function TimelineB({ onOpen = () => {}, onCompose = () => {}, onTab = () => {}, onComment = () => {} }) {
  const m = window.MOMORA_MOCK.memories;
  return (
    <div style={{ height: '100%', background: TC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 130 }}>
        <TimelineHeader/>
        <div style={{ padding: '24px 20px 8px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {m.map(mm => <MemoryCardSpread key={mm.id} m={mm} onClick={() => onOpen(mm)} onComment={() => onComment(mm)}/>)}
        </div>
      </div>
      <ComposeFab onClick={onCompose}/>
      <TabBar active="timeline" onTab={onTab}/>
    </div>
  );
}

// ─────────────────── TIMELINE C — All quotes ───────────────────
function TimelineC({ onOpen = () => {}, onCompose = () => {}, onTab = () => {}, onComment = () => {} }) {
  const m = window.MOMORA_MOCK.memories;
  return (
    <div style={{ height: '100%', background: TC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 130 }}>
        <TimelineHeader/>
        <div style={{ padding: '24px 20px 8px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {m.map(mm => <MemoryCardQuote key={mm.id} m={mm} onClick={() => onOpen(mm)} onComment={() => onComment(mm)}/>)}
        </div>
      </div>
      <ComposeFab onClick={onCompose}/>
      <TabBar active="timeline" onTab={onTab}/>
    </div>
  );
}

// ─────────────────── EMPTY STATES ───────────────────
function TimelineEmptyA({ onCompose = () => {}, onTab = () => {} }) {
  return (
    <div style={{ height: '100%', background: TC.bg, position: 'relative', display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '60px 24px 0' }}>
        <Eyebrow color={TC.ink3}>Sunday · May 25</Eyebrow>
        <Display size={36} style={{ marginTop: 12 }}>Your<br/>moments.</Display>
      </div>
      <div style={{ flex: 1, padding: '0 32px', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', textAlign: 'center', gap: 18 }}>
        <div style={{
          width: '100%', aspectRatio: '4/3', background: '#fff',
          border: `1px solid ${TC.border}`, borderRadius: 24,
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8,
          boxShadow: '0 24px 48px rgba(40,30,20,0.06)', position: 'relative', overflow: 'hidden',
        }}>
          {[1,2,3,4,5,6].map(i => (
            <div key={i} style={{ position: 'absolute', left: 24, right: 24, top: 24 + i * 28, height: 1, background: TC.border, opacity: 0.5 }}/>
          ))}
          <Script size={32} color={TC.primary} style={{ transform: 'rotate(-3deg)' }}>nothing yet</Script>
          <Body size={13} muted style={{ position: 'relative' }}>but today is still happening.</Body>
        </div>
        <Body size={14.5} muted style={{ maxWidth: 280 }}>
          Capture your first moment when you are ready — type, or just speak it.
        </Body>
        <Button onClick={onCompose} icon={<Icon name="plus" size={18} strokeWidth={2.2}/>}>
          Capture a moment
        </Button>
      </div>
      <TabBar active="timeline" onTab={onTab} style={{ position: 'absolute', left: 16, right: 16, bottom: 28 }}/>
    </div>
  );
}

function TimelineEmptyB({ onCompose = () => {}, onTab = () => {} }) {
  const example = { ...window.MOMORA_MOCK.memories[0], dayLabel: 'Example' };
  return (
    <div style={{ height: '100%', background: TC.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 130 }}>
        <div style={{ padding: '60px 24px 0' }}>
          <Eyebrow color={TC.ink3}>Sunday · May 25</Eyebrow>
          <Display size={36} style={{ marginTop: 12 }}>Welcome,<br/><em style={{ fontStyle: 'italic', color: TC.primary }}>Sam.</em></Display>
          <Body muted size={14.5} style={{ marginTop: 14, lineHeight: 1.55 }}>
            Every moment you save becomes a card like the one below. Tap the + to add yours.
          </Body>
        </div>
        <div style={{ padding: '24px 20px 8px', position: 'relative' }}>
          <div style={{ position: 'relative' }}>
            <MemoryCardSpread m={example}/>
            <div style={{
              position: 'absolute', top: -10, right: 4,
              background: TC.sun, color: TC.ink, fontFamily: TF.sans, fontWeight: 700, fontSize: 11,
              padding: '4px 10px', borderRadius: 999, letterSpacing: '0.08em', textTransform: 'uppercase',
              boxShadow: '0 6px 14px rgba(242,180,65,0.4)', transform: 'rotate(2deg)',
            }}>example</div>
          </div>
        </div>
      </div>
      <ComposeFab onClick={onCompose}/>
      <TabBar active="timeline" onTab={onTab}/>
    </div>
  );
}

// Alias — picks card type automatically
function MemoryCardPostcard({ m, onClick, onComment }) {
  return m.memory_type === 'text_only'
    ? <MemoryCardQuote m={m} onClick={onClick} onComment={onComment}/>
    : <MemoryCardSpread m={m} onClick={onClick} onComment={onComment}/>;
}

Object.assign(window, {
  StreakStrip, TabBar, ComposeFab, MemoryCardFooter,
  MemoryCardSpread, MemoryCardQuote, MemoryCardPostcard,
  TimelineA, TimelineB, TimelineC, TimelineEmptyA, TimelineEmptyB,
});
