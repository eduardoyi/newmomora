// New memory + memory detail screens — all 3 memory types
const { c: NC, f: NF, s: NS, r: NR } = window.MOMORA;

// ─── Shared icon button style ───────────────────────────────────────────────
const iconBtn = {
  width: 38, height: 38, borderRadius: '50%', background: '#fff',
  border: `1px solid ${window.MOMORA.c.border}`,
  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
};

// ─── NEW MEMORY A — emergent type form ──────────────────────────────────────
// Type is derived from user action — no upfront selector.
//   · No media + AI toggle on  → text_illustration
//   · No media + AI toggle off → text_only
//   · Photo or video attached  → media (AI toggle hidden)
function NewMemoryA({
  onCancel = () => {},
  onSave   = () => {},
  initial  = '',
  initialIllustration = true,
  initialMedia = null,
  initialTagged = ['lila'],
  pickerOpen = false,
}) {
  const family = window.MOMORA_MOCK.family;
  const [text, setText]   = React.useState(initial);
  const [tagged, setTagged] = React.useState(initialTagged);
  const [illustrationEnabled, setIllustrationEnabled] = React.useState(initialIllustration);
  const [media, setMedia] = React.useState(initialMedia);
  const [showPicker, setShowPicker] = React.useState(false);

  const wordCount = text.trim().split(/\s+/).filter(Boolean).length;
  const canSave   = media !== null || text.trim().length > 0;

  // Derived type
  const memType = media
    ? 'media'
    : illustrationEnabled ? 'text_illustration' : 'text_only';

  const typeConfigs = {
    text_illustration: { label: 'Illustrated', icon: 'sparkle', color: NC.primary,   bg: NC.primaryTint, border: NC.primary + '50' },
    text_only:         { label: 'Text only',   icon: 'type',    color: NC.ink2,       bg: NC.surface,     border: NC.border },
    media_photo:       { label: 'Photo',        icon: 'camera',  color: NC.ink2,       bg: NC.surface,     border: NC.border },
    media_video:       { label: 'Video',        icon: 'video',   color: NC.ink2,       bg: NC.surface,     border: NC.border },
  };
  const tk = media
    ? typeConfigs[media.kind === 'video' ? 'media_video' : 'media_photo']
    : typeConfigs[memType];

  return (
    <div style={{ height: '100%', background: NC.bg, display: 'flex', flexDirection: 'column', position: 'relative' }}>

      {/* ── Header ── */}
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <button onClick={onCancel} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          fontFamily: NF.sans, fontSize: 16, fontWeight: 600, color: NC.primary, padding: 0,
        }}>Cancel</button>

        {/* type pill — signals what kind of memory this will become */}
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 5,
          background: tk.bg, border: `1px solid ${tk.border}`,
          borderRadius: 999, padding: '5px 11px 5px 8px',
          transition: 'all 220ms cubic-bezier(.22,.61,.36,1)',
        }}>
          <Icon name={tk.icon} size={12} color={tk.color} strokeWidth={2}/>
          <span style={{ fontFamily: NF.sans, fontSize: 12, fontWeight: 700, color: tk.color }}>
            {tk.label}
          </span>
        </div>

        <button onClick={onSave} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          fontFamily: NF.sans, fontSize: 16, fontWeight: 700,
          color: canSave ? NC.primary : NC.ink3, padding: 0,
        }}>Save</button>
      </div>

      {/* ── Date pill ── */}
      <div style={{ padding: '14px 20px 0' }}>
        <button style={{
          background: '#fff', border: `1px solid ${NC.border}`, borderRadius: 999,
          padding: '6px 13px', fontFamily: NF.sans, fontSize: 13, fontWeight: 600,
          color: NC.ink2, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 7,
        }}>
          <Icon name="calendar" size={13} color={NC.ink2}/>Today · Sun, May 25
          <Icon name="chevronDown" size={13} color={NC.ink2}/>
        </button>
      </div>

      {/* ── Text area ── */}
      <div style={{ padding: '14px 20px 0', flex: media ? 0 : 1, display: 'flex', flexDirection: 'column', minHeight: media ? 'auto' : 0 }}>
        <textarea
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder={media ? 'Add a caption (optional)…' : 'What just happened?'}
          style={{
            width: '100%', background: 'transparent', border: 'none', outline: 'none',
            fontFamily: NF.display, fontWeight: 400,
            fontSize: media ? 18 : 24, lineHeight: media ? 1.5 : 1.35,
            color: NC.ink, resize: 'none', boxSizing: 'border-box',
            minHeight: media ? 60 : 120,
            flex: media ? 0 : 1,
          }}
        />
        {!media && (
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <span style={{ fontFamily: NF.mono, fontSize: 11, color: NC.ink3 }}>
              {wordCount} {wordCount === 1 ? 'word' : 'words'}
            </span>
          </div>
        )}
      </div>

      {/* ── Media preview ── */}
      {media && (
        <div style={{ padding: '10px 20px 0', flex: 1 }}>
          <div style={{ position: 'relative' }}>
            <MediaThumbnail
              kind={media.kind}
              color={media.color}
              style={{ width: '100%', height: 195, borderRadius: 16 }}
            />
            <button
              onClick={() => setMedia(null)}
              style={{
                position: 'absolute', top: 10, right: 10,
                width: 30, height: 30, borderRadius: '50%',
                background: 'rgba(0,0,0,0.5)', border: 'none', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
              <Icon name="x" size={14} color="#fff" strokeWidth={2.5}/>
            </button>
            <div style={{
              position: 'absolute', bottom: 10, left: 12,
              background: 'rgba(0,0,0,0.45)', borderRadius: 999,
              padding: '3px 9px', display: 'inline-flex', alignItems: 'center', gap: 4,
            }}>
              <Icon name={media.kind === 'video' ? 'video' : 'camera'} size={10} color="rgba(255,255,255,0.95)" strokeWidth={2}/>
              <span style={{ fontFamily: NF.sans, fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,0.95)' }}>
                {media.kind === 'video' ? '0:32' : 'JPEG · 2.4 MB'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ── Media picker sheet ── */}
      {showPicker && !media && (
        <div style={{
          margin: '10px 20px 0',
          background: '#fff', border: `1px solid ${NC.border}`, borderRadius: 14,
          overflow: 'hidden', boxShadow: '0 8px 24px rgba(40,30,20,0.08)',
        }}>
          {[
            {
              label: 'Photo from camera roll',
              sub: 'JPEG, HEIC, PNG, WEBP · up to 20 MB',
              icon: 'camera',
              action: () => { setMedia({ kind: 'photo', color: '#ddc9a8' }); setShowPicker(false); },
            },
            {
              label: 'Video from camera roll',
              sub: 'MP4, MOV · up to 60 seconds',
              icon: 'video',
              action: () => { setMedia({ kind: 'video', color: '#b8cdb0' }); setShowPicker(false); },
            },
          ].map((opt, i) => (
            <button key={i} onClick={opt.action} style={{
              width: '100%', padding: '13px 16px',
              border: 'none', borderBottom: i === 0 ? `1px solid ${NC.border}` : 'none',
              background: 'none', cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 12, textAlign: 'left',
            }}>
              <div style={{
                width: 38, height: 38, borderRadius: 11, flexShrink: 0,
                background: NC.surface, display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Icon name={opt.icon} size={18} color={NC.ink2} strokeWidth={1.75}/>
              </div>
              <div>
                <div style={{ fontFamily: NF.sans, fontSize: 14, fontWeight: 600, color: NC.ink }}>{opt.label}</div>
                <div style={{ fontFamily: NF.sans, fontSize: 11, color: NC.ink3, marginTop: 2 }}>{opt.sub}</div>
              </div>
            </button>
          ))}
          <button
            onClick={() => setShowPicker(false)}
            style={{
              width: '100%', padding: '12px', border: 'none',
              background: NC.surface, fontFamily: NF.sans, fontSize: 14,
              fontWeight: 600, color: NC.ink2, cursor: 'pointer',
            }}>
            Cancel
          </button>
        </div>
      )}

      {/* ── Tag strip ── */}
      <WhosInIt tagged={tagged} setTagged={setTagged} max={4} defaultOpen={pickerOpen}/>

      {/* ── Bottom toolbar ── */}
      <div style={{
        padding: '13px 20px 28px',
        borderTop: `1px solid ${NC.border}`,
        marginTop: 12,
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        {/* Mic */}
        <button style={{
          width: 46, height: 46, borderRadius: '50%', flexShrink: 0,
          background: '#fff', border: `1px solid ${NC.border}`,
          cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="mic" size={20} color={NC.sea} strokeWidth={2}/>
        </button>

        {/* Attach — dimmed when media already attached */}
        <button
          onClick={() => { if (!media) setShowPicker(v => !v); }}
          style={{
            width: 46, height: 46, borderRadius: '50%', flexShrink: 0,
            background: media ? NC.surface : (showPicker ? NC.primaryTint : '#fff'),
            border: `1px solid ${showPicker && !media ? NC.primary : NC.border}`,
            cursor: media ? 'default' : 'pointer', opacity: media ? 0.4 : 1,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'all 140ms',
          }}>
          <Icon name="paperclip" size={20} color={showPicker && !media ? NC.primary : NC.ink2} strokeWidth={1.75}/>
        </button>

        {/* AI illustration toggle — only when no media attached */}
        {!media && (
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 10 }}>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontFamily: NF.sans, fontSize: 12.5, fontWeight: 700, color: illustrationEnabled ? NC.ink : NC.ink3 }}>
                AI illustration
              </div>
              <div style={{ fontFamily: NF.sans, fontSize: 11, color: NC.ink3 }}>
                {illustrationEnabled ? 'On — runs after save' : 'Off — text only'}
              </div>
            </div>
            <div
              onClick={() => setIllustrationEnabled(v => !v)}
              style={{ cursor: 'pointer', flexShrink: 0 }}>
              <div style={{
                width: 44, height: 26, borderRadius: 999,
                background: illustrationEnabled ? NC.primary : NC.border,
                transition: 'background 200ms',
                display: 'flex', alignItems: 'center', padding: '0 3px',
              }}>
                <div style={{
                  width: 20, height: 20, borderRadius: '50%', background: '#fff',
                  transform: illustrationEnabled ? 'translateX(18px)' : 'translateX(0)',
                  transition: 'transform 200ms cubic-bezier(.22,.61,.36,1)',
                  boxShadow: '0 1px 4px rgba(0,0,0,0.18)',
                }}/>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── NEW MEMORY B — Voice-first hero recorder ───────────────────────────────
function NewMemoryB({ onCancel = () => {}, onSave = () => {} }) {
  const [state, setState] = React.useState('idle');
  const [seconds, setSeconds] = React.useState(0);
  const [text, setText] = React.useState('');
  const [illustrationEnabled, setIllustrationEnabled] = React.useState(true);
  const family = window.MOMORA_MOCK.family;
  const [tagged, setTagged] = React.useState(['lila']);

  React.useEffect(() => {
    if (state === 'recording') {
      const i = setInterval(() => setSeconds(s => s + 1), 1000);
      return () => clearInterval(i);
    }
  }, [state]);

  const start = () => { setSeconds(0); setState('recording'); };
  const stop  = () => {
    setState('transcribing');
    setTimeout(() => {
      setText('Lila found my fluffy slippers and decided they were microphones. Full setlist before breakfast. She bowed.');
      setState('review');
    }, 1400);
  };

  const mmss = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
  const toggleMember = (id) =>
    setTagged(t => t.includes(id) ? t.filter(x => x !== id) : (t.length >= 4 ? t : [...t, id]));

  return (
    <div style={{ height: '100%', background: NC.bg, display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Button variant="ghost" size="sm" onClick={onCancel}>Cancel</Button>
        <Eyebrow color={NC.ink3}>Speak it</Eyebrow>
        <div style={{ width: 60 }}/>
      </div>

      {state !== 'review' ? (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 32px' }}>
          <div style={{ position: 'relative', width: 260, height: 260, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{
              position: 'absolute', inset: 0,
              background: `radial-gradient(circle at 50% 50%, ${NC.seaSoft} 0%, transparent 70%)`,
              borderRadius: '50%',
              transform: state === 'recording' ? 'scale(1.08)' : 'scale(0.85)',
              transition: 'transform 1200ms ease-in-out',
            }}/>
            <div style={{
              position: 'absolute', inset: 30,
              background: `radial-gradient(circle at 40% 35%, ${NC.sea}90 0%, ${NC.seaInk}40 80%)`,
              borderRadius: '50%',
              transform: state === 'recording' ? 'scale(1.0)' : 'scale(0.75)',
              transition: 'transform 220ms cubic-bezier(.22,.61,.36,1)',
            }}/>
            <button onClick={state === 'recording' ? stop : start} style={{
              position: 'relative', width: 96, height: 96, borderRadius: '50%',
              background: state === 'recording' ? '#fff' : NC.sea, color: state === 'recording' ? NC.sea : '#fff',
              border: 'none', cursor: 'pointer', boxShadow: '0 16px 40px rgba(63,168,161,0.4)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'all 220ms',
            }}>
              {state === 'recording'
                ? <Icon name="stop" size={28} color={NC.sea} strokeWidth={2}/>
                : <Icon name="mic" size={36} color="#fff" strokeWidth={2}/>}
            </button>
          </div>
          <div style={{ marginTop: 36, textAlign: 'center', minHeight: 100, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            {state === 'idle' && (
              <>
                <Display size={26}>Tell me what happened.</Display>
                <Body size={14} muted style={{ marginTop: 14 }}>Tap to start. Tap to stop. 2 minute max.</Body>
              </>
            )}
            {state === 'recording' && (
              <>
                <Display size={36} style={{ fontFamily: NF.mono, color: NC.seaInk }}>{mmss}</Display>
                <Body size={14} muted style={{ marginTop: 14 }}>Listening…</Body>
              </>
            )}
            {state === 'transcribing' && (
              <>
                <Display size={22} style={{ color: NC.seaInk }}>One second…</Display>
                <Body size={13} muted style={{ marginTop: 12 }}>Turning your words into text.</Body>
              </>
            )}
          </div>
        </div>
      ) : (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '24px 24px 0' }}>
          <Eyebrow color={NC.sea}>Heard you · 18s</Eyebrow>
          <div style={{ marginTop: 14, background: '#fff', border: `1px solid ${NC.border}`, borderRadius: 16, padding: 18 }}>
            <textarea value={text} onChange={e => setText(e.target.value)} rows={5} style={{
              width: '100%', border: 'none', outline: 'none', resize: 'none', background: 'transparent',
              fontFamily: NF.display, fontWeight: 400, fontSize: 19, lineHeight: 1.4, color: NC.ink,
              boxSizing: 'border-box',
            }}/>
          </div>

          {/* AI toggle in review state */}
          <div style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderTop: `1px solid ${NC.border}` }}>
            <div style={{ flex: 1 }}>
              <Body size={13} style={{ fontWeight: 700 }}>Generate AI illustration</Body>
              <Body size={11} muted>On by default — runs after save</Body>
            </div>
            <div onClick={() => setIllustrationEnabled(v => !v)} style={{ cursor: 'pointer', flexShrink: 0 }}>
              <div style={{
                width: 44, height: 26, borderRadius: 999,
                background: illustrationEnabled ? NC.primary : NC.border,
                transition: 'background 200ms',
                display: 'flex', alignItems: 'center', padding: '0 3px',
              }}>
                <div style={{
                  width: 20, height: 20, borderRadius: '50%', background: '#fff',
                  transform: illustrationEnabled ? 'translateX(18px)' : 'translateX(0)',
                  transition: 'transform 200ms cubic-bezier(.22,.61,.36,1)',
                  boxShadow: '0 1px 4px rgba(0,0,0,0.18)',
                }}/>
              </div>
            </div>
          </div>

          <div style={{ marginTop: 14 }}>
            <Eyebrow color={NC.ink3} style={{ fontSize: 10, marginBottom: 10 }}>Tagged from voice</Eyebrow>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {family.map(f => {
                const on = tagged.includes(f.id);
                return (
                  <button key={f.id} onClick={() => toggleMember(f.id)} style={{
                    display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px 4px 4px',
                    background: on ? NC.primaryTint : '#fff', border: `1px solid ${on ? NC.primary : NC.border}`,
                    borderRadius: 999, cursor: 'pointer',
                  }}>
                    <Avatar name={f.name} size={24} tint={f.tint}/>
                    <span style={{ fontFamily: NF.sans, fontSize: 12.5, fontWeight: 700, color: on ? NC.primary : NC.ink }}>{f.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
          <div style={{ flex: 1 }}/>
          <div style={{ padding: '20px 0 28px', display: 'flex', gap: 10 }}>
            <Button variant="secondary" size="md" onClick={() => { setState('idle'); setText(''); setSeconds(0); }} style={{ flex: 1 }}>Re-record</Button>
            <Button onClick={onSave} style={{ flex: 2 }}>Save moment</Button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── MEMORY DETAIL A — Framed print (text_illustration + media) ─────────────
// Reused for both: illustrated memories show the AI art, media shows the photo/video.
function MemoryDetailA({ m = window.MOMORA_MOCK.memories[0], onBack = () => {}, onEdit = () => {}, illustrationState = 'ready', autoOpenComments = false }) {
  const isMedia = m.memory_type === 'media';
  const eng = useEngagement(m);
  const [commentsOpen, setCommentsOpen] = React.useState(!!autoOpenComments);

  return (
    <div style={{ height: '100%', background: NC.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative' }}>

      {/* ── Header ── */}
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <button onClick={onBack} style={iconBtn}>
          <Icon name="chevronLeft" size={18} color={NC.ink2}/>
        </button>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={onEdit} style={iconBtn}><Icon name="edit" size={16} color={NC.ink2}/></button>
          <button style={iconBtn}><Icon name="trash" size={15} color={NC.error}/></button>
        </div>
      </div>

      {/* ── Scrollable centered area ── */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ minHeight: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '16px 24px 40px' }}>

          {/* single card */}
          <div style={{
            background: '#fff', border: `1px solid ${NC.border}`, borderRadius: 24,
            padding: 14, boxShadow: '0 6px 24px rgba(40,30,20,0.07)',
          }}>
            {isMedia ? (
              <div style={{ position: 'relative' }}>
                <MediaThumbnail
                  kind={m.mediaKind}
                  color={m.mediaColor || '#ddc9a8'}
                  style={{ width: '100%', aspectRatio: '4/3', borderRadius: 14 }}
                />
                {m.mediaKind === 'video' && (
                  <div style={{
                    position: 'absolute', bottom: 10, right: 12,
                    background: 'rgba(0,0,0,0.45)', borderRadius: 999,
                    padding: '4px 10px', display: 'flex', alignItems: 'center', gap: 5,
                  }}>
                    <Icon name="play" size={11} color="#fff" strokeWidth={2.5}/>
                    <span style={{ fontFamily: NF.sans, fontSize: 12, fontWeight: 600, color: '#fff' }}>0:32</span>
                  </div>
                )}
              </div>
            ) : illustrationState === 'ready' ? (
              <Illustration emotion={m.emotion} scene={m.scene}
                style={{ width: '100%', aspectRatio: '4/5', borderRadius: 14 }}
                stamp={window.fmtDate(m.date)}/>
            ) : (
              <div style={{
                width: '100%', aspectRatio: '4/5', borderRadius: 14,
                background: NC.surface, display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <div style={{ textAlign: 'center' }}>
                  <Icon name="sparkle" size={32} color={NC.primary}/>
                  <Body size={13} muted style={{ marginTop: 8 }}>Generating your illustration…</Body>
                </div>
              </div>
            )}

            {/* card content below visual */}
            <div style={{ padding: '14px 10px 6px', display: 'flex', flexDirection: 'column', gap: 10 }}>
              <EngagementBar eng={eng} onOpenComments={() => setCommentsOpen(true)} iconSize={24}/>
              <Eyebrow color={NC.primary} style={{ fontSize: 11 }}>{window.fmtDate(m.date)}</Eyebrow>
              {m.emotion && <div style={{ alignSelf: 'flex-start' }}><EmotionChip emotion={m.emotion} size="md"/></div>}
              {m.content && <span style={{ fontFamily: NF.display, fontSize: 17, fontWeight: 400, lineHeight: 1.6, color: NC.ink }}>{m.content}</span>}
              {m.tagged.length > 0 && (
                <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', paddingTop: 10, borderTop: `1px solid ${NC.border}` }}>
                  {m.tagged.map(id => {
                    const mm = window.MOMORA_MOCK.byId[id];
                    return (
                      <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <Avatar name={mm.name} size={24} tint={mm.tint}/>
                        <Body size={13} style={{ fontWeight: 600 }}>{mm.name}, {window.ageOf(mm.dob)}</Body>
                      </div>
                    );
                  })}
                </div>
              )}
              {!isMedia && illustrationState === 'failed' && (
                <button style={{ alignSelf: 'flex-start', background: NC.surface, border: `1px solid ${NC.border}`, borderRadius: 10, padding: '8px 14px', fontFamily: NF.sans, fontSize: 13, fontWeight: 700, color: NC.primary, cursor: 'pointer' }}>
                  Retry illustration
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
      <CommentsDrawer open={commentsOpen} onClose={() => setCommentsOpen(false)} eng={eng}/>
    </div>
  );
}

// ─── MEMORY DETAIL B — Text only · editorial focus ──────────────────────────
// Emotion-tinted header (no illustration) + overlapping paper card with full text.
function MemoryDetailB({ m = window.MOMORA_MOCK.memories[1], onBack = () => {}, onEdit = () => {}, autoOpenComments = false }) {
  const emo = m.emotion ? window.MOMORA_EMOTIONS[m.emotion] : null;
  const eng = useEngagement(m);
  const [commentsOpen, setCommentsOpen] = React.useState(!!autoOpenComments);
  const headerBg = emo
    ? `linear-gradient(160deg, ${emo.soft} 0%, ${emo.soft}cc 100%)`
    : `linear-gradient(160deg, ${NC.surface} 0%, ${NC.surface} 100%)`;

  return (
    <div style={{ height: '100%', background: NC.bg, overflow: 'hidden', position: 'relative' }}>
      <div style={{ height: '100%', overflowY: 'auto' }}>
        {/* tinted header — replaces illustration */}
        <div style={{ position: 'relative', height: 300 }}>
          <div style={{ position: 'absolute', inset: 0, background: headerBg }}>
            {/* large decorative quote */}
            <div style={{
              position: 'absolute', top: 60, left: 20,
              fontFamily: NF.display, fontSize: 160, fontWeight: 400, lineHeight: 1,
              color: emo ? emo.ink : NC.ink3, opacity: 0.1,
              userSelect: 'none', pointerEvents: 'none',
            }}>"</div>
          </div>
          {/* top chrome */}
          <div style={{ position: 'absolute', top: 60, left: 20, right: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center', zIndex: 2 }}>
            <button onClick={onBack} style={{
              width: 38, height: 38, borderRadius: '50%', background: 'rgba(255,255,255,0.85)',
              border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
            }}>
              <Icon name="chevronLeft" size={18} color={NC.ink}/>
            </button>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <button onClick={onEdit} style={{ width: 38, height: 38, borderRadius: '50%', background: 'rgba(255,255,255,0.85)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
                <Icon name="edit" size={16} color={NC.ink2}/>
              </button>
              <button style={{ width: 38, height: 38, borderRadius: '50%', background: 'rgba(255,255,255,0.85)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
                <Icon name="trash" size={15} color={NC.error}/>
              </button>
            </div>
          </div>
          {/* fade to bg */}
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 160, background: `linear-gradient(180deg, transparent 0%, ${NC.bg} 100%)` }}/>
        </div>

        {/* overlapping paper card */}
        <div style={{ margin: '-80px 20px 0', position: 'relative' }}>
          <Paper pad={24} style={{ boxShadow: '0 24px 48px rgba(40,30,20,0.08)' }}>
            <Eyebrow color={NC.primary} style={{ fontSize: 11 }}>{window.fmtDate(m.date)}</Eyebrow>
            {m.emotion && <div style={{ marginTop: 10 }}><EmotionChip emotion={m.emotion} size="md"/></div>}
            <Display size={22} style={{ marginTop: 14, lineHeight: 1.55 }}>{m.content}</Display>
            <div style={{ marginTop: 18, paddingTop: 14, borderTop: `1px solid ${NC.border}` }}>
              <EngagementBar eng={eng} onOpenComments={() => setCommentsOpen(true)} iconSize={24}/>
            </div>
            <div style={{ marginTop: 20, paddingTop: 16, borderTop: `1px solid ${NC.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {m.tagged.map(id => {
                  const mm = window.MOMORA_MOCK.byId[id];
                  return (
                    <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <Avatar name={mm.name} size={26} tint={mm.tint}/>
                      <Body size={13} style={{ fontWeight: 600 }}>{mm.name}, {window.ageOf(mm.dob)}</Body>
                    </div>
                  );
                })}
              </div>
              <Script size={22} color={NC.primary} style={{ transform: 'rotate(-3deg)', flexShrink: 0, marginLeft: 8 }}>{m.dayLabel}</Script>
            </div>
          </Paper>
        </div>
      </div>
      <CommentsDrawer open={commentsOpen} onClose={() => setCommentsOpen(false)} eng={eng}/>
    </div>
  );
}

// ─── MEMORY DETAIL C — Text only ────────────────────────────────────────────
function MemoryDetailTextOnly({ m = window.MOMORA_MOCK.memories[1], onBack = () => {}, autoOpenComments = false }) {
  const emo = m.emotion ? window.MOMORA_EMOTIONS[m.emotion] : null;
  const eng = useEngagement(m);
  const [commentsOpen, setCommentsOpen] = React.useState(!!autoOpenComments);

  return (
    <div style={{ height: '100%', background: NC.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative' }}>

      {/* ── Header ── */}
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <button onClick={onBack} style={iconBtn}>
          <Icon name="chevronLeft" size={18} color={NC.ink2}/>
        </button>
        <button style={iconBtn}><Icon name="edit" size={16} color={NC.ink2}/></button>
      </div>

      {/* ── Date + type badge ── */}
      <div style={{ padding: '16px 24px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <Eyebrow color={NC.ink3} style={{ fontSize: 11 }}>{window.fmtDate(m.date)}</Eyebrow>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: NC.surface, border: `1px solid ${NC.border}`, borderRadius: 999, padding: '4px 10px 4px 8px' }}>
          <Icon name="type" size={11} color={NC.ink3} strokeWidth={2}/>
          <span style={{ fontFamily: NF.sans, fontSize: 11, fontWeight: 700, color: NC.ink3 }}>Text only</span>
        </div>
      </div>

      {/* ── Scrollable centered area ── */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ minHeight: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '16px 24px 40px' }}>

          {/* text card — book-page treatment */}
          <Paper pad={28} style={{ position: 'relative', overflow: 'hidden', boxShadow: '0 6px 20px rgba(40,30,20,0.06)' }}>
            {/* decorative opening quote */}
            <div style={{
              position: 'absolute', top: 2, left: 14,
              fontFamily: NF.display, fontSize: 88, fontWeight: 400, lineHeight: 1,
              color: emo ? emo.soft : NC.surface,
              userSelect: 'none', pointerEvents: 'none',
            }}>"</div>
            <div style={{ position: 'relative' }}>
              {m.emotion && <div style={{ marginBottom: 16 }}><EmotionChip emotion={m.emotion} size="md"/></div>}
              <Display size={22} style={{ lineHeight: 1.55 }}>{m.content}</Display>
              <div style={{ marginTop: 18, paddingTop: 14, borderTop: `1px solid ${NC.border}` }}>
                <EngagementBar eng={eng} onOpenComments={() => setCommentsOpen(true)} iconSize={24}/>
              </div>
              {m.tagged.length > 0 && (
                <div style={{ marginTop: 20, paddingTop: 16, borderTop: `1px solid ${NC.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    {m.tagged.map(id => {
                      const mm = window.MOMORA_MOCK.byId[id];
                      return (
                        <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                          <Avatar name={mm.name} size={26} tint={mm.tint}/>
                          <Body size={13} style={{ fontWeight: 600 }}>{mm.name}, {window.ageOf(mm.dob)}</Body>
                        </div>
                      );
                    })}
                  </div>
                  <Script size={22} color={NC.primary} style={{ transform: 'rotate(-3deg)', flexShrink: 0, marginLeft: 8 }}>{m.dayLabel}</Script>
                </div>
              )}
            </div>
          </Paper>

          <button style={{ width: '100%', padding: '16px 0', background: 'none', border: 'none', cursor: 'pointer', fontFamily: NF.sans, fontSize: 14, fontWeight: 600, color: NC.error, textAlign: 'center' }}>
            Delete memory
          </button>
        </div>
      </div>
      <CommentsDrawer open={commentsOpen} onClose={() => setCommentsOpen(false)} eng={eng}/>
    </div>
  );
}

// ─── MEMORY DETAIL D — Media (photo / video) ────────────────────────────────
function MemoryDetailMedia({ m = window.MOMORA_MOCK.memories[2], onBack = () => {}, autoOpenComments = false }) {
  const isVideo = m.mediaKind === 'video';
  const eng = useEngagement(m);
  const [commentsOpen, setCommentsOpen] = React.useState(!!autoOpenComments);

  return (
    <div style={{ height: '100%', background: NC.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative' }}>

      {/* ── Header ── */}
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <button onClick={onBack} style={iconBtn}>
          <Icon name="chevronLeft" size={18} color={NC.ink2}/>
        </button>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={iconBtn}><Icon name="edit" size={16} color={NC.ink2}/></button>
          <button style={iconBtn}><Icon name="trash" size={15} color={NC.error}/></button>
        </div>
      </div>

      {/* ── Scrollable centered area ── */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ minHeight: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '16px 24px 40px' }}>

          {/* single card */}
          <div style={{
            background: '#fff', border: `1px solid ${NC.border}`, borderRadius: 24,
            padding: 14, boxShadow: '0 6px 24px rgba(40,30,20,0.07)',
          }}>
            <div style={{ position: 'relative' }}>
              <MediaThumbnail
                kind={m.mediaKind}
                color={m.mediaColor || '#ddc9a8'}
                style={{ width: '100%', aspectRatio: '4/3', borderRadius: 14 }}
              />
              {isVideo && (
                <div style={{
                  position: 'absolute', bottom: 10, right: 12,
                  background: 'rgba(0,0,0,0.45)', borderRadius: 999,
                  padding: '4px 10px', display: 'flex', alignItems: 'center', gap: 5,
                }}>
                  <Icon name="play" size={11} color="#fff" strokeWidth={2.5}/>
                  <span style={{ fontFamily: NF.sans, fontSize: 12, fontWeight: 600, color: '#fff' }}>0:32</span>
                </div>
              )}
            </div>

            {/* card content */}
            <div style={{ padding: '14px 10px 6px', display: 'flex', flexDirection: 'column', gap: 10 }}>
              <EngagementBar eng={eng} onOpenComments={() => setCommentsOpen(true)} iconSize={24}/>
              <Eyebrow color={NC.primary} style={{ fontSize: 11 }}>{window.fmtDate(m.date)}</Eyebrow>
              {m.emotion && <div style={{ alignSelf: 'flex-start' }}><EmotionChip emotion={m.emotion} size="md"/></div>}
              {m.content && <span style={{ fontFamily: NF.display, fontSize: 17, fontWeight: 400, lineHeight: 1.6, color: NC.ink }}>{m.content}</span>}
              {m.tagged.length > 0 && (
                <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', paddingTop: 10, borderTop: `1px solid ${NC.border}` }}>
                  {m.tagged.map(id => {
                    const mm = window.MOMORA_MOCK.byId[id];
                    return (
                      <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <Avatar name={mm.name} size={24} tint={mm.tint}/>
                        <Body size={13} style={{ fontWeight: 600 }}>{mm.name}, {window.ageOf(mm.dob)}</Body>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <CommentsDrawer open={commentsOpen} onClose={() => setCommentsOpen(false)} eng={eng}/>
    </div>
  );
}

Object.assign(window, { NewMemoryA, NewMemoryB, MemoryDetailA, MemoryDetailB, MemoryDetailTextOnly, MemoryDetailMedia });
