// Rediscovery prototype wiring + the interaction/motion notes sheet.
const { c: XC, f: XF } = window.MOMORA;

// Archive chapter → the memory shape the existing detail screens expect.
function chapterToMemory(ch) {
  const base = {
    id: 'arch_' + ch.id, date: ch.date,
    dayLabel: new Date(ch.date + 'T12:00:00').getFullYear(),
    tagged: ch.tagged, emotion: ch.emotion, content: ch.content,
    likedByMe: false, likeCount: 2, comments: [],
  };
  if (ch.type === 'multi_media') {
    return { ...base, memory_type: 'multi_media', mediaItems: ch.assets.map((a, i) => ({
      id: ch.id + '-' + i, kind: a.kind, color: a.color,
      duration: a.duration ? `0:${String(a.duration).padStart(2, '0')}` : undefined,
    })) };
  }
  if (ch.type === 'media') {
    return { ...base, memory_type: 'media', mediaKind: ch.assets[0].kind, mediaColor: ch.assets[0].color };
  }
  if (ch.type === 'text_only') return { ...base, memory_type: 'text_only' };
  return { ...base, memory_type: 'text_illustration', scene: ch.scene };
}

// Timeline → viewer → memory detail → back into the viewer, position kept.
function RediscoverPrototype({ variant = 'plate', startPkg = null }) {
  const [screen, setScreen] = React.useState(startPkg ? 'viewer' : 'timeline');
  const [pkgId, setPkgId] = React.useState(startPkg || 'p-onthisday');
  const [resumeAt, setResumeAt] = React.useState(null);
  const [detail, setDetail] = React.useState(null);
  const [seenIds, setSeenIds] = React.useState([]);

  const packages = window.MOMORA_ARCHIVE.packages.map(p =>
    seenIds.includes(p.id) ? { ...p, viewed: true, seenLabel: 'Revisited today' } : p);

  if (screen === 'viewer') {
    return (
      <StoryViewer
        key={pkgId + (resumeAt ? '-r' + resumeAt.chapterIdx + resumeAt.assetIdx : '')}
        pkgId={pkgId} autoplay
        stage={resumeAt ? 'frame' : 'intro'}
        resumeAt={resumeAt}
        onClose={() => { setSeenIds(s => s.includes(pkgId) ? s : [...s, pkgId]); setResumeAt(null); setScreen('timeline'); }}
        onOpenDetail={(ch, pos) => { setResumeAt(pos); setDetail(chapterToMemory(ch)); setScreen('detail'); }}
      />
    );
  }
  if (screen === 'detail' && detail) {
    const back = () => setScreen('viewer');
    if (detail.memory_type === 'multi_media') return <MemoryDetailMultiMedia m={detail} onBack={back}/>;
    if (detail.memory_type === 'text_only') return <MemoryDetailB m={detail} onBack={back}/>;
    return <MemoryDetailA m={detail} onBack={back}/>;
  }
  return (
    <TimelineRediscover
      packages={packages} variant={variant}
      onOpenPackage={(p) => { setPkgId(p.id); setResumeAt(null); setScreen('viewer'); }}
    />
  );
}

// ── Notes sheet ──────────────────────────────────────────────────────────────
function NoteBlock({ title, items }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
      <Eyebrow style={{ fontSize: 10.5 }}>{title}</Eyebrow>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
        {items.map((t, i) => (
          <div key={i} style={{ display: 'flex', gap: 9, alignItems: 'flex-start' }}>
            <div style={{ width: 5, height: 5, borderRadius: 999, background: XC.border, marginTop: 7, flexShrink: 0 }}/>
            <div style={{ fontFamily: XF.sans, fontSize: 12.5, lineHeight: 1.55, color: XC.ink2, textWrap: 'pretty' }}
              dangerouslySetInnerHTML={{ __html: t }}/>
          </div>
        ))}
      </div>
    </div>
  );
}

function RediscoverNotes() {
  const b = (s) => `<strong style="color:${XC.ink};font-weight:700">${s}</strong>`;
  return (
    <div style={{ height: '100%', overflowY: 'auto', background: XC.bg, padding: '34px 34px 44px' }}>
      <Eyebrow>Looking back · interaction &amp; motion</Eyebrow>
      <div style={{ fontFamily: XF.display, fontWeight: 400, fontSize: 34, lineHeight: 1.08, letterSpacing: '-0.02em', color: XC.ink, marginTop: 14 }}>
        How it behaves.
      </div>
      <div style={{ fontFamily: XF.sans, fontSize: 13.5, lineHeight: 1.6, color: XC.ink2, marginTop: 12, maxWidth: 460 }}>
        Nothing here counts anything, expires, or asks for a memory back. The rail is a reward for a journal that already has history in it — so every rule below leans calm.
      </div>

      <div style={{ marginTop: 30, display: 'grid', gap: 26 }}>
        <NoteBlock title="The rail" items={[
          `Packages sit directly under the Timeline header, above ${b('This week')}. Horizontal scroll, snap to card start, no arrows, no dots.`,
          `Today's set is chosen server-side and ${b('stable all day')}; cooldown keeps a package or its memories from returning too soon. The client just renders what it is given.`,
          `Fewer than four meaningful memories in a candidate collection → that package is not built. No candidates at all → ${b('the whole block is absent')}, header spacing closes up, no empty state, no placeholder.`,
          `Card press: opacity 0.9, ${b('no scale')}. 140ms.`,
        ]}/>
        <NoteBlock title="Viewed vs unviewed" items={[
          `Unviewed: full-colour cover under the warm scrim, plate lifted (${b('0 12px 28px')} shadow), kind eyebrow in warm cream, meta reads “6 memories · 2024”.`,
          `Viewed: the lift shadow drops to a 1px seat, the cover desaturates to 78% under a 20% lavender veil, the scrim softens, and the meta becomes ${b('“Revisited today”')}.`,
          `A package holding only written memories has no art to lean on, so the cover leans on ${b('type alone')}: one Newsreader quotation mark on an emotion-tinted plate, ink type instead of cream, no scrim. No excerpt is pulled \u2014 written memories are not always quotes, and one line rarely stands for the set.`,
          `No rings, dots, counts, or “new” badges in either state. Order never punishes: viewed packages stay in place rather than being pushed to the end.`,
        ]}/>
        <NoteBlock title="Opening + closing" items={[
          `Tapping a card scales the cover up into the viewer's intro card (${b('380ms')}, --ease-out) while the mat fades from the timeline bg to the warm dark. Timeline stays mounted underneath.`,
          `The viewer opens on a ${b('title card')}: package kind, name, count, and a fanned three-print stack. It holds 2.6s, shows the only instruction in the feature — “Tap to move · hold to pause” — then advances.`,
          `Close is a persistent ✕ top-right (34px, cream at 14%). Escape also closes. Closing reverses the same 380ms transform back onto the card.`,
        ]}/>
        <NoteBlock title="Advancement + pausing" items={[
          `Dwell is content-derived, not fixed: illustration ${b('5.6s')}, photo ${b('4.6s')}, video = its own length (3.5–9s), short text ${b('5.6s')}, long text ${b('6s + 0.26s per word')} capped at 16s. Legibility wins over rhythm.`,
          `Tap left third = previous frame, right two-thirds = next. Frames are ${b('per-asset')}, so tapping through a 4-photo memory walks its assets, then lands on the next memory.`,
          `Press and hold (220ms) pauses: a 34% veil, a “Paused” pill under the chrome, and the caption ${b('un-clamps to full length')}. Release resumes from the same millisecond.`,
          `The app going inactive (visibilitychange, call, app switch) pauses identically — never silently burns frames in the background.`,
        ]}/>
        <NoteBlock title="Progress" items={[
          `One segment per ${b('memory')}, width proportional to that memory's total dwell — so a 4-photo chapter is visibly a longer stretch than a one-line note.`,
          `Inside a multi-asset memory the segment splits into ${b('hairline ticks')} (2px gaps), one per asset. Ticks fill left to right; you can read “3rd memory, 2nd of 4 photos” at a glance without counting identical bars.`,
          `Fill animates 90ms linear so scrubs and taps feel instant; bars never bounce or pulse.`,
        ]}/>
        <NoteBlock title="Chapter transitions" items={[
          `Within a memory: assets ${b('cross-fade 300ms')}; the date, caption, emotion, and tagged faces do not move — that continuity is what says “still the same memory”.`,
          `Between memories: the same 300ms fade plus the mat's glow tweening to the new memory's emotion hue over ${b('380ms')}. No slide, no push, no zoom.`,
          `Text memories invert to a cream page tinted with the memory's emotion, opened by the same serif quote glyph the text memory-detail screen uses. The flip between dark media and cream page is the deliberate rhythm break of the sequence.`,
        ]}/>
        <NoteBlock title="Media states" items={[
          `Loading: cream-8% panel, gentle 1.6s pulse, “Loading this photo…”. ${b('The timer does not start')} until the asset is ready — you never miss a frame you never saw.`,
          `Unavailable: dashed panel, “This photo isn't on this device right now.” with “It may still be syncing. The memory and its words are safe.” The caption and date stay; playback continues normally.`,
          `Video: plays inline, ${b('muted by default')}, with a moon/sun toggle beside the ✕ and an elapsed pill on the frame. Its progress tick is its real duration.`,
        ]}/>
        <NoteBlock title="Into full detail — and back" items={[
          `Every frame carries one quiet outline pill, ${b('“Open memory →”')}, bottom-right. It is the only action in the viewer; likes, comments, edit, and regenerate all live on the detail screen.`,
          `Tapping it pauses playback and pushes the existing memory-detail screen (illustrated / text / multi-media variants, unchanged).`,
          `Back restores the viewer at ${b('the same frame and the same progress')} — not the start of the chapter, not the start of the package.`,
        ]}/>
        <NoteBlock title="Completion" items={[
          `After the last frame: a fanned row of the package's covers, “That was 6 from 2024.”, and the reassurance ${b('“Every one of them is still in your timeline.”')}`,
          `Two actions only: ${b('Back to your timeline')} (cream, primary) and Play it again (ghost). No next-package autoplay, no share prompt, no “capture something new” nudge.`,
          `On close, the card's meta line becomes “Revisited today”. That is the entire reward loop.`,
        ]}/>
      </div>
    </div>
  );
}

Object.assign(window, { RediscoverPrototype, RediscoverNotes, chapterToMemory, NoteBlock });
