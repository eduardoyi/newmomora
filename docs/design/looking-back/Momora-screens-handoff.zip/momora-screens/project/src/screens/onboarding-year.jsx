// S10b · A year of these — makes "imagine a year of these" literal.
// One screen, self-scrolling. Teaches the memory types by showing them.
const { c: YC, f: YF, r: YR } = window.MOMORA;
const YNB = window.ONB;

// Shared footer row on every card in the mock.
function YearCardFooter({ day, tint, who = YNB.name }) {
  return (
    <div style={{ padding: '9px 13px 11px', display: 'flex', alignItems: 'center', gap: 7 }}>
      <span style={{ fontFamily: YF.sans, fontSize: 9, fontWeight: 800, letterSpacing: '0.07em', textTransform: 'uppercase', color: YC.ink3 }}>{day}</span>
      <Avatar name={who} size={16} tint={tint}/>
      <div style={{ flex: 1 }}/>
      <EmotionChip emotion={tint} size="sm"/>
    </div>
  );
}

function OnbYear() {
  const emo = window.MOMORA_EMOTIONS;
  const firstText = "She lined up all her stuffed animals facing the window and told them to \"watch for the garbage truck, it's the best part.\"";
  return (
    <div style={{ height: '100%', background: YC.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '62px 26px 0', flexShrink: 0 }}>
        <Display size={30}>A year of these looks like this.</Display>
      </div>

      {/* self-scrolling mock timeline */}
      <div style={{ flex: 1, position: 'relative', marginTop: 16, minHeight: 0 }}>
        <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', maskImage: 'linear-gradient(to bottom, transparent 0, #000 30px, #000 78%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to bottom, transparent 0, #000 30px, #000 78%, transparent 100%)' }}>
          <div style={{ padding: '6px 26px 40px', display: 'flex', flexDirection: 'column', gap: 22, animation: 'yearDrift 38s cubic-bezier(0.22,0.61,0.36,1) infinite alternate' }}>

            {/* the user's own card, anchored at the start */}
            <div style={{ position: 'relative' }}>
              <Paper pad={0} style={{ overflow: 'hidden', border: `1.5px solid ${YC.primary}`, boxShadow: `0 8px 24px ${YC.primary}22` }}>
                <div style={{ position: 'relative', padding: '22px 16px 4px', background: `linear-gradient(170deg, ${emo.joy.soft}55 0%, transparent 62%)` }}>
                  <div style={{ position: 'absolute', top: 0, left: 9, fontFamily: YF.display, fontSize: 58, color: emo.joy.c, opacity: 0.16, lineHeight: 1 }}>&ldquo;</div>
                  <div style={{ position: 'relative', fontFamily: YF.display, fontStyle: 'italic', fontSize: 15, lineHeight: 1.42, color: YC.ink }}>{firstText}</div>
                </div>
                <YearCardFooter day="Tonight" tint="joy"/>
              </Paper>
            </div>

            {/* illustrated storybook page */}
            <div style={{ position: 'relative' }}>
              <Paper pad={0} style={{ overflow: 'hidden' }}>
                <Illustration emotion="mischief" scene="garden" style={{ width: '100%', aspectRatio: '4/3' }}/>
                <div style={{ padding: '11px 13px 0' }}>
                  <Body size={13} style={{ lineHeight: 1.4 }}>Declared the hose "broken" right after soaking the dog on purpose.</Body>
                </div>
                <YearCardFooter day="Sat, Aug 9" tint="mischief"/>
              </Paper>
            </div>

            {/* photo card */}
            <div style={{ position: 'relative' }}>
              <Paper pad={0} style={{ overflow: 'hidden' }}>
                <MediaThumbnail kind="photo" color="#d8c39c" style={{ width: '100%', aspectRatio: '4/3', borderRadius: 0 }}/>
                <div style={{ padding: '11px 13px 0' }}>
                  <Body size={13} style={{ lineHeight: 1.4 }}>Two hours at the zoo. Favourite animal: a pigeon.</Body>
                </div>
                <YearCardFooter day="Sun, Oct 12" tint="wonder"/>
              </Paper>
            </div>

            {/* video card */}
            <div style={{ position: 'relative' }}>
              <Paper pad={0} style={{ overflow: 'hidden' }}>
                <div style={{ position: 'relative' }}>
                  <MediaThumbnail kind="video" color="#c9d4bd" style={{ width: '100%', aspectRatio: '4/3', borderRadius: 0 }}/>
                  <div style={{ position: 'absolute', bottom: 8, right: 8, background: 'rgba(44,36,24,0.62)', borderRadius: 999, padding: '3px 8px', fontFamily: YF.sans, fontSize: 10.5, fontWeight: 700, color: '#fff', letterSpacing: '0.01em' }}>0:12</div>
                </div>
                <div style={{ padding: '11px 13px 0' }}>
                  <Body size={13} style={{ lineHeight: 1.4 }}>The laugh that only happens when Dad drops something.</Body>
                </div>
                <YearCardFooter day="Thu, Jan 22" tint="calm"/>
              </Paper>
            </div>

            {/* one-line text quote */}
            <div style={{ position: 'relative' }}>
              <Paper pad={0} style={{ overflow: 'hidden' }}>
                <div style={{ padding: '18px 16px 2px', background: `linear-gradient(170deg, ${emo.tender.soft}4d 0%, transparent 70%)` }}>
                  <div style={{ fontFamily: YF.display, fontStyle: 'italic', fontSize: 16, lineHeight: 1.4, color: YC.ink }}>&ldquo;More bastetti please.&rdquo;</div>
                </div>
                <YearCardFooter day="Tue, Mar 3" tint="tender"/>
              </Paper>
            </div>

          </div>
        </div>
      </div>

      <div style={{ flexShrink: 0, padding: '0 26px 40px' }}>
        <Body muted size={14} style={{ textAlign: 'center' }}>Talk, type, photos, video. All of it lands in {YNB.name}'s journal.</Body>
        <Button style={{ width: '100%', marginTop: 16 }}>I could actually do this</Button>
      </div>

      <style>{`@keyframes yearDrift { from { transform: translateY(0) } to { transform: translateY(-58%) } }`}</style>
    </div>
  );
}

Object.assign(window, { OnbYear, YearCardFooter });
