// Family member management + memory editing screens
const { c: FC, f: FF, s: FS, r: FR } = window.MOMORA;

const FE_GENDERS = ['male', 'female', 'prefer not to say'];

const iconBtnFE = {
  width: 38, height: 38, borderRadius: '50%', background: '#fff',
  border: `1px solid ${window.MOMORA.c.border}`,
  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
};

// ─── Shared: Gender picker ───────────────────────────────────────────────────
function GenderPicker({ value, onChange }) {
  return (
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
      {FE_GENDERS.map(g => {
        const on = value === g;
        return (
          <button key={g} onClick={() => onChange(g)} style={{
            padding: '7px 14px', borderRadius: FR.pill,
            background: on ? FC.primaryTint : '#fff',
            border: `1px solid ${on ? FC.primary : FC.border}`,
            fontFamily: FF.sans, fontSize: 13, fontWeight: 600,
            color: on ? FC.primary : FC.ink2, cursor: 'pointer',
            transition: 'all 140ms',
          }}>{g}</button>
        );
      })}
    </div>
  );
}

// ─── Shared: Nickname pill adder ─────────────────────────────────────────────
function NicknameAdder({ value = [], onChange }) {
  const [input, setInput] = React.useState('');

  const add = () => {
    const v = input.trim();
    if (v && !value.includes(v)) onChange([...value, v]);
    setInput('');
  };
  const remove = n => onChange(value.filter(x => x !== n));
  const onKey = e => { if (e.key === 'Enter') { e.preventDefault(); add(); } };

  return (
    <div>
      <label style={{ fontFamily: FF.sans, fontSize: 13, fontWeight: 600, color: FC.ink2, display: 'block', marginBottom: 10 }}>
        Nicknames
      </label>
      {/* Existing pills */}
      {value.length > 0 && (
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 10 }}>
          {value.map(n => (
            <div key={n} style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '5px 8px 5px 12px', borderRadius: FR.pill,
              background: FC.primaryTint, border: `1px solid ${FC.primary}50`,
            }}>
              <span style={{ fontFamily: FF.sans, fontSize: 13, fontWeight: 600, color: FC.primary }}>{n}</span>
              <button onClick={() => remove(n)} style={{
                width: 18, height: 18, borderRadius: '50%', border: 'none',
                background: FC.primary + '22', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0,
              }}>
                <Icon name="x" size={10} color={FC.primary} strokeWidth={2.5}/>
              </button>
            </div>
          ))}
        </div>
      )}
      {/* Input row */}
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={onKey}
          placeholder="Add a nickname…"
          style={{
            flex: 1, fontFamily: FF.sans, fontSize: 15, color: FC.ink,
            background: 'transparent', border: 'none',
            borderBottom: `1px solid ${FC.border}`,
            outline: 'none', padding: '6px 0',
          }}
        />
        {input.trim().length > 0 && (
          <button onClick={add} style={{
            padding: '5px 12px', borderRadius: FR.pill, border: 'none',
            background: FC.primary, color: '#fff',
            fontFamily: FF.sans, fontSize: 12, fontWeight: 700, cursor: 'pointer',
          }}>Add</button>
        )}
      </div>
      <div style={{ fontFamily: FF.sans, fontSize: 12, color: FC.ink3, marginTop: 5 }}>Press Enter or tap Add</div>
    </div>
  );
}

// ─── Shared: Photo upload circle ─────────────────────────────────────────────
function PhotoUpload({ name = '?', tint, existing = false }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
      <button style={{
        width: 96, height: 96, borderRadius: '50%', position: 'relative',
        background: existing ? 'transparent' : FC.surface,
        border: existing ? 'none' : `2px dashed ${FC.borderStrong}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', padding: 0, overflow: 'hidden',
      }}>
        {existing
          ? <Avatar name={name} size={96} tint={tint || 'tender'}/>
          : <Icon name="camera" size={26} color={FC.ink3} strokeWidth={1.5}/>
        }
        {existing && (
          <div style={{
            position: 'absolute', inset: 0, borderRadius: '50%',
            background: 'rgba(0,0,0,0.32)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon name="camera" size={20} color="#fff" strokeWidth={1.75}/>
          </div>
        )}
      </button>
      <Body size={12} muted>{existing ? 'Change photo' : 'Add photo'}</Body>
    </div>
  );
}

// ─── ADD FAMILY MEMBER ──────────────────────────────────────────────────────
function AddFamilyMember({ onCancel = () => {}, onSave = () => {} }) {
  const [name, setName]           = React.useState('');
  const [nicknames, setNicknames] = React.useState([]);
  const [dob, setDob]             = React.useState('');
  const [gender, setGender]       = React.useState('');
  const [about, setAbout]         = React.useState('');

  const canSave = name.trim().length > 0;

  return (
    <div style={{ height: '100%', background: FC.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

      {/* ── Header ── */}
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: FF.sans, fontSize: 16, fontWeight: 600, color: FC.primary, padding: 0 }}>Cancel</button>
        <span style={{ fontFamily: FF.sans, fontSize: 15, fontWeight: 700, color: FC.ink }}>Add person</span>
        <button onClick={canSave ? onSave : undefined} style={{ background: 'none', border: 'none', cursor: canSave ? 'pointer' : 'default', fontFamily: FF.sans, fontSize: 16, fontWeight: 700, color: canSave ? FC.primary : FC.ink3, padding: 0 }}>Save</button>
      </div>

      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: '32px 24px 52px', display: 'flex', flexDirection: 'column', gap: 28 }}>

          <PhotoUpload name={name} existing={false}/>

          <Field label="Name">
            <Input value={name} onChange={setName} placeholder="e.g. Lila"/>
          </Field>

          <NicknameAdder value={nicknames} onChange={setNicknames}/>

          <Field label="Gender">
            <GenderPicker value={gender} onChange={setGender}/>
          </Field>

          <Field label="Date of birth">
            <Input value={dob} onChange={setDob} type="date"/>
          </Field>

          <Field label="About" hint="Physical traits, quirks, personality — anything that paints a picture">
            <Input
              value={about}
              onChange={setAbout}
              placeholder="Has green eyes and hair always sort of messy…"
              multiline
              rows={3}
            />
          </Field>

        </div>
      </div>
    </div>
  );
}

// ─── VIEW FAMILY MEMBER ─────────────────────────────────────────────────────
function ViewFamilyMember({ member = window.MOMORA_MOCK.family[0], onBack = () => {}, onEdit = () => {}, onPortraits = () => {} }) {
  const emo = window.MOMORA_EMOTIONS[member.tint] || window.MOMORA_EMOTIONS.joy;
  const memories = window.MOMORA_MOCK.memories.filter(m => m.tagged.includes(member.id));
  const portraits = window.portraitsFor(member.id);
  const current = portraits.find(p => p.status === 'ready');
  const portraitCount = portraits.filter(p => p.status === 'ready').length;

  return (
    <div style={{ height: '100%', background: FC.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

      {/* ── Header ── */}
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <button onClick={onBack} style={iconBtnFE}>
          <Icon name="chevronLeft" size={18} color={FC.ink2}/>
        </button>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={onEdit} style={iconBtnFE}><Icon name="edit" size={16} color={FC.ink2}/></button>
          <button style={iconBtnFE}><Icon name="trash" size={15} color={FC.error}/></button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: '20px 24px 48px', display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* ── Identity + portrait card ── */}
          <Paper pad={0} style={{ overflow: 'hidden' }}>
            <div style={{ display: 'flex', gap: 0, alignItems: 'stretch' }}>
              <div style={{
                width: 130, flexShrink: 0, position: 'relative',
                background: current ? undefined : `linear-gradient(135deg, ${emo.soft}, ${emo.c})`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {current ? (
                  <Illustration emotion={current.emotion} scene={current.scene}
                    style={{ position: 'absolute', inset: 0, borderRadius: 0 }}/>
                ) : (
                  <Display size={64} style={{ color: '#fff', fontStyle: 'italic', textShadow: '0 2px 12px rgba(0,0,0,0.15)' }}>
                    {member.name.charAt(0)}
                  </Display>
                )}
                {/* ── Portrait timeline action ── */}
                <button
                  onClick={onPortraits}
                  aria-label={`Open portrait timeline, ${portraitCount} portraits`}
                  style={{
                    position: 'absolute', bottom: 8, right: 8,
                    width: 34, height: 34, borderRadius: '50%', cursor: 'pointer',
                    background: '#fff', border: `1px solid ${FC.border}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    boxShadow: '0 2px 8px rgba(28,20,10,0.18)', padding: 0,
                  }}>
                  <Icon name="history" size={17} color={FC.ink} strokeWidth={2}/>
                  {portraitCount > 0 && (
                    <span style={{
                      position: 'absolute', top: -5, right: -5, minWidth: 17, height: 17,
                      padding: '0 4px', borderRadius: 999, background: FC.primary,
                      border: '1.5px solid #fff', color: '#fff',
                      fontFamily: FF.sans, fontSize: 10, fontWeight: 700,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>{portraitCount}</span>
                  )}
                </button>
              </div>
              <div style={{ padding: '14px 16px', flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 6 }}>
                <Title size={20} style={{ lineHeight: 1.1 }}>{member.name}</Title>
                <Body size={13} muted>{window.ageOf(member.dob)} old</Body>
                {member.nicknames.length > 0 && (
                  <Body size={12} muted style={{ fontFamily: FF.script, fontSize: 16, color: FC.ink2 }}>
                    "{member.nicknames.join(', ')}"
                  </Body>
                )}
              </div>
            </div>
          </Paper>

          {/* ── Memories ── */}
          {memories.length > 0 && (
            <div>
              <Eyebrow color={FC.ink3} style={{ fontSize: 10, marginBottom: 12 }}>
                Memories with {member.name}
              </Eyebrow>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {memories.map(m => (
                  <Paper key={m.id} pad={14} style={{ display: 'flex', gap: 12, alignItems: 'center', cursor: 'pointer' }}>
                    {m.memory_type === 'media' ? (
                      <MediaThumbnail kind={m.mediaKind} color={m.mediaColor}
                        style={{ width: 54, height: 54, borderRadius: 12, flexShrink: 0 }}/>
                    ) : m.memory_type === 'text_only' ? (
                      <div style={{
                        width: 54, height: 54, borderRadius: 12, flexShrink: 0,
                        background: m.emotion ? window.MOMORA_EMOTIONS[m.emotion].soft : FC.surface,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                      }}>
                        <span style={{
                          fontFamily: FF.display, fontSize: 32, lineHeight: 1, fontWeight: 400,
                          color: m.emotion ? window.MOMORA_EMOTIONS[m.emotion].ink : FC.ink3,
                          opacity: 0.45, marginTop: -4,
                        }}>"</span>
                      </div>
                    ) : (
                      <Illustration emotion={m.emotion} scene={m.scene}
                        style={{ width: 54, height: 54, borderRadius: 12, flexShrink: 0 }}/>
                    )}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <Eyebrow color={FC.ink3} style={{ fontSize: 10 }}>{window.fmtDate(m.date)}</Eyebrow>
                      {m.content ? (
                        <div style={{
                          marginTop: 4, fontFamily: FF.display, fontWeight: 400,
                          fontSize: 14, lineHeight: 1.4, color: FC.ink,
                          display: '-webkit-box', WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical', overflow: 'hidden',
                        }}>{m.content}</div>
                      ) : (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 4 }}>
                          <Icon name={m.mediaKind === 'video' ? 'video' : 'camera'} size={13} color={FC.ink3} strokeWidth={1.75}/>
                          <Body size={12} muted>{m.mediaKind === 'video' ? 'Video' : 'Photo'}</Body>
                        </div>
                      )}
                      {m.emotion && <div style={{ marginTop: 5 }}><EmotionChip emotion={m.emotion} size="sm"/></div>}
                    </div>
                    <Icon name="chevronRight" size={15} color={FC.ink3}/>
                  </Paper>
                ))}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

// ─── EDIT FAMILY MEMBER ─────────────────────────────────────────────────────
function EditFamilyMember({ member = window.MOMORA_MOCK.family[0], onCancel = () => {}, onSave = () => {} }) {
  const [name, setName]           = React.useState(member.name);
  const [nicknames, setNicknames] = React.useState([...(member.nicknames || [])]);
  const [dob, setDob]             = React.useState(member.dob);
  const [gender, setGender]       = React.useState(member.gender || 'female');
  const [about, setAbout]         = React.useState(member.about || '');

  return (
    <div style={{ height: '100%', background: FC.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

      {/* ── Header ── */}
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: FF.sans, fontSize: 16, fontWeight: 600, color: FC.primary, padding: 0 }}>Cancel</button>
        <span style={{ fontFamily: FF.sans, fontSize: 15, fontWeight: 700, color: FC.ink }}>Edit person</span>
        <button onClick={onSave} style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: FF.sans, fontSize: 16, fontWeight: 700, color: FC.primary, padding: 0 }}>Save</button>
      </div>

      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: '32px 24px 52px', display: 'flex', flexDirection: 'column', gap: 28 }}>

          <PhotoUpload name={name} tint={member.tint} existing={true}/>

          <Field label="Name">
            <Input value={name} onChange={setName} placeholder="Name"/>
          </Field>

          <NicknameAdder value={nicknames} onChange={setNicknames}/>

          <Field label="Gender">
            <GenderPicker value={gender} onChange={setGender}/>
          </Field>

          <Field label="Date of birth">
            <Input value={dob} onChange={setDob} type="date"/>
          </Field>

          <Field label="About" hint="Physical traits, quirks, personality — anything that paints a picture">
            <Input
              value={about}
              onChange={setAbout}
              placeholder="Has green eyes and hair always sort of messy…"
              multiline
              rows={3}
            />
          </Field>

          <button style={{
            width: '100%', background: 'none', border: 'none', cursor: 'pointer',
            fontFamily: FF.sans, fontSize: 14, fontWeight: 600, color: FC.error,
            textAlign: 'center', padding: '8px 0',
          }}>Remove from family</button>

        </div>
      </div>
    </div>
  );
}

// ─── EDIT MEMORY ────────────────────────────────────────────────────────────
// Mirrors NewMemoryA layout exactly — pre-populated. Illustration shown as
// a removable attachment. Toolbar: mic + paperclip (disabled when attachment) + AI toggle.
function EditMemory({ m = window.MOMORA_MOCK.memories[0], onCancel = () => {}, onSave = () => {}, pickerOpen = false }) {
  const family  = window.MOMORA_MOCK.family;
  const isMedia = m.memory_type === 'media';
  const isIllus = m.memory_type === 'text_illustration';

  const [text, setText]                             = React.useState(m.content || '');
  const [tagged, setTagged]                         = React.useState([...m.tagged]);
  const [illustrationEnabled, setIllustrationEnabled] = React.useState(isIllus);
  const [illustrationAttached, setIllustrationAttached] = React.useState(isIllus);

  const hasAttachment = isMedia || illustrationAttached;

  // Type badge — mirrors NewMemoryA
  const typeLabel  = isMedia
    ? (m.mediaKind === 'video' ? 'Video' : 'Photo')
    : illustrationEnabled ? 'Illustrated' : 'Text only';
  const typeIcon   = isMedia
    ? (m.mediaKind === 'video' ? 'video' : 'camera')
    : illustrationEnabled ? 'sparkle' : 'type';
  const typeColor  = (!isMedia && illustrationEnabled) ? FC.primary : FC.ink2;
  const typeBg     = (!isMedia && illustrationEnabled) ? FC.primaryTint : FC.surface;
  const typeBorder = (!isMedia && illustrationEnabled) ? FC.primary + '50' : FC.border;

  return (
    <div style={{ height: '100%', background: FC.bg, display: 'flex', flexDirection: 'column', position: 'relative' }}>

      {/* ── Header ── */}
      <div style={{ padding: '60px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: FF.sans, fontSize: 16, fontWeight: 600, color: FC.primary, padding: 0 }}>Cancel</button>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 5,
          background: typeBg, border: `1px solid ${typeBorder}`,
          borderRadius: 999, padding: '5px 11px 5px 8px',
          transition: 'all 220ms cubic-bezier(.22,.61,.36,1)',
        }}>
          <Icon name={typeIcon} size={12} color={typeColor} strokeWidth={2}/>
          <span style={{ fontFamily: FF.sans, fontSize: 12, fontWeight: 700, color: typeColor }}>{typeLabel}</span>
        </div>
        <button onClick={onSave} style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: FF.sans, fontSize: 16, fontWeight: 700, color: FC.primary, padding: 0 }}>Save</button>
      </div>

      {/* ── Date pill ── */}
      <div style={{ padding: '14px 20px 0' }}>
        <button style={{
          background: '#fff', border: `1px solid ${FC.border}`, borderRadius: 999,
          padding: '6px 13px', fontFamily: FF.sans, fontSize: 13, fontWeight: 600,
          color: FC.ink2, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 7,
        }}>
          <Icon name="calendar" size={13} color={FC.ink2}/>
          {window.fmtDate(m.date)}
          <Icon name="chevronDown" size={13} color={FC.ink2}/>
        </button>
      </div>

      {/* ── Text area ── */}
      <div style={{ padding: '14px 20px 0', flex: hasAttachment ? 0 : 1, display: 'flex', flexDirection: 'column', minHeight: hasAttachment ? 'auto' : 0 }}>
        <textarea
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder={isMedia ? 'Add a caption…' : 'Edit your memory…'}
          style={{
            flex: 1, width: '100%', background: 'transparent', border: 'none', outline: 'none',
            fontFamily: FF.display, fontWeight: 400, fontSize: 20, lineHeight: 1.55,
            color: FC.ink, resize: 'none', boxSizing: 'border-box',
            minHeight: hasAttachment ? 64 : 140,
          }}
        />
      </div>

      {/* ── Illustration attachment (removable) ── */}
      {illustrationAttached && (
        <div style={{ flex: 1, padding: '10px 20px 0', minHeight: 0 }}>
          <div style={{ position: 'relative', height: '100%' }}>
            <Illustration emotion={m.emotion} scene={m.scene}
              style={{ width: '100%', height: '100%', borderRadius: 18 }}
              stamp={window.fmtDate(m.date)}/>
            <button
              onClick={() => { setIllustrationAttached(false); setIllustrationEnabled(false); }}
              style={{
                position: 'absolute', top: 10, right: 10,
                width: 32, height: 32, borderRadius: '50%',
                background: 'rgba(0,0,0,0.48)', border: 'none',
                display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
              }}>
              <Icon name="x" size={14} color="#fff" strokeWidth={2.5}/>
            </button>
          </div>
        </div>
      )}

      {/* ── Media attachment (read-only) ── */}
      {isMedia && (
        <div style={{ flex: 1, padding: '10px 20px 0', minHeight: 0 }}>
          <div style={{ position: 'relative', height: '100%' }}>
            <MediaThumbnail kind={m.mediaKind} color={m.mediaColor || '#ddc9a8'}
              style={{ width: '100%', height: '100%', borderRadius: 18 }}/>
            {m.mediaKind === 'video' && (
              <div style={{
                position: 'absolute', bottom: 10, right: 12,
                background: 'rgba(0,0,0,0.45)', borderRadius: 999,
                padding: '4px 10px', display: 'flex', alignItems: 'center', gap: 5,
              }}>
                <Icon name="play" size={11} color="#fff" strokeWidth={2.5}/>
                <span style={{ fontFamily: FF.sans, fontSize: 12, fontWeight: 600, color: '#fff' }}>0:32</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Who's in it ── */}
      <div style={{ flexShrink: 0 }}>
        <WhosInIt tagged={tagged} setTagged={setTagged} max={4} defaultOpen={pickerOpen}/>
      </div>

      {/* ── Bottom toolbar — exact NewMemoryA pattern ── */}
      <div style={{
        padding: '13px 20px 28px',
        borderTop: `1px solid ${FC.border}`,
        marginTop: 12,
        display: 'flex', alignItems: 'center', gap: 10,
        flexShrink: 0,
      }}>
        {/* Mic */}
        <button style={{
          width: 46, height: 46, borderRadius: '50%', flexShrink: 0,
          background: '#fff', border: `1px solid ${FC.border}`,
          cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="mic" size={20} color={FC.sea} strokeWidth={2}/>
        </button>

        {/* Attach — disabled when any attachment exists */}
        <button style={{
          width: 46, height: 46, borderRadius: '50%', flexShrink: 0,
          background: '#fff', border: `1px solid ${FC.border}`,
          cursor: hasAttachment ? 'default' : 'pointer',
          opacity: hasAttachment ? 0.4 : 1,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'all 140ms',
        }}>
          <Icon name="paperclip" size={20} color={FC.ink2} strokeWidth={1.75}/>
        </button>

        {/* AI illustration toggle — exact NewMemoryA style, hidden for media */}
        {!isMedia && (
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 10 }}>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontFamily: FF.sans, fontSize: 12.5, fontWeight: 700, color: illustrationEnabled ? FC.ink : FC.ink3 }}>
                AI illustration
              </div>
              <div style={{ fontFamily: FF.sans, fontSize: 11, color: FC.ink3 }}>
                {illustrationEnabled ? 'On — runs after save' : 'Off — text only'}
              </div>
            </div>
            <div
              onClick={() => setIllustrationEnabled(v => !v)}
              style={{ cursor: 'pointer', flexShrink: 0 }}
            >
              <div style={{
                width: 44, height: 26, borderRadius: 999,
                background: illustrationEnabled ? FC.primary : FC.border,
                transition: 'background 200ms',
                display: 'flex', alignItems: 'center', padding: '0 3px',
              }}>
                <div style={{
                  width: 20, height: 20, borderRadius: '50%', background: '#fff',
                  transform: illustrationEnabled ? 'translateX(18px)' : 'translateX(0)',
                  transition: 'transform 200ms cubic-bezier(.22,.61,.36,1)',
                  boxShadow: '0 1px 4px rgba(0,0,0,0.18)',
                }}/>
              </div>
            </div>
          </div>
        )}
      </div>

    </div>
  );
}

Object.assign(window, { AddFamilyMember, ViewFamilyMember, EditFamilyMember, EditMemory });
