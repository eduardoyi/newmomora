// Rediscovery — "Looking back" packages.
// A package = a curated set of OLDER memories (min 4, usually ≤ 10).
// A memory = one chapter. A chapter has 1..10 ordered presentation frames.
// Rotation/cooldown is server-side; the client just receives today's set.

(function () {
  // frame durations (ms) — unhurried, never rushed
  const DUR = {
    illustration: 5600,
    photo: 4600,
    video: (secs) => Math.min(9000, Math.max(3500, (secs || 6) * 1000)),
    textShort: 5600,
    textLong: (words) => Math.min(16000, 6000 + words * 260),
    intro: 2600,
  };

  // asset helper: a(kind, ratio, color, extra)
  const a = (kind, ratio, color, extra = {}) => ({ kind, ratio, color, ...extra });

  const P1 = {
    id: 'p-onthisday',
    kind: 'On this day',
    title: 'Two years ago today',
    sub: 'Saturday, May 25 · 2024',
    era: '2024',
    tint: 'tender',
    viewed: false,
    cover: { type: 'illustration', emotion: 'mischief', scene: 'garden' },
    layers: ['#E8D6C2', '#D9CBE4'],
    chapters: [
      {
        id: 'c1', date: '2024-05-25', type: 'text_illustration',
        emotion: 'mischief', scene: 'garden', tagged: ['lila'],
        content: 'Declared the hose "broken" immediately after soaking the dog. Held the interview standing in the flowerbed.',
      },
      {
        id: 'c2', date: '2024-05-25', type: 'media', emotion: null, tagged: ['lila'],
        content: 'Sandals on the wrong feet. All day. On purpose.',
        assets: [a('photo', '3/4', '#d9c4a4')],
      },
      {
        id: 'c3', date: '2024-05-24', type: 'multi_media', emotion: 'joy', tagged: ['lila', 'theo'],
        content: 'Two hours at the zoo. Favourite animal: a pigeon.',
        assets: [
          a('photo', '4/3', '#cdd6bb'),
          a('photo', '3/4', '#e0cdb2'),
          a('video', '4/3', '#b9cdb2', { duration: 14 }),
          a('photo', '1/1', '#d5c3d8'),
        ],
      },
      {
        id: 'c4', date: '2024-05-23', type: 'text_only', emotion: 'wonder', tagged: ['lila'],
        content: '"Mama, does the moon get tired?" — 7:14pm, from the bath.',
      },
      {
        id: 'c5', date: '2024-05-22', type: 'text_only', emotion: 'calm', tagged: ['lila', 'sam'],
        content: 'She woke up before anyone else and came looking for me instead of the tablet. We sat on the kitchen floor because the chairs were "too far away" and shared the last of the raspberries, one each, taking turns, until she gave me two in a row and told me it was because I looked tired. Then she asked whether the raspberries had families. I said probably. She said we should eat the lonely ones first. It was 6:40 in the morning and I already knew nothing better would happen that day.',
      },
      {
        id: 'c6', date: '2024-05-21', type: 'media', emotion: null, tagged: ['lila'],
        content: 'The whole alphabet. Twice. Off-key, at full volume, from inside the laundry basket.',
        assets: [a('video', '9/16', '#c6bcd4', { duration: 8 })],
      },
    ],
  };

  // Lighter packages — same shape, fewer bespoke words.
  const mk = (o, chapters) => ({ ...o, chapters });

  const P2 = mk({
    id: 'p-around', kind: 'Around this time', title: 'Late May, four years running',
    sub: '2021 – 2025', era: 'Late May', tint: 'calm', viewed: false,
    cover: { type: 'illustration', emotion: 'calm', scene: 'window' },
    layers: ['#D8E2D2', '#EADFCB'],
  }, [
    { id: 'a1', date: '2021-05-28', type: 'text_illustration', emotion: 'calm', scene: 'window', tagged: ['theo'], content: 'Rain all afternoon. He narrated every drop that made it to the bottom of the glass.' },
    { id: 'a2', date: '2022-05-30', type: 'media', tagged: ['lila'], content: 'Nine days old and already suspicious of the camera.', assets: [a('photo', '3/4', '#e2cfc0')] },
    { id: 'a3', date: '2023-05-26', type: 'text_only', emotion: 'joy', tagged: ['lila'], content: 'First full sentence, delivered as a complaint about socks.' },
    { id: 'a4', date: '2024-05-27', type: 'multi_media', emotion: 'wonder', tagged: ['lila', 'theo'], content: 'The strawberry field. Mostly eaten, barely picked.', assets: [a('photo', '4/3', '#e3c6bd'), a('photo', '4/3', '#d8c9a6'), a('photo', '1/1', '#cfd8bd')] },
    { id: 'a5', date: '2025-05-24', type: 'text_illustration', emotion: 'tender', scene: 'kitchen', tagged: ['noor'], content: 'Noor learned the word "more" and used it forty times before lunch.' },
  ]);

  const P3 = mk({
    id: 'p-age', kind: 'Lila at two', title: 'The year she narrated everything',
    sub: '2024 · age 2', era: 'Age 2', tint: 'mischief', viewed: false,
    cover: { type: 'photo', color: '#dcc3a8' },
    layers: ['#E6D3C0', '#D6CCE6'],
  }, [
    { id: 'b1', date: '2024-03-19', type: 'text_illustration', emotion: 'mischief', scene: 'bedroom', tagged: ['lila'], content: 'Found my slippers, decided they were microphones. Full setlist before breakfast. She bowed.' },
    { id: 'b2', date: '2024-06-02', type: 'media', tagged: ['lila'], content: 'Hat: hers. Boots: mine. Opinions: strong.', assets: [a('photo', '3/4', '#d5c9ae')] },
    { id: 'b3', date: '2024-08-14', type: 'text_only', emotion: 'joy', tagged: ['lila'], content: 'Called the vacuum "the loud dog" and apologised to it.' },
    { id: 'b4', date: '2024-10-05', type: 'multi_media', emotion: 'wonder', tagged: ['lila'], content: 'Leaf collection, curated over one hour, sorted by "loudness".', assets: [a('photo', '4/3', '#dbc59d'), a('video', '4/3', '#c8b998', { duration: 11 }), a('photo', '3/4', '#cbb99f')] },
    { id: 'b5', date: '2024-12-24', type: 'text_illustration', emotion: 'tender', scene: 'window', tagged: ['lila', 'sam'], content: 'Stayed up for the lights, fell asleep for the lights, woke up cross about the lights.' },
  ]);

  const P4 = mk({
    id: 'p-season', kind: 'A season', title: 'The summer of the hose',
    sub: 'June – August 2024', era: 'Summer 2024', tint: 'joy', viewed: true, seenLabel: 'Revisited today',
    cover: { type: 'illustration', emotion: 'joy', scene: 'garden' },
    layers: ['#EBD9B4', '#DCCBB0'],
  }, [
    { id: 'd1', date: '2024-06-21', type: 'media', tagged: ['lila', 'theo'], content: 'Paddling pool, day one, factory settings.', assets: [a('photo', '4/3', '#cfd9c2')] },
    { id: 'd2', date: '2024-07-09', type: 'text_only', emotion: 'joy', tagged: ['theo'], content: 'Announced that water is "for everyone" and acted on it immediately.' },
    { id: 'd3', date: '2024-07-30', type: 'text_illustration', emotion: 'joy', scene: 'garden', tagged: ['lila'], content: 'Sprinkler diplomacy. Terms were unclear but everyone was soaked and satisfied.' },
    { id: 'd4', date: '2024-08-17', type: 'multi_media', emotion: 'calm', tagged: ['lila', 'noor'], content: 'Last warm evening. Nobody wanted to come in.', assets: [a('photo', '4/3', '#e0c9a5'), a('photo', '3/4', '#d3c1a2')] },
  ]);

  const P5 = mk({
    id: 'p-quiet', kind: 'From your archive', title: 'Quiet mornings',
    sub: '2023 – 2025', era: 'Mornings', tint: 'wonder', viewed: true, seenLabel: 'Revisited Tuesday',
    cover: { type: 'illustration', emotion: 'wonder', scene: 'bath' },
    layers: ['#CFDCE8', '#E3D9C6'],
  }, [
    { id: 'e1', date: '2023-11-04', type: 'text_only', emotion: 'calm', tagged: ['sam', 'lila'], content: 'Six-forty. Two cups, one of them pretend.' },
    { id: 'e2', date: '2024-02-11', type: 'media', tagged: ['lila'], content: 'Frost on the inside of the window, traced with one finger.', assets: [a('photo', '4/3', '#c9d3de')] },
    { id: 'e3', date: '2024-09-30', type: 'text_illustration', emotion: 'wonder', scene: 'window', tagged: ['noor'], content: 'Watched the bin lorry like it was weather.' },
    { id: 'e4', date: '2025-01-18', type: 'text_only', emotion: 'tender', tagged: ['lila'], content: 'Climbed in beside me and whispered the whole plan for the day. It involved a cat we do not own.' },
  ]);

  // A package that happens to hold only written memories — no art to lean on.
  const P6 = mk({
    id: 'p-words', kind: 'From your archive', title: 'Small things, written down',
    sub: '2023 – 2025', era: '2023 – 2025', tint: 'wonder', viewed: false,
    cover: { type: 'text', emotion: 'wonder' },
    layers: ['#DCE6F0', '#EDE4D4'],
  }, [
    { id: 'w1', date: '2023-08-12', type: 'text_only', emotion: 'wonder', tagged: ['lila'], content: '“Mama, does the moon get tired?” — 7:14pm, from the bath.' },
    { id: 'w2', date: '2024-01-27', type: 'text_only', emotion: 'joy', tagged: ['lila'], content: 'Called the vacuum “the loud dog” and apologised to it.' },
    { id: 'w3', date: '2024-11-03', type: 'text_only', emotion: 'mischief', tagged: ['lila'], content: 'Spent the whole bus ride explaining to a stranger which of her socks was the fast one.' },
    { id: 'w4', date: '2025-06-15', type: 'text_only', emotion: 'tender', tagged: ['lila'], content: 'Asked whether I was a kid once and whether I liked it. I said mostly. She said she would check.' },
  ]);

  const packages = [P1, P2, P3, P6, P4, P5];

  // ── Frame flattening ──────────────────────────────────────────────────────
  // Every chapter yields 1..n frames. Multi-asset memories yield consecutive
  // frames inside the SAME chapter — never a nested carousel.
  const wordsOf = (s) => (s || '').trim().split(/\s+/).filter(Boolean).length;

  function chapterFrames(ch, ci) {
    const assets = ch.assets || [];
    if (ch.type === 'multi_media' || ch.type === 'media') {
      return assets.map((as, ai) => ({
        chapterIdx: ci, assetIdx: ai, assetCount: assets.length, chapter: ch, asset: as,
        kind: as.kind === 'video' ? 'video' : 'photo',
        dur: as.kind === 'video' ? DUR.video(as.duration) : DUR.photo,
      }));
    }
    if (ch.type === 'text_illustration') {
      return [{ chapterIdx: ci, assetIdx: 0, assetCount: 1, chapter: ch, kind: 'illustration', dur: DUR.illustration }];
    }
    const w = wordsOf(ch.content);
    const long = w > 45;
    return [{
      chapterIdx: ci, assetIdx: 0, assetCount: 1, chapter: ch,
      kind: long ? 'text_long' : 'text_short',
      dur: long ? DUR.textLong(w) : DUR.textShort,
    }];
  }

  function framesOf(pkg) {
    const out = [];
    pkg.chapters.forEach((ch, ci) => chapterFrames(ch, ci).forEach((f) => out.push({ ...f, i: out.length })));
    return out;
  }

  const yearOf = (iso) => iso.slice(0, 4);
  const fmtFrameDate = (iso) =>
    new Date(iso + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });

  window.MOMORA_ARCHIVE = { packages, DUR, framesOf, chapterFrames, wordsOf, yearOf, fmtFrameDate };
  window.pkgById = (id) => packages.find((p) => p.id === id);
})();
