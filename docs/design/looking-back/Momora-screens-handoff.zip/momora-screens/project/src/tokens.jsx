// Momora design tokens — JS mirror of colors_and_type.css for inline-style use.
// Source of truth: src/constants/theme.ts in the Momora2 codebase.

window.MOMORA = {
  c: {
    bg: '#FAFAFD',
    surface: '#F4F3F8',
    surface2: '#F2EFF8',
    border: '#EBE7F2',
    borderStrong: '#CFC8E0',
    white: '#F4F3F8',

    ink: '#2C2418',
    ink2: '#6B5E4F',
    ink3: '#9A8B79',

    primary: '#D63E78',
    primaryDark: '#B22A60',
    primarySoft: '#FBD3E2',
    primaryTint: '#FDEAF1',

    sun: '#F2B441', sunSoft: '#FBE8B8', sunInk: '#7a560f',
    sea: '#3FA8A1', seaSoft: '#C9ECE9', seaInk: '#1f5a56',

    joy: '#F5A623', joySoft: '#FFE7B0', joyInk: '#8a5b13',
    calm: '#6BB58A', calmSoft: '#D6EDDE', calmInk: '#3f6a4c',
    wonder: '#4F8FCC', wonderSoft: '#CFE1F4', wonderInk: '#3a5b7a',
    tender: '#EC7FA1', tenderSoft: '#FBD6E1', tenderInk: '#9c4f68',
    mischief: '#9863B8', mischiefSoft: '#E5D2F1', mischiefInk: '#5c4374',

    error: '#B42318', errorSoft: '#FCE4E1',
    success: '#4F8A5E', successSoft: '#DCEADD',
    warn: '#C48A2A', warnSoft: '#FBEFD5',
  },
  f: {
    display: '"Newsreader","Iowan Old Style",Georgia,serif',
    sans: '"Plus Jakarta Sans",-apple-system,BlinkMacSystemFont,system-ui,sans-serif',
    script: '"Caveat","Bradley Hand",cursive',
    mono: '"Space Mono",ui-monospace,Menlo,monospace',
  },
  s: { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48 },
  r: { sm: 8, md: 12, lg: 16, xl: 24, pill: 999 },
};

// Emotion lookup for chips, illustration tints, etc.
window.MOMORA_EMOTIONS = {
  joy:      { c: '#F5A623', soft: '#FFE7B0', ink: '#8a5b13' },
  calm:     { c: '#6BB58A', soft: '#D6EDDE', ink: '#3f6a4c' },
  wonder:   { c: '#4F8FCC', soft: '#CFE1F4', ink: '#3a5b7a' },
  tender:   { c: '#EC7FA1', soft: '#FBD6E1', ink: '#9c4f68' },
  mischief: { c: '#9863B8', soft: '#E5D2F1', ink: '#5c4374' },
};
