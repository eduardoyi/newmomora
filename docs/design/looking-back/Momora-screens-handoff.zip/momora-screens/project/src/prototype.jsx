// Live prototype — all screens wired with simple navigation.
const { c: PC } = window.MOMORA;

function MomoraPrototype({ start = 'login' }) {
  const [route, setRoute] = React.useState(start);
  const [stack, setStack] = React.useState([]);
  const [memory, setMemory] = React.useState(window.MOMORA_MOCK.memories[0]);
  const [member, setMember] = React.useState(window.MOMORA_MOCK.family[0]);
  const [commentsOpen, setCommentsOpen] = React.useState(false);
  const [revealState, setRevealState] = React.useState('ready');

  const go = (r) => { setStack(s => [...s, route]); setRoute(r); };
  const back = () => setStack(s => { if (s.length) setRoute(s[s.length - 1]); return s.slice(0, -1); });
  const tab = (id) => {
    const map = { timeline: 'timeline', calendar: 'calendar', family: 'family', settings: 'settings' };
    setRoute(map[id]);
  };

  // Onboarding flow
  if (route === 'login')       return <LoginA onSubmit={(r) => r === 'signup' ? go('signup') : go('timeline')}/>;
  if (route === 'signup')      return <SignupA onSubmit={() => go('add-member')}/>;
  if (route === 'add-member')  return <AddMemberA onSubmit={() => { setRevealState('generating'); go('portrait'); setTimeout(() => setRevealState('ready'), 1800); }}/>;
  if (route === 'portrait')    return <PortraitReveal state={revealState} onContinue={() => go('new-memory')}/>;

  // Core tabs
  if (route === 'timeline') return <TimelineA onOpen={(m) => { setCommentsOpen(false); setMemory(m); go('memory-detail'); }} onComment={(m) => { setCommentsOpen(true); setMemory(m); go('memory-detail'); }} onCompose={() => go('new-memory')} onTab={tab}/>;
  if (route === 'calendar') return <CalendarA onOpen={(m) => { setCommentsOpen(false); setMemory(m); go('memory-detail'); }} onTab={tab}/>;
  if (route === 'family')   return <FamilyA onTab={tab} onAdd={() => go('add-family')} onOpen={(f) => { setMember(f); go('view-family'); }}/>;
  if (route === 'settings') return <SettingsA onTab={tab} onSignOut={() => setRoute('login')}/>;

  // Memory flows
  if (route === 'memory-detail') {
    const mt = memory.memory_type;
    if (mt === 'text_only')   return <MemoryDetailB m={memory} autoOpenComments={commentsOpen} onBack={back} onEdit={() => go('edit-memory')}/>;
    if (mt === 'multi_media') return <MemoryDetailMultiMedia m={memory} autoOpenComments={commentsOpen} onBack={back} onEdit={() => go('edit-memory-multi')}/>;
    return <MemoryDetailA m={memory} autoOpenComments={commentsOpen} onBack={back} onEdit={() => go('edit-memory')}/>;
  }
  if (route === 'new-memory')       return <NewMemoryA onCancel={back} onSave={() => setRoute('timeline')}/>;
  if (route === 'new-memory-multi') return <NewMemoryMultiMedia onCancel={back} onSave={() => setRoute('timeline')}/>;
  if (route === 'edit-memory')      return <EditMemory m={memory} onCancel={back} onSave={back}/>;
  if (route === 'edit-memory-multi') return <EditMemoryMultiMedia m={memory} onCancel={back} onSave={back}/>;

  // Family flows
  if (route === 'add-family')  return <AddFamilyMember onCancel={back} onSave={back}/>;
  if (route === 'view-family') return <ViewFamilyMember member={member} onBack={back} onEdit={() => go('edit-family')} onPortraits={() => go('portraits')}/>;
  if (route === 'edit-family') return <EditFamilyMember member={member} onCancel={back} onSave={back}/>;
  if (route === 'portraits')   return <PortraitTimeline member={member} onBack={back}/>;

  return null;
}

window.MomoraPrototype = MomoraPrototype;
