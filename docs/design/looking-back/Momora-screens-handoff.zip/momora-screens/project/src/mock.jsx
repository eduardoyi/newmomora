// Mock data for the prototype.
// No separate title — just content (caption), like Instagram.
window.MOMORA_MOCK = {
  // tagCount = how often this person has been tagged. Drives "often tagged" ordering.
  family: [
    { id: 'lila',  name: 'Lila',  nicknames: ['Lils'], dob: '2022-03-14', tint: 'tender',   role: 'child',       relation: 'Daughter', tagCount: 42 },
    { id: 'noor',  name: 'Noor',  nicknames: ['Bear'], dob: '2024-08-02', tint: 'joy',       role: 'child',       relation: 'Son',      tagCount: 38 },
    { id: 'sam',   name: 'Sam',   nicknames: [],        dob: '1988-09-22', tint: 'wonder',   role: 'parent',      relation: 'You',      tagCount: 23 },
    { id: 'mateo', name: 'Mateo', nicknames: ['Matt'],  dob: '1986-04-10', tint: 'calm',     role: 'parent',      relation: 'Partner',  tagCount: 17 },
    { id: 'theo',  name: 'Theo',  nicknames: [],        dob: '2020-01-09', tint: 'mischief', role: 'child',       relation: 'Son',      tagCount: 14 },
    { id: 'rosa',  name: 'Rosa',  nicknames: ['Nana'],  dob: '1957-06-20', tint: 'tender',   role: 'grandparent', relation: 'Grandma',  tagCount: 9 },
    { id: 'henry', name: 'Henry', nicknames: ['Pop'],   dob: '1955-02-14', tint: 'wonder',   role: 'grandparent', relation: 'Grandpa',  tagCount: 6 },
    { id: 'mia',   name: 'Mia',   nicknames: [],         dob: '1992-11-30', tint: 'joy',       role: 'aunt',        relation: 'Aunt',     tagCount: 4 },
  ],
  memories: [
    {
      id: 'm7', date: '2026-05-25', dayLabel: 'Today',
      memory_type: 'multi_media',
      mediaItems: [
        { id: 'mi1', kind: 'photo',  color: '#ddc9a8' },
        { id: 'mi2', kind: 'photo',  color: '#c9d4b8' },
        { id: 'mi3', kind: 'video',  color: '#b8cdb0', duration: '0:18' },
        { id: 'mi4', kind: 'photo',  color: '#d4bfb0' },
        { id: 'mi5', kind: 'photo',  color: '#c5bfd6' },
      ],
      content: 'Morning at the park — Lila led the whole expedition.',
      tagged: ['lila', 'noor'], emotion: 'joy',
      likedByMe: false, likeCount: 4,
      comments: [
        { id: 'c71', author: 'mateo', text: "Wish I could've been on the expedition. Look at her go.", ago: '2h' },
        { id: 'c72', author: 'rosa',  text: 'My little explorer. Nana could watch this all day.', ago: '1h' },
      ],
    },
    {
      id: 'm1', date: '2026-05-23', dayLabel: 'Yesterday',
      memory_type: 'text_illustration',
      content: 'Lila found my fluffy slippers and decided they were microphones. Full setlist before breakfast. She bowed.',
      tagged: ['lila'], emotion: 'mischief', scene: 'bedroom',
      likedByMe: true, likeCount: 6,
      comments: [
        { id: 'c11', author: 'mateo', text: 'The bow at the end is what gets me every time.', ago: '1d' },
      ],
    },
    {
      id: 'm2', date: '2026-05-22', dayLabel: 'Fri',
      memory_type: 'text_only',
      content: 'Noor figured out how to peel a banana today. Mostly. The kitchen looked like a crime scene and he was beaming.',
      tagged: ['noor'], emotion: 'joy',
      likedByMe: false, likeCount: 3,
      comments: [
        { id: 'c21', author: 'rosa', text: 'That grin is exactly you at that age.', ago: '3d' },
        { id: 'c22', author: 'mia',  text: 'A true crime scene. Worth every second.', ago: '2d' },
      ],
    },
    {
      id: 'm3', date: '2026-05-21', dayLabel: 'Thu',
      memory_type: 'media', mediaKind: 'photo', mediaColor: '#ddc9a8',
      content: 'The look on his face when he finally figured it out.',
      tagged: ['noor'],
      likedByMe: false, likeCount: 2, comments: [],
    },
    {
      id: 'm4', date: '2026-05-20', dayLabel: 'Wed',
      memory_type: 'text_illustration',
      content: 'Both of them sat in the window watching the rain. No fighting. No yelling. Three whole minutes. I cried a little.',
      tagged: ['lila', 'noor'], emotion: 'calm', scene: 'window',
      likedByMe: true, likeCount: 8,
      comments: [
        { id: 'c41', author: 'mateo', text: 'Three whole minutes. Somebody frame this.', ago: '5d' },
        { id: 'c42', author: 'henry', text: 'Pop needs a copy of this one.', ago: '4d' },
      ],
    },
    {
      id: 'm5', date: '2026-05-18', dayLabel: 'Mon',
      memory_type: 'media', mediaKind: 'video', mediaColor: '#b8cdb0',
      content: null, // media with no caption
      tagged: ['lila'],
      likedByMe: false, likeCount: 1, comments: [],
    },
    {
      id: 'm6', date: '2026-05-16', dayLabel: 'Sat',
      memory_type: 'text_only',
      content: '"Mama, does the moon get tired?" — Lila, 7:14pm, looking out from the bath.',
      tagged: ['lila'], emotion: 'wonder',
      likedByMe: false, likeCount: 5,
      comments: [
        { id: 'c61', author: 'rosa', text: 'She asks the big questions, that one.', ago: '1w' },
      ],
    },
  ],
  recentDays: [
    { d: 'M', has: true  },
    { d: 'T', has: true  },
    { d: 'W', has: false },
    { d: 'T', has: true  },
    { d: 'F', has: true  },
    { d: 'S', has: false },
    { d: 'S', has: true, today: true },
  ],
};
window.MOMORA_MOCK.byId = Object.fromEntries(window.MOMORA_MOCK.family.map(f => [f.id, f]));

// ── Age-aware portrait versions ──────────────────────────────────────────────
// One dated source photo paired with its generated portrait. Newest-first.
// dateSource: exif | manual | default_today | legacy_unknown
// status:     ready | generating | failed
window.MOMORA_MOCK.portraitVersions = {
  lila: [
    { id: 'pv-l5', refDate: '2026-05-20', dateSource: 'default_today', status: 'ready', emotion: 'tender',   scene: 'window',  photo: '#e6cbb2' },
    { id: 'pv-l4', refDate: '2025-11-08', dateSource: 'exif',          status: 'ready', emotion: 'joy',      scene: 'garden',  photo: '#d9c49a' },
    { id: 'pv-l3', refDate: '2025-04-18', dateSource: 'manual',        status: 'ready', emotion: 'wonder',   scene: 'park',    photo: '#cbd3bd' },
    { id: 'pv-l2', refDate: '2024-08-10', dateSource: 'exif',          status: 'ready', emotion: 'calm',     scene: 'kitchen', photo: '#d5c1b0' },
    { id: 'pv-l1', refDate: null,         dateSource: 'legacy_unknown', status: 'ready', emotion: 'mischief', scene: 'bedroom', photo: '#d8c7ae' },
  ],
  noor: [
    { id: 'pv-n2', refDate: '2026-05-10', dateSource: 'default_today', status: 'ready', emotion: 'joy',  scene: 'garden', photo: '#ddc9a8' },
    { id: 'pv-n1', refDate: '2025-01-15', dateSource: 'exif',          status: 'ready', emotion: 'calm', scene: 'window', photo: '#c9d4b8' },
  ],
  sam: [
    { id: 'pv-s1', refDate: '2026-05-25', dateSource: 'default_today', status: 'ready', emotion: 'wonder', scene: 'window', photo: '#cfc3d6' },
  ],
};
window.portraitsFor = (id) => window.MOMORA_MOCK.portraitVersions[id] || [];

// Full-word age at a given reference date, relative to DOB.
window.ageAt = (dob, at) => {
  const a = new Date(dob + 'T12:00:00'), b = new Date(at + 'T12:00:00');
  let years = b.getFullYear() - a.getFullYear();
  let months = b.getMonth() - a.getMonth();
  if (b.getDate() < a.getDate()) months--;
  if (months < 0) { years--; months += 12; }
  const y = years === 1 ? '1 year' : `${years} years`;
  const m = months === 1 ? '1 month' : `${months} months`;
  if (years === 0) return m;
  if (months === 0) return y;
  return `${y}, ${m}`;
};
window.fmtDateLong = (iso) =>
  new Date(iso + 'T12:00:00').toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

window.fmtDate = (iso) => {
  const d = new Date(iso + 'T12:00:00');
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
};
window.ageOf = (dob) => {
  const a = new Date(dob), b = new Date('2026-05-25');
  let years = b.getFullYear() - a.getFullYear();
  let months = b.getMonth() - a.getMonth();
  if (b.getDate() < a.getDate()) months--;
  if (months < 0) { years--; months += 12; }
  if (years === 0) return `${months}m`;
  return `${years}y ${months}m`;
};
