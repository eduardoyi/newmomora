// Compose every screen variation into the design canvas.
// Each artboard wraps a screen in an iOS bezel. The first section is the
// fully clickable prototype; the rest are static variations side-by-side.

const PHONE_W = 402;
const PHONE_H = 874;
const AB_W = 432;
const AB_H = 920;

// Wrap a screen in an iOS bezel inside a fixed-size artboard frame.
function PhoneAB({ children }) {
  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f0eee9' }}>
      <IOSDevice width={PHONE_W} height={PHONE_H}>
        {children}
      </IOSDevice>
    </div>
  );
}

function MomoraCanvas() {
  return (
    <DesignCanvas>
      {/* ─── Live prototype ─── */}
      <DCSection id="prototype" title="Live prototype" subtitle="Fully clickable — start at Login, walk through onboarding, capture a memory, browse tabs.">
        <DCArtboard id="live" label="Tap through" width={AB_W} height={AB_H}>
          <PhoneAB><MomoraPrototype start="login"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="live-timeline" label="Skip to Timeline" width={AB_W} height={AB_H}>
          <PhoneAB><MomoraPrototype start="timeline"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="live-newmem" label="New memory · voice" width={AB_W} height={AB_H}>
          <PhoneAB><NewMemoryB/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── Looking back — rediscovery rail ─── */}
      <DCSection id="lb-rail" title="Looking back · packages on the Timeline" subtitle="Curated sets of older memories at the top of the Timeline. Start at the live artboard: tap a package, watch it play, tap left/right, hold to pause, open a memory, come back.">
        <DCArtboard id="lb-live" label="Live · rail → viewer → detail" width={AB_W} height={AB_H}>
          <PhoneAB><RediscoverPrototype/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="lb-timeline" label="Timeline · rail integrated" width={AB_W} height={AB_H}>
          <PhoneAB><TimelineRediscover/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="lb-cover-c" label="Package covers · warm plate" width={AB_W} height={AB_H}>
          <PhoneAB><TimelineRediscover variant="plate"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="lb-states" label="Viewed vs unviewed" width={AB_W} height={AB_H}>
          <PhoneAB>
            <div style={{ height: '100%', background: window.MOMORA.c.bg, paddingTop: 60, overflow: 'hidden' }}>
              <PackageRail label="Not opened yet" packages={[window.pkgById('p-onthisday'), window.pkgById('p-words')]}/>
              <div style={{ height: 20 }}/>
              <PackageRail label="Already revisited" packages={[
                { ...window.pkgById('p-season'), viewed: true, seenLabel: 'Revisited today' },
                { ...window.pkgById('p-words'), viewed: true, seenLabel: 'Revisited Tuesday' },
              ]}/>
              <div style={{ padding: '26px 24px 0' }}>
                <Body size={12.5} muted style={{ lineHeight: 1.6 }}>
                  A revisited plate loses its lift shadow, desaturates a touch under a lavender veil, softens its scrim, and swaps the count line for “Revisited today”. No rings, no unread dots, no expiry.
                </Body>
              </div>
            </div>
          </PhoneAB>
        </DCArtboard>
        <DCArtboard id="lb-cover-text" label="Cover · text-only package" width={AB_W} height={AB_H}>
          <PhoneAB>
            <div style={{ height: '100%', background: window.MOMORA.c.bg, paddingTop: 60, overflow: 'hidden' }}>
              <PackageRail label="Words only" packages={[
                window.pkgById('p-words'),
                { ...window.pkgById('p-words'), id: 'p-words-2', kind: 'A child at an age', title: 'Lila at two, in her own words', era: 'Age 2', cover: { type: 'text', emotion: 'calm' } },
              ]}/>
              <div style={{ padding: '26px 24px 0' }}>
                <Body size={12.5} muted style={{ lineHeight: 1.6 }}>
                  With no photo or illustration in the set, the cover leans on type alone: a single Newsreader quotation mark on an emotion-tinted plate, ink type instead of cream, no scrim. No excerpt — written memories are not always quotes, and one line rarely represents the set.
                </Body>
              </div>
            </div>
          </PhoneAB>
        </DCArtboard>
        <DCArtboard id="lb-absent" label="No packages today" width={AB_W} height={AB_H}>
          <PhoneAB><TimelineRediscover packages={[]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="lb-notes" label="Interaction &amp; motion notes" width={560} height={AB_H}>
          <RediscoverNotes/>
        </DCArtboard>
      </DCSection>

      {/* ─── Looking back — the viewer ─── */}
      <DCSection id="lb-viewer" title="Looking back · the package viewer" subtitle="Warm dark mat, cream prints. One progress segment per memory; multi-asset memories subdivide their segment into hairline ticks and play as consecutive frames. Text memories invert to a cream page.">
        <DCArtboard id="v-intro" label="Opening state" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer stage="intro"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-illus" label="AI-illustrated memory" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer startChapter={0} seed={0.55}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-photo" label="Photo memory" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer startChapter={1} seed={0.4}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-multi-1" label="Multi-asset · 1 of 4" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer startChapter={2} startAsset={0} seed={0.7}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-multi-2" label="Multi-asset · 2 of 4" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer startChapter={2} startAsset={1} seed={0.45}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-multi-3" label="Multi-asset · 3 of 4 · video" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer startChapter={2} startAsset={2} seed={0.3}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-video" label="Video memory" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer startChapter={5} seed={0.5}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-text-short" label="Text only · short" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer startChapter={3} seed={0.35}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-text-pkg" label="Text-only package · frame" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer pkgId="p-words" startChapter={2} seed={0.5}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-text-long" label="Text only · long story" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer startChapter={4} seed={0.25}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-paused" label="Paused · held" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer startChapter={2} startAsset={1} seed={0.45} frameState="paused"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-loading" label="Media loading" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer startChapter={1} seed={0} frameState="loading"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-unavailable" label="Media unavailable" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer startChapter={2} startAsset={3} seed={0.3} frameState="unavailable"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-complete" label="Package complete" width={AB_W} height={AB_H}>
          <PhoneAB><StoryViewer stage="complete"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="v-detail" label="Open memory → detail" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailMultiMedia m={window.chapterToMemory(window.pkgById('p-onthisday').chapters[2])}/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── New onboarding — story arc (S0–S8) ─── */}
      <DCSection id="onb-story" title="New onboarding · Story arc (S0–S8)" subtitle="Welcome fork, three recognition beats, founder intro, the artifact demo, and the two typed commitments. CTAs are affirmations, never Next.">
        <DCArtboard id="onb-s0" label="S0 · Welcome / fork" width={AB_W} height={AB_H}>
          <PhoneAB><OnbWelcome/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s1" label="S1 · The 2 a.m. scroll" width={AB_W} height={AB_H}>
          <PhoneAB><OnbStory1/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s2" label="S2 · The baby book" width={AB_W} height={AB_H}>
          <PhoneAB><OnbStory2/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s3" label="S3 · The stuff that goes" width={AB_W} height={AB_H}>
          <PhoneAB><OnbStory3/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s4" label="S4 · Founders" width={AB_W} height={AB_H}>
          <PhoneAB><OnbFounderA/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s5" label="S5 · The artifact demo" width={AB_W} height={AB_H}>
          <PhoneAB><OnbFounderB/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s6" label="S6 · One kid (default)" width={AB_W} height={AB_H}>
          <PhoneAB><OnbChildName value="Lila"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s6-multi" label="S6 · Two chips + third field" width={AB_W} height={AB_H}>
          <PhoneAB><OnbChildName kids={['Lila', 'Miguel']} value="Teo"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s7" label="S7 · Family name" width={AB_W} height={AB_H}>
          <PhoneAB><OnbFamilyName/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s7-multi" label="S7 · Three kids prefill" width={AB_W} height={AB_H}>
          <PhoneAB><OnbFamilyName kids={['Lila', 'Miguel', 'Teo']}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s8" label="S8 · Bridge · no behind" width={AB_W} height={AB_H}>
          <PhoneAB><OnbBridge/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── New onboarding — capture + aha (S9–S12) ─── */}
      <DCSection id="onb-capture" title="New onboarding · Capture → aha → account (S9–S12)" subtitle="Voice-first guided capture with all four states, the first-page aha (quote + photo variants), the embedded notification question, and email OTP.">
        <DCArtboard id="onb-s9-idle" label="S9 · Capture · idle" width={AB_W} height={AB_H}>
          <PhoneAB><OnbCapture mode="idle"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s9-rec" label="S9 · Recording" width={AB_W} height={AB_H}>
          <PhoneAB><OnbCapture mode="recording"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s9-trans" label="S9 · Transcribing" width={AB_W} height={AB_H}>
          <PhoneAB><OnbCapture mode="transcribing"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s9-typed" label="S9 · Typed entry" width={AB_W} height={AB_H}>
          <PhoneAB><OnbCapture mode="typed"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s9-photo" label="S9 · Photo attached" width={AB_W} height={AB_H}>
          <PhoneAB><OnbCapture mode="photo"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s9-multi" label="S9 · Multi-kid · one tagged" width={AB_W} height={AB_H}>
          <PhoneAB><OnbCapture mode="idle" kids={['Lila', 'Miguel', 'Teo']} selected={[0]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s9-multi2" label="S9 · Multi-kid · two tagged" width={AB_W} height={AB_H}>
          <PhoneAB><OnbCapture mode="idle" kids={['Lila', 'Miguel', 'Teo']} selected={[0, 1]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s10-quote" label="S10 · Aha · quote page" width={AB_W} height={AB_H}>
          <PhoneAB><OnbAha variant="quote"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s10-spread" label="S10 · Aha · photo page" width={AB_W} height={AB_H}>
          <PhoneAB><OnbAha variant="spread"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s10-multi" label="S10 · Aha · siblings tagged" width={AB_W} height={AB_H}>
          <PhoneAB><OnbAha variant="quote" tagged={['Lila', 'Miguel']}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s10b" label="S10b · A year of these" width={AB_W} height={AB_H}>
          <PhoneAB><OnbYear/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s11" label="S11 · Notification question" width={AB_W} height={AB_H}>
          <PhoneAB><OnbNotify/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s11-sel" label="S11 · Evenings selected" width={AB_W} height={AB_H}>
          <PhoneAB><OnbNotify selected="eve"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s12a" label="S12A · Email" width={AB_W} height={AB_H}>
          <PhoneAB><OnbEmail/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s12b" label="S12B · Code entry" width={AB_W} height={AB_H}>
          <PhoneAB><OnbCode/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── New onboarding — trust + paywall (S13–S16) ─── */}
      <DCSection id="onb-trust" title="New onboarding · Trust → paywall → portrait (S13–S16)" subtitle="Trial timeline kills bill shock, the export promise is a signed card, hard paywall with quiet close, then the portrait kickoff.">
        <DCArtboard id="onb-s13" label="S13 · Trial timeline" width={AB_W} height={AB_H}>
          <PhoneAB><OnbTrial/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s14" label="S14 · Included + promise" width={AB_W} height={AB_H}>
          <PhoneAB><OnbIncluded/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s15" label="S15 · Paywall" width={AB_W} height={AB_H}>
          <PhoneAB><OnbPaywall/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s15-close" label="S15 · Close confirm" width={AB_W} height={AB_H}>
          <PhoneAB><OnbPaywall closeSheet/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s16" label="S16 · Portrait kickoff" width={AB_W} height={AB_H}>
          <PhoneAB><OnbPortrait state="pick"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s16-multi" label="S16 · Portrait · several kids" width={AB_W} height={AB_H}>
          <PhoneAB><OnbPortrait state="pick" multi/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s16-paint" label="S16 · Painting" width={AB_W} height={AB_H}>
          <PhoneAB><OnbPortrait state="painting"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s17-next" label="S17 · Reveal · sibling next" width={AB_W} height={AB_H}>
          <PhoneAB><OnbReveal nextKid="Miguel"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-s17-done" label="S17 · Reveal · no siblings left" width={AB_W} height={AB_H}>
          <PhoneAB><OnbReveal/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-cast-waiting" label="Cast · waiting to be painted" width={AB_W} height={AB_H}>
          <PhoneAB><CastWaitingState/></PhoneAB>
        </DCArtboard>
      </DCSection>
      <DCSection id="onb-join" title="New onboarding · Join path (J1–J5)" subtitle="For invited family. Zero selling: code → confirm → name → OTP → wait state. All typing happens before the email round trip.">
        <DCArtboard id="onb-j1" label="J1 · Invite code" width={AB_W} height={AB_H}>
          <PhoneAB><JoinCode/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-j2" label="J2 · Family found" width={AB_W} height={AB_H}>
          <PhoneAB><JoinFound/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-j3" label="J3 · Display name" width={AB_W} height={AB_H}>
          <PhoneAB><JoinName/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-j4" label="J4 · Account" width={AB_W} height={AB_H}>
          <PhoneAB><JoinAuth/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="onb-j5" label="J5 · Approval wait" width={AB_W} height={AB_H}>
          <PhoneAB><JoinWait/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── Onboarding ─── */}
      <DCSection id="onboarding" title="Onboarding (earlier pass)" subtitle="Sign-in, sign-up, add the first child, and the hero portrait reveal.">
        <DCArtboard id="login-a" label="Login · Editorial" width={AB_W} height={AB_H}>
          <PhoneAB><LoginA/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="login-b" label="Login · Hero illustration" width={AB_W} height={AB_H}>
          <PhoneAB><LoginB/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="signup" label="Sign up" width={AB_W} height={AB_H}>
          <PhoneAB><SignupA/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="add-member" label="Add child" width={AB_W} height={AB_H}>
          <PhoneAB><AddMemberA/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="portrait-gen" label="Portrait · generating" width={AB_W} height={AB_H}>
          <PhoneAB><PortraitReveal state="generating"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="portrait-ready" label="Portrait · ready ✨" width={AB_W} height={AB_H}>
          <PhoneAB><PortraitReveal state="ready"/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── Timeline ─── */}
      <DCSection id="timeline" title="Timeline" subtitle="The home feed. Three card languages + two empty states.">
        <DCArtboard id="t-a" label="A · Mixed postcards" width={AB_W} height={AB_H}>
          <PhoneAB><TimelineA/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="t-b" label="B · Storybook spreads" width={AB_W} height={AB_H}>
          <PhoneAB><TimelineB/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="t-c" label="C · Editorial quotes" width={AB_W} height={AB_H}>
          <PhoneAB><TimelineC/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="t-empty-a" label="Empty · Poetic" width={AB_W} height={AB_H}>
          <PhoneAB><TimelineEmptyA/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="t-empty-b" label="Empty · Sample-first" width={AB_W} height={AB_H}>
          <PhoneAB><TimelineEmptyB/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── Memory detail ─── */}
      <DCSection id="detail" title="Memory detail" subtitle="Framed print layout for both illustrated + media. Emotion-tinted editorial layout for text-only. Generating state.">
        <DCArtboard id="md-a" label="Illustrated · framed print" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailA/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="md-a-media-photo" label="Media photo · framed" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailA m={window.MOMORA_MOCK.memories[2]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="md-a-media-video" label="Media video · framed" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailA m={window.MOMORA_MOCK.memories[4]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="md-gen" label="Illustrated · generating" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailA illustrationState="generating"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="md-b" label="Text only · editorial" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailB m={window.MOMORA_MOCK.memories[1]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="md-b-wonder" label="Text only · wonder" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailB m={window.MOMORA_MOCK.memories[5]}/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── Likes & comments ─── */}
      <DCSection id="engagement" title="Likes &amp; comments" subtitle="Tap the outline heart to like — it fills with a gentle pop. Tap the bubble to open the comments drawer. Counts sit next to each icon. Likes stay in sync across the timeline and detail.">
        <DCArtboard id="eng-timeline" label="Timeline · like + comment on cards" width={AB_W} height={AB_H}>
          <PhoneAB><TimelineA/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="eng-detail-illus" label="Detail · liked, 2 comments" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailA m={window.MOMORA_MOCK.memories[1]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="eng-drawer" label="Comments drawer · open" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailA m={window.MOMORA_MOCK.memories[0]} autoOpenComments/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="eng-drawer-text" label="Drawer · text-only memory" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailB m={window.MOMORA_MOCK.memories[5]} autoOpenComments/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="eng-drawer-empty" label="Drawer · no comments yet" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailA m={window.MOMORA_MOCK.memories[3]} autoOpenComments/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="eng-drawer-multi" label="Drawer · multi-media memory" width={AB_W} height={AB_H}>
          <PhoneAB><MemoryDetailMultiMedia m={window.MOMORA_MOCK.memories.find(x => x.memory_type === 'multi_media')} autoOpenComments/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── Multi-media memory ─── */}
      <DCSection id="multi-media" title="Multi-media memory" subtitle="Up to 10 photos/videos per memory. Swipeable carousel in detail view (drag to slide); dot + counter indicators. Tile grid in the composer with drag-to-reorder.">
        <DCArtboard id="mm-timeline" label="Timeline · multi-media card" width={AB_W} height={AB_H}>
          <PhoneAB><TimelineA/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="mm-detail-1" label="Detail · slide 1/5" width={AB_W} height={AB_H}>
          <PhoneAB>
            <MemoryDetailMultiMedia
              m={window.MOMORA_MOCK.memories.find(x => x.memory_type === 'multi_media')}
              startIdx={0}
            />
          </PhoneAB>
        </DCArtboard>
        <DCArtboard id="mm-detail-3" label="Detail · slide 3/5 · video" width={AB_W} height={AB_H}>
          <PhoneAB>
            <MemoryDetailMultiMedia
              m={window.MOMORA_MOCK.memories.find(x => x.memory_type === 'multi_media')}
              startIdx={2}
            />
          </PhoneAB>
        </DCArtboard>
        <DCArtboard id="mm-new-empty" label="New · empty" width={AB_W} height={AB_H}>
          <PhoneAB><NewMemoryMultiMedia/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="mm-new-filled" label="New · 4 items · mixed" width={AB_W} height={AB_H}>
          <PhoneAB>
            <NewMemoryMultiMedia
              initialItems={[
                { id: 'a1', kind: 'photo', color: '#ddc9a8' },
                { id: 'a2', kind: 'photo', color: '#c9d4b8' },
                { id: 'a3', kind: 'video', color: '#b8cdb0', duration: '0:18' },
                { id: 'a4', kind: 'photo', color: '#d4bfb0' },
              ]}
              initialText="Morning at the park — Lila led the whole expedition."
              initialTagged={['lila', 'noor']}
            />
          </PhoneAB>
        </DCArtboard>
        <DCArtboard id="mm-edit" label="Edit · 5 items" width={AB_W} height={AB_H}>
          <PhoneAB>
            <EditMemoryMultiMedia
              m={window.MOMORA_MOCK.memories.find(x => x.memory_type === 'multi_media')}
            />
          </PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── New memory ─── */}
      <DCSection id="new" title="New memory" subtitle="Type emerges from what you do — no upfront selector. Toggle AI off for text-only; attach a photo or video for media.">
        <DCArtboard id="new-a-illustrated" label="Text · AI illustration on" width={AB_W} height={AB_H}>
          <PhoneAB><NewMemoryA initial="Lila found my fluffy slippers and decided they were microphones."/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="new-a-text-only" label="Text · text only" width={AB_W} height={AB_H}>
          <PhoneAB><NewMemoryA initial="Noor figured out how to peel a banana today." initialIllustration={false}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="new-a-photo" label="Media · photo attached" width={AB_W} height={AB_H}>
          <PhoneAB><NewMemoryA initialMedia={{ kind: 'photo', color: '#ddc9a8' }}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="new-a-video" label="Media · video attached" width={AB_W} height={AB_H}>
          <PhoneAB><NewMemoryA initialMedia={{ kind: 'video', color: '#b8cdb0' }}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="new-b-idle" label="Voice · idle" width={AB_W} height={AB_H}>
          <PhoneAB><NewMemoryB/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="new-a-roster" label="Tag · roster sheet" width={AB_W} height={AB_H}>
          <PhoneAB><NewMemoryA initial="Both of them sat in the window watching the rain." initialTagged={['lila','noor']} pickerOpen/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── Calendar ─── */}
      <DCSection id="calendar" title="Calendar" subtitle="Postage-stamp grid or a vertical ribbon — same data, different feel.">
        <DCArtboard id="cal-a" label="A · Stamp grid" width={AB_W} height={AB_H}>
          <PhoneAB><CalendarA/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="cal-b" label="B · Vertical ribbon" width={AB_W} height={AB_H}>
          <PhoneAB><CalendarB/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── Family + Settings ─── */}
      <DCSection id="rest" title="Family · Settings" subtitle="The supporting cast and the quiet drawers.">
        <DCArtboard id="family" label="Family · The cast" width={AB_W} height={AB_H}>
          <PhoneAB><FamilyA/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="settings" label="Settings" width={AB_W} height={AB_H}>
          <PhoneAB><SettingsA/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── Family management ─── */}
      <DCSection id="family-mgmt" title="Family management" subtitle="Add, view, and edit family members.">
        <DCArtboard id="add-family" label="Add person" width={AB_W} height={AB_H}>
          <PhoneAB><AddFamilyMember/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="view-lila" label="View · Lila" width={AB_W} height={AB_H}>
          <PhoneAB><ViewFamilyMember member={window.MOMORA_MOCK.family[0]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="view-noor" label="View · Noor" width={AB_W} height={AB_H}>
          <PhoneAB><ViewFamilyMember member={window.MOMORA_MOCK.family[1]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="view-sam" label="View · Sam" width={AB_W} height={AB_H}>
          <PhoneAB><ViewFamilyMember member={window.MOMORA_MOCK.family[2]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="edit-lila" label="Edit · Lila" width={AB_W} height={AB_H}>
          <PhoneAB><EditFamilyMember member={window.MOMORA_MOCK.family[0]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="edit-sam" label="Edit · Sam (parent)" width={AB_W} height={AB_H}>
          <PhoneAB><EditFamilyMember member={window.MOMORA_MOCK.family[2]}/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── Portrait timeline ─── */}
      <DCSection id="portraits" title="Portrait timeline" subtitle="Age-aware portraits: every dated source photo paired with its generated portrait, newest first. Opened from the history action on the member card. Covers ready, generating, failed and legacy-undated states, plus the add / date / actions / full-screen flows.">
        <DCArtboard id="pt-member-card" label="Member card · history action" width={AB_W} height={AB_H}>
          <PhoneAB><ViewFamilyMember member={window.MOMORA_MOCK.family[0]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="pt-timeline" label="Timeline · Lila" width={AB_W} height={AB_H}>
          <PhoneAB><PortraitTimeline member={window.MOMORA_MOCK.family[0]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="pt-generating" label="Newest · generating" width={AB_W} height={AB_H}>
          <PhoneAB><PortraitTimeline member={window.MOMORA_MOCK.family[0]} topStatus="generating"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="pt-failed" label="Newest · failed · retry" width={AB_W} height={AB_H}>
          <PhoneAB><PortraitTimeline member={window.MOMORA_MOCK.family[0]} topStatus="failed"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="pt-add" label="Add portrait sheet" width={AB_W} height={AB_H}>
          <PhoneAB><PortraitTimeline member={window.MOMORA_MOCK.family[0]} sheet="add"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="pt-date" label="Date · from photo (EXIF)" width={AB_W} height={AB_H}>
          <PhoneAB><PortraitTimeline member={window.MOMORA_MOCK.family[0]} sheet="date"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="pt-actions" label="Version actions" width={AB_W} height={AB_H}>
          <PhoneAB><PortraitTimeline member={window.MOMORA_MOCK.family[0]} sheet="actions"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="pt-fullscreen" label="Full-screen viewer" width={AB_W} height={AB_H}>
          <PhoneAB><PortraitTimeline member={window.MOMORA_MOCK.family[0]} sheet="fullscreen"/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="pt-noor" label="Timeline · Noor (2)" width={AB_W} height={AB_H}>
          <PhoneAB><PortraitTimeline member={window.MOMORA_MOCK.family[1]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="pt-single" label="First portrait · explainer" width={AB_W} height={AB_H}>
          <PhoneAB><PortraitTimeline member={window.MOMORA_MOCK.family[2]}/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* ─── Edit memory ─── */}
      <DCSection id="edit-memory" title="Edit memory" subtitle="Edit flow for all three memory types.">
        <DCArtboard id="em-illustrated" label="Edit · Illustrated" width={AB_W} height={AB_H}>
          <PhoneAB><EditMemory m={window.MOMORA_MOCK.memories[0]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="em-text-only" label="Edit · Text only" width={AB_W} height={AB_H}>
          <PhoneAB><EditMemory m={window.MOMORA_MOCK.memories[1]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="em-photo" label="Edit · Photo" width={AB_W} height={AB_H}>
          <PhoneAB><EditMemory m={window.MOMORA_MOCK.memories[2]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="em-video" label="Edit · Video" width={AB_W} height={AB_H}>
          <PhoneAB><EditMemory m={window.MOMORA_MOCK.memories[4]}/></PhoneAB>
        </DCArtboard>
        <DCArtboard id="em-roster" label="Edit · roster sheet" width={AB_W} height={AB_H}>
          <PhoneAB><EditMemory m={window.MOMORA_MOCK.memories[3]} pickerOpen/></PhoneAB>
        </DCArtboard>
      </DCSection>

      {/* Floating designer notes */}
      <DCPostIt top={60} right={40} rotate={3} width={210}>
        Anchor Journal — big Newsreader serif for moments worth keeping, Caveat script for hand-touches, gentle weekly dots instead of a streak counter.
      </DCPostIt>
    </DesignCanvas>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<MomoraCanvas/>);
